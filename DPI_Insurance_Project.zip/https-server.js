/**
 * Native HTTPS Secure Proxy Server
 * Uses valid X.509 SSL certificate to serve native HTTPS traffic (port 8443)
 * and proxies securely to local PHP backend (port 8000).
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

const HTTPS_PORT = 8443;
const TARGET_PORT = 8000;
const SSL_DIR = path.join(__dirname, 'config', 'ssl');

const keyPath = path.join(SSL_DIR, 'server.key');
const certPath = path.join(SSL_DIR, 'server.crt');

if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
    console.error('ERROR: SSL key or certificate file missing in config/ssl/');
    process.exit(1);
}

const options = {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath)
};

const server = https.createServer(options, (req, res) => {
    // Set HTTPS forwarding headers
    const proxyReq = http.request({
        host: '127.0.0.1',
        port: TARGET_PORT,
        path: req.url,
        method: req.method,
        headers: {
            ...req.headers,
            'x-forwarded-proto': 'https',
            'x-forwarded-port': HTTPS_PORT.toString()
        }
    }, (proxyRes) => {
        res.writeHead(proxyRes.statusCode, proxyRes.headers);
        proxyRes.pipe(res);
    });

    proxyReq.on('error', (err) => {
        res.writeHead(502, { 'Content-Type': 'text/plain' });
        res.end('HTTPS Proxy Error: Local PHP server unavailable.');
    });

    req.pipe(proxyReq);
});

server.listen(HTTPS_PORT, '0.0.0.0', () => {
    console.log(`HTTPS Secure Server running on https://0.0.0.0:${HTTPS_PORT}`);
    console.log(`Access Patient Form via HTTPS: https://localhost:${HTTPS_PORT}/patient/index.php`);
});
