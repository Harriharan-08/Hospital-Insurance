<?php
/**
 * Hospital Officer Claim Management Portal (Phase 16 + Patient Claim Engine)
 * 
 * Enforces requireOfficer() backend guard.
 * Dynamically retrieves and renders ALL submitted patient claims, eKYC screenshots, and documents from MySQL.
 * Includes Document & Claim Verification functionality.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

requireOfficer();

$csrfToken = generateCSRFToken();

$pdo = getDBConnection();
$officerId    = (int)$_SESSION['user_id'];
$officerName  = $_SESSION['user_name'] ?? 'Officer';
$officerEmail = $_SESSION['user_email'] ?? '';
$is2FA        = $_SESSION['user_2fa_enabled'] ?? false;

$officerSuccess = $_SESSION['officer_success'] ?? null;
$officerErrors  = $_SESSION['officer_errors'] ?? [];
unset($_SESSION['officer_success']);
unset($_SESSION['officer_errors']);

// Fetch officer profile details
$stmt = $pdo->prepare("SELECT hospital_name, department, phone, status, created_at FROM users WHERE id = :id");
$stmt->execute([':id' => $officerId]);
$profile = $stmt->fetch();
$hospitalName = $profile['hospital_name'] ?? '';

// Filter and retrieve submitted patient claims for this officer's assigned hospital
if (!empty($hospitalName)) {
    $claimsStmt = $pdo->prepare("
        SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
               c.insurance_company, c.policy_number, c.status, c.created_at AS claim_date,
               p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.alt_phone, p.email, p.guardian_phone, p.address
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        WHERE LOWER(TRIM(c.hospital_name)) = LOWER(TRIM(:hospital_name))
        ORDER BY c.id DESC
    ");
    $claimsStmt->execute([':hospital_name' => $hospitalName]);
    $claims = $claimsStmt->fetchAll();
} else {
    $claimsStmt = $pdo->query("
        SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
               c.insurance_company, c.policy_number, c.status, c.created_at AS claim_date,
               p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.alt_phone, p.email, p.guardian_phone, p.address
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        ORDER BY c.id DESC
    ");
    $claims = $claimsStmt->fetchAll();
}

// Helper to fetch documents for a claim
function getClaimDocuments(PDO $pdo, int $claimId): array {
    $dStmt = $pdo->prepare("SELECT id, document_type, original_filename, mime_type, file_size FROM patient_documents WHERE claim_id = :claim_id");
    $dStmt->execute([':claim_id' => $claimId]);
    return $dStmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Portal - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; color: #1e293b; }
        .navbar-custom { background-color: #0f172a; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .badge-evidence { background-color: #f59e0b; color: #ffffff; }
        .user-nav-avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; border: 2px solid #ffffff; }
    </style>
</head>
<body>

    <!-- Header Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom py-2 shadow-sm">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold text-white d-flex align-items-center" href="#"><i class="bi bi-hospital-fill text-primary me-2 fs-5"></i>Hospital Officer Portal</a>
            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2 text-white small">
                    <?php 
                    $officerAvatar = $_SESSION['user_profile_image'] ?? ($_SESSION['user_avatar'] ?? null);
                    if (!empty($officerAvatar)): 
                    ?>
                        <img src="<?= htmlspecialchars($officerAvatar) ?>" alt="Avatar" class="user-nav-avatar">
                    <?php else: ?>
                        <i class="bi bi-person-circle fs-4"></i>
                    <?php endif; ?>
                    <div class="d-none d-md-block text-start lh-1">
                        <div class="fw-bold"><?= htmlspecialchars($officerName) ?> <span class="badge bg-primary ms-1" style="font-size: 10px;">OFFICER</span></div>
                        <div class="text-white-50" style="font-size: 11px;"><?= htmlspecialchars($officerEmail) ?></div>
                    </div>
                </div>
                <a href="../auth/setup-2fa.php" class="btn btn-outline-light btn-sm"><i class="bi bi-shield-gear me-1"></i>2FA Settings</a>
                <a href="../public/logout.php" class="btn btn-danger btn-sm fw-bold"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4 my-4">

        <!-- Notification Alerts -->
        <?php if (!empty($officerErrors)): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 shadow-sm">
                <ul class="mb-0 small">
                    <?php foreach ($officerErrors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($officerSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 shadow-sm">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i><?= $officerSuccess ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Officer Profile Card -->
        <div class="card card-custom p-4 bg-white mb-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle">
                        <i class="bi bi-person-vcard display-6"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold mb-1"><?= htmlspecialchars($officerName) ?></h4>
                        <p class="text-muted small mb-0"><i class="bi bi-building me-1"></i><?= htmlspecialchars($profile['hospital_name'] ?? 'General Hospital') ?> | <?= htmlspecialchars($profile['department'] ?? 'Claims') ?></p>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <a href="../patient/index.php" target="_blank" class="btn btn-success fw-bold"><i class="bi bi-plus-circle me-1"></i>Open Patient Form</a>
                    <span class="badge bg-<?= $is2FA ? 'primary' : 'secondary' ?> p-2 align-self-center"><i class="bi bi-shield-lock me-1"></i>2FA <?= $is2FA ? 'Enabled' : 'Disabled' ?></span>
                </div>
            </div>
        </div>

        <?php
        $patientFormUrl = (defined('APP_PUBLIC_URL') && !empty(APP_PUBLIC_URL)) ? APP_PUBLIC_URL . '/patient/index.php' : 'http://localhost/insurancee/patient/index.php';
        $encodedFormUrl = urlencode($patientFormUrl);
        $waText         = urlencode("Dear Patient, please complete your hospital insurance claim submission using this secure link: " . $patientFormUrl);
        ?>

        <!-- SHAREABLE PATIENT CLAIM LINK CARD -->
        <div class="card card-custom p-4 bg-white mb-4 border-start border-4 border-success">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 bg-success bg-opacity-10 text-success rounded-circle fs-3">
                        <i class="bi bi-share-fill"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-1 text-dark"><i class="bi bi-send-fill text-success me-2"></i>Send Claim Link to Public Patient</h5>
                        <p class="text-muted small mb-0">Share this link or QR code with patients. Submissions automatically save directly into your dashboard.</p>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <div class="input-group" style="max-width: 380px;">
                        <span class="input-group-text bg-light"><i class="bi bi-link-45deg text-primary"></i></span>
                        <input type="text" class="form-control font-monospace text-dark fw-semibold" id="patientFormLink" value="<?= htmlspecialchars($patientFormUrl) ?>" readonly>
                        <button class="btn btn-primary fw-bold" type="button" id="copyLinkBtn" onclick="copyPatientLink()">
                            <i class="bi bi-clipboard me-1"></i>Copy Link
                        </button>
                    </div>
                    <a href="https://api.whatsapp.com/send?text=<?= $waText ?>" target="_blank" class="btn btn-outline-success fw-bold">
                        <i class="bi bi-whatsapp me-1"></i>WhatsApp
                    </a>
                    <button type="button" class="btn btn-outline-dark fw-bold" data-bs-toggle="modal" data-bs-target="#qrModal">
                        <i class="bi bi-qr-code me-1"></i>Show QR Code
                    </button>
                </div>
            </div>
        </div>

        <!-- QR CODE MODAL -->
        <div class="modal fade" id="qrModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content text-center p-4">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title fw-bold"><i class="bi bi-qr-code-scan me-2 text-primary"></i>Patient Claim Form QR Code</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body py-3">
                        <p class="text-muted small mb-3">Patients can scan this QR code with any smartphone camera to open and fill out the claim form instantly.</p>
                        <div class="p-3 bg-light d-inline-block rounded-3 border mb-3">
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=<?= $encodedFormUrl ?>" alt="Patient Claim Form QR Code" class="img-fluid" width="220" height="220">
                        </div>
                        <div class="font-monospace small text-primary fw-bold"><?= htmlspecialchars($patientFormUrl) ?></div>
                    </div>
                    <div class="modal-footer border-0 pt-0 justify-content-center">
                        <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- NEW INSURANCE CLAIMS FROM PATIENTS -->
        <div class="card card-custom p-4 bg-white mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-file-earmark-medical me-2 text-primary"></i>SUBMITTED PATIENT CLAIMS (<?= count($claims) ?>)</h5>
                <span class="badge bg-primary fs-6"><?= count($claims) ?> Total Claims</span>
            </div>
            <hr>

            <?php if (empty($claims)): ?>
                <div class="alert alert-info p-4 text-center mb-0">
                    <i class="bi bi-info-circle display-6 me-2"></i>
                    <h5 class="fw-bold mt-2">No Submitted Claims Found</h5>
                    <p class="small text-muted mb-3">Patients can submit insurance claims using the public Patient Claim Form.</p>
                    <a href="../patient/index.php" target="_blank" class="btn btn-outline-primary btn-sm"><i class="bi bi-box-arrow-up-right me-1"></i>Open Patient Form</a>
                </div>
            <?php else: ?>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Claim Ref</th>
                                <th>Patient Details</th>
                                <th>Treatment & Hospital</th>
                                <th>Insurance & Policy</th>
                                <th>Documents & eKYC</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($claims as $c): 
                                $docs = getClaimDocuments($pdo, (int)$c['claim_id']);
                                $isVerified = ($c['status'] === 'VERIFIED');
                            ?>
                                <tr>
                                    <td>
                                        <strong class="text-primary"><?= htmlspecialchars($c['claim_reference']) ?></strong><br>
                                        <small class="text-muted">Pat: <code><?= htmlspecialchars($c['patient_reference']) ?></code></small>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($c['patient_name']) ?></div>
                                        <div class="small text-muted">
                                            <?= htmlspecialchars($c['gender']) ?> | DOB: <?= htmlspecialchars($c['date_of_birth']) ?><br>
                                            <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($c['phone']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($c['hospital_name']) ?></div>
                                        <div class="small text-muted">
                                            Adm: <?= htmlspecialchars($c['admission_date']) ?><br>
                                            <em><?= htmlspecialchars(substr($c['treatment_details'], 0, 50)) ?>...</em>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($c['insurance_company']) ?></div>
                                        <div class="small text-muted">Pol: <code><?= htmlspecialchars($c['policy_number']) ?></code></div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column gap-1">
                                            <?php foreach ($docs as $doc): ?>
                                                <a href="../public/view-patient-doc.php?id=<?= (int)$doc['id'] ?>" target="_blank" class="btn btn-outline-secondary btn-sm py-0 px-2 text-start text-truncate" style="max-width: 180px;">
                                                    <?php if ($doc['document_type'] === 'POLICY_CARD'): ?>
                                                        <i class="bi bi-file-pdf text-danger me-1"></i>Policy Card
                                                    <?php elseif ($doc['document_type'] === 'TREATMENT_DOCUMENT'): ?>
                                                        <i class="bi bi-file-pdf text-danger me-1"></i>Treatment Doc
                                                    <?php else: ?>
                                                        <i class="bi bi-file-image text-primary me-1"></i>eKYC Screenshot
                                                    <?php endif; ?>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($c['status'] === 'OFFICER_VERIFIED'): ?>
                                            <span class="badge bg-info text-dark px-3 py-2 fs-6"><i class="bi bi-shield-check me-1"></i>OFFICER VERIFIED</span>
                                        <?php elseif ($c['status'] === 'APPROVED'): ?>
                                            <span class="badge bg-success px-3 py-2 fs-6"><i class="bi bi-check-circle-fill me-1"></i>FINAL APPROVED</span>
                                        <?php elseif ($c['status'] === 'REJECTED'): ?>
                                            <span class="badge bg-danger px-3 py-2 fs-6"><i class="bi bi-x-circle-fill me-1"></i>REJECTED</span>
                                        <?php else: ?>
                                            <span class="badge badge-evidence px-3 py-2 font-monospace"><?= htmlspecialchars($c['status']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <a href="verify-patient-form.php?id=<?= (int)$c['claim_id'] ?>" class="btn btn-sm btn-<?= $isVerified ? 'outline-success' : 'success' ?> fw-bold px-3">
                                                <?php if ($isVerified): ?>
                                                    <i class="bi bi-patch-check-fill me-1"></i>Verified (View Form)
                                                <?php else: ?>
                                                    <i class="bi bi-file-earmark-check me-1"></i>Verify Document
                                                <?php endif; ?>
                                            </a>
                                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#claimModal<?= (int)$c['claim_id'] ?>">
                                                <i class="bi bi-eye me-1"></i>Quick View
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Claim Details Modal -->
                                <div class="modal fade" id="claimModal<?= (int)$c['claim_id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header bg-dark text-white">
                                                <h5 class="modal-title fw-bold"><i class="bi bi-file-earmark-medical me-2"></i>Claim Details - <?= htmlspecialchars($c['claim_reference']) ?></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body p-4">

                                                <?php if ($isVerified): ?>
                                                    <div class="alert alert-success d-flex align-items-center mb-4">
                                                        <i class="bi bi-patch-check-fill fs-2 me-3"></i>
                                                        <div>
                                                            <strong class="fs-6">Verified Patient Document & Claim</strong><br>
                                                            <small>This patient document and insurance claim has been verified and approved by the Hospital Officer.</small>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php
                                                    $mAge = 0;
                                                    if (!empty($c['date_of_birth'])) {
                                                        try {
                                                            $dobO = new DateTime($c['date_of_birth']);
                                                            $todO = new DateTime('today');
                                                            $mAge = $dobO->diff($todO)->y;
                                                        } catch (Exception $e) { $mAge = 0; }
                                                    }
                                                    $mIsMinor = ($mAge < 18);
                                                ?>
                                                <!-- Patient Section -->
                                                <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="bi bi-person me-1"></i>PATIENT DETAILS</h6>
                                                <div class="row g-3 mb-4">
                                                    <div class="col-md-6"><strong>Patient Reference:</strong> <code><?= htmlspecialchars($c['patient_reference']) ?></code></div>
                                                    <div class="col-md-6"><strong>Full Name:</strong> <?= htmlspecialchars($c['patient_name']) ?></div>
                                                    <div class="col-md-6"><strong>Date of Birth & Age:</strong> <?= htmlspecialchars($c['date_of_birth']) ?> <span class="badge bg-<?= $mIsMinor ? 'warning text-dark' : 'success' ?> ms-1">Age: <?= $mAge ?> Years (<?= $mIsMinor ? 'Minor' : 'Adult' ?>)</span></div>
                                                    <div class="col-md-6"><strong>Gender:</strong> <?= htmlspecialchars($c['gender']) ?></div>
                                                    <div class="col-md-6"><strong>Email Address:</strong> <?= htmlspecialchars($c['email'] ?? 'N/A') ?></div>
                                                    <?php if ($mIsMinor): ?>
                                                        <div class="col-md-6 text-danger"><strong>Parent / Guardian:</strong> <?= htmlspecialchars($c['guardian_name'] ?? 'N/A') ?> (<?= htmlspecialchars($c['guardian_phone'] ?? 'N/A') ?>)</div>
                                                    <?php else: ?>
                                                        <div class="col-md-6"><strong>Phone Number:</strong> <?= htmlspecialchars($c['phone']) ?> <?= !empty($c['alt_phone']) ? '| Alt: ' . htmlspecialchars($c['alt_phone']) : '' ?></div>
                                                    <?php endif; ?>
                                                    <div class="col-12"><strong>Address:</strong> <?= htmlspecialchars($c['address']) ?></div>
                                                </div>

                                                <!-- Treatment Section -->
                                                <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="bi bi-hospital me-1"></i>TREATMENT DETAILS</h6>
                                                <div class="row g-3 mb-4">
                                                    <div class="col-md-6"><strong>Hospital Name:</strong> <?= htmlspecialchars($c['hospital_name']) ?></div>
                                                    <div class="col-md-6"><strong>Admission Date:</strong> <?= htmlspecialchars($c['admission_date']) ?></div>
                                                    <div class="col-12"><strong>Treatment Details:</strong> <?= htmlspecialchars($c['treatment_details']) ?></div>
                                                </div>

                                                <!-- Insurance Section -->
                                                <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="bi bi-shield-check me-1"></i>INSURANCE DETAILS</h6>
                                                <div class="row g-3 mb-4">
                                                    <div class="col-md-6"><strong>Insurance Company:</strong> <?= htmlspecialchars($c['insurance_company']) ?></div>
                                                    <div class="col-md-6"><strong>Policy Number:</strong> <code><?= htmlspecialchars($c['policy_number']) ?></code></div>
                                                </div>

                                                <!-- Documents Section -->
                                                <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="bi bi-paperclip me-1"></i>ATTACHED DOCUMENTS & eKYC</h6>
                                                <div class="d-flex flex-wrap gap-2">
                                                    <?php foreach ($docs as $doc): ?>
                                                        <a href="../public/view-patient-doc.php?id=<?= (int)$doc['id'] ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                                                            <i class="bi bi-file-earmark me-1"></i><?= htmlspecialchars($doc['document_type']) ?> (<?= htmlspecialchars($doc['original_filename']) ?>)
                                                        </a>
                                                    <?php endforeach; ?>
                                                </div>

                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <a href="verify-patient-form.php?id=<?= (int)$c['claim_id'] ?>" class="btn btn-success fw-bold">
                                                    <i class="bi bi-file-earmark-check me-1"></i>Open Patient Form & Verify
                                                </a>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    function copyPatientLink() {
        const input = document.getElementById('patientFormLink');
        input.select();
        input.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(input.value);
        
        const btn = document.getElementById('copyLinkBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check-lg me-1"></i>Copied!';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-success');
        
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.remove('btn-success');
            btn.classList.add('btn-primary');
        }, 2500);
    }
    </script>
    <!-- Session Keep-Alive Heartbeat (Runs every 5 minutes to guarantee persistent lifelong session) -->
    <script>
    setInterval(() => {
        fetch('../public/keep-alive.php')
            .then(res => res.json())
            .then(data => {
                if (data.status === 'ok') {
                    console.log('[Session Keep-Alive] Active session verified at ' + new Date().toLocaleTimeString());
                }
            })
            .catch(err => console.warn('[Session Keep-Alive] Ping warning:', err));
    }, 300000);
    </script>
</body>
</html>
