<?php
/**
 * Patient Claim Document Verification Controller
 * 
 * Handles officer document verification, updates claim status to 'VERIFIED' or 'REJECTED', and logs audit events.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

require_once __DIR__ . '/../config/mail.php';

requireOfficer();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit();
}

$csrfToken     = $_POST[CSRF_TOKEN_NAME] ?? '';
$claimId       = (int)($_POST['claim_id'] ?? 0);
$action        = $_POST['action'] ?? 'verify';
$redirectToForm= !empty($_POST['redirect_to_form']);

if (!validateCSRFToken($csrfToken)) {
    if ($redirectToForm) {
        $_SESSION['verify_error'] = "Security validation failed. Invalid CSRF token.";
        header("Location: verify-patient-form.php?id=$claimId");
    } else {
        $_SESSION['officer_errors'] = ["Security validation failed. Invalid CSRF token."];
        header("Location: dashboard.php");
    }
    exit();
}

if ($claimId <= 0) {
    $_SESSION['officer_errors'] = ["Invalid Claim ID specified."];
    header("Location: dashboard.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // Fetch claim reference, hospital name, and patient email
    $stmt = $pdo->prepare("
        SELECT c.claim_reference, c.hospital_name, c.status, p.full_name AS patient_name, p.email
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $claimId]);
    $claim = $stmt->fetch();

    if (!$claim) {
        throw new Exception("Claim record #$claimId not found.");
    }

    $officerId   = (int)$_SESSION['user_id'];
    $officerName = $_SESSION['user_name'] ?? 'Officer';

    // Enforce Hospital Authorization Guard
    $offStmt = $pdo->prepare("SELECT hospital_name FROM users WHERE id = :id");
    $offStmt->execute([':id' => $officerId]);
    $offProfile = $offStmt->fetch();
    $officerHospital = $offProfile['hospital_name'] ?? '';

    if (!empty($officerHospital) && strtolower(trim($claim['hospital_name'])) !== strtolower(trim($officerHospital))) {
        throw new Exception("Access Denied: Claim #{$claim['claim_reference']} belongs to {$claim['hospital_name']} and cannot be verified by $officerHospital staff.");
    }

    $newStatus    = ($action === 'reject') ? 'REJECTED' : 'OFFICER_VERIFIED';
    $officerNotes = trim($_POST['officer_notes'] ?? '');

    // Update claim status and officer remarks in MySQL
    $updateStmt = $pdo->prepare("UPDATE claims SET status = :status, officer_notes = :notes, updated_at = NOW() WHERE id = :id");
    $updateStmt->execute([':status' => $newStatus, ':notes' => $officerNotes, ':id' => $claimId]);

    $officerId   = (int)$_SESSION['user_id'];
    $officerName = $_SESSION['user_name'] ?? 'Officer';

    logAuditEvent($officerId, 'PATIENT_CLAIM_' . $newStatus, "Patient Claim {$claim['claim_reference']} set to $newStatus by Hospital Officer $officerName");

    // Send verification email notification to patient's registered email address (or official hospital mail)
    $targetEmail = !empty($claim['email']) ? $claim['email'] : (getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in');
    $emailSentNote = "";
    
    $mailSent = sendClaimStatusNotificationEmail($targetEmail, $claim['patient_name'], $claim['claim_reference'], $newStatus, $officerNotes);
    if ($mailSent) {
        $emailSentNote = " <br><span class='badge bg-success text-white mt-1'>✓ Email Delivered:</span> Status notification sent to <strong>" . htmlspecialchars($targetEmail) . "</strong>.";
    } else {
        $emailSentNote = " <br><small class='text-muted'><i class='bi bi-envelope-check me-1'></i>Notification queued for <strong>" . htmlspecialchars($targetEmail) . "</strong> (Configure live Gmail SMTP in <code>.env</code> to deliver).</small>";
    }

    if ($newStatus === 'REJECTED') {
        if ($redirectToForm) {
            $_SESSION['verify_success'] = "Claim <strong>" . htmlspecialchars($claim['claim_reference']) . "</strong> has been <strong>REJECTED</strong> by the Hospital Officer." . $emailSentNote;
            header("Location: verify-patient-form.php?id=$claimId");
        } else {
            $_SESSION['officer_success'] = "Patient Claim <strong>" . htmlspecialchars($claim['claim_reference']) . "</strong> has been <strong>REJECTED</strong> by the Hospital Officer." . $emailSentNote;
            header("Location: dashboard.php");
        }
    } else {
        if ($redirectToForm) {
            $_SESSION['verify_success'] = "Claim <strong>" . htmlspecialchars($claim['claim_reference']) . "</strong> documents have been <strong>VERIFIED</strong> and forwarded to the Admin Dashboard for Final eSign Approval!" . $emailSentNote;
            header("Location: verify-patient-form.php?id=$claimId");
        } else {
            $_SESSION['officer_success'] = "Patient Document & Claim <strong>" . htmlspecialchars($claim['claim_reference']) . "</strong> has been <strong>OFFICER VERIFIED</strong> and forwarded to the Admin Dashboard for Final Approval!" . $emailSentNote;
            header("Location: dashboard.php");
        }
    }
    exit();

} catch (Exception $e) {
    if ($redirectToForm) {
        $_SESSION['verify_error'] = "Verification failed: " . $e->getMessage();
        header("Location: verify-patient-form.php?id=$claimId");
    } else {
        $_SESSION['officer_errors'] = ["Verification failed: " . $e->getMessage()];
        header("Location: dashboard.php");
    }
    exit();
}
