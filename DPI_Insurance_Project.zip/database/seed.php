<?php
/**
 * Test Account Seeder & Rate Limit Reset Controller
 * 
 * Clears login lockouts and seeds standard test accounts for Admin and Officer roles.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

try {
    $pdo = getDBConnection();

    // 1. Clear failed login attempts / lockouts
    $pdo->exec("TRUNCATE TABLE login_attempts");

    // 2. Seed Admin Account if not exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminUser = $stmt->fetch();
    if (!$adminUser) {
        $adminPass = password_hash('AdminPass123!', PASSWORD_DEFAULT);
        $insAdmin = $pdo->prepare("
            INSERT INTO users (role, full_name, username, hospital_name, department, email, password_hash, email_verified, status, created_at)
            VALUES ('admin', 'System Administrator', 'admin', 'City Central Hospital', 'Administration', '11239a107@kanchiuniv.ac.in', :pass, 1, 'active', NOW())
        ");
        $insAdmin->execute([':pass' => $adminPass]);
        echo "<p style='color: green;'>Admin account <code>admin</code> / <code>11239a107@kanchiuniv.ac.in</code> seeded successfully.</p>";
    } else {
        $pdo->prepare("UPDATE users SET email = '11239a107@kanchiuniv.ac.in', role = 'admin', department = 'Administration' WHERE id = :id")->execute([':id' => $adminUser['id']]);
    }

    // 3. Seed/Update Officer Account
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = '11239a089@kanchiuniv.ac.in' OR username = 'sarah_officer'");
    $stmt->execute();
    $officerUser = $stmt->fetch();
    if (!$officerUser) {
        $officerPass = password_hash('OfficerPass123!', PASSWORD_DEFAULT);
        $insOfficer = $pdo->prepare("
            INSERT INTO users (role, full_name, username, hospital_name, department, phone, email, password_hash, email_verified, status, created_at)
            VALUES ('officer', 'Officer Sarah Connor', 'sarah_officer', 'City Central Hospital', 'Claims & Billing', '+91 9876543210', '11239a089@kanchiuniv.ac.in', :pass, 1, 'active', NOW())
        ");
        $insOfficer->execute([':pass' => $officerPass]);
        echo "<p style='color: green;'>Officer account <code>sarah_officer</code> / <code>11239a089@kanchiuniv.ac.in</code> seeded successfully.</p>";
    } else {
        $pdo->prepare("UPDATE users SET email = '11239a089@kanchiuniv.ac.in', username = 'sarah_officer', full_name = 'Officer Sarah Connor', role = 'officer', department = 'Claims & Billing' WHERE id = :id")->execute([':id' => $officerUser['id']]);
    }

    // 4. Seed/Update Test Officer Account (username: test_officer)
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = 'test_officer' OR email = 'test_officer@hospital.com'");
    $stmt->execute();
    $testOfficer = $stmt->fetch();
    $officerPass = password_hash('OfficerPass123!', PASSWORD_DEFAULT);
    if (!$testOfficer) {
        $insTestOfficer = $pdo->prepare("
            INSERT INTO users (role, full_name, username, hospital_name, department, phone, email, password_hash, email_verified, status, two_factor_enabled, created_at)
            VALUES ('officer', 'Test Verification Officer', 'test_officer', 'City General Hospital', 'Claims & Billing', '+91 9876543211', 'test_officer@hospital.com', :pass, 1, 'active', 0, NOW())
        ");
        $insTestOfficer->execute([':pass' => $officerPass]);
        echo "<p style='color: green;'>Officer account <code>test_officer</code> seeded successfully.</p>";
    } else {
        $pdo->prepare("UPDATE users SET hospital_name = 'City General Hospital', password_hash = :pass, email_verified = 1, status = 'active', two_factor_enabled = 0 WHERE id = :id")
            ->execute([':pass' => $officerPass, ':id' => $testOfficer['id']]);
    }

    echo "<h3 style='color: green;'>Database Seeding & Rate Limit Reset Completed!</h3>";

} catch (Exception $e) {
    echo "<h3 style='color: red;'>Error Seeding Database: " . htmlspecialchars($e->getMessage()) . "</h3>";
}
