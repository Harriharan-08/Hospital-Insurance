-- ====================================================================
-- Hospital Insurance Claim Authentication System
-- Master Database Schema (MySQL 8.x / MariaDB compatible)
-- Streamlined 2-Role System + Patient Claim Management Engine
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `hospital_insurance_db`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `hospital_insurance_db`;

-- Disable foreign key checks during DDL recreation
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------------------
-- Table 1: users
-- Master authentication table (Roles: admin, officer).
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `role` ENUM('admin', 'officer') NOT NULL DEFAULT 'officer',
    `full_name` VARCHAR(150) NOT NULL,
    `first_name` VARCHAR(100) NULL,
    `last_name` VARCHAR(100) NULL,
    `username` VARCHAR(60) NOT NULL,
    `hospital_name` VARCHAR(150) NULL,
    `department` VARCHAR(100) NULL,
    `phone` VARCHAR(30) NULL,
    `profile_image` VARCHAR(500) NULL,
    `provider` VARCHAR(50) NOT NULL DEFAULT 'local',
    `provider_user_id` VARCHAR(191) NULL,
    `email` VARCHAR(191) NOT NULL,
    `password_hash` VARCHAR(255) NULL,
    `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
    `two_factor_enabled` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('pending', 'active', 'blocked') NOT NULL DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login` DATETIME NULL,
    
    CONSTRAINT `uq_users_username` UNIQUE (`username`),
    CONSTRAINT `uq_users_email` UNIQUE (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `idx_users_role` ON `users` (`role`);
CREATE INDEX `idx_users_status` ON `users` (`status`);
CREATE INDEX `idx_users_provider` ON `users` (`provider`, `provider_user_id`);

-- --------------------------------------------------------------------
-- Table 2: email_otps
-- Stores SHA-256 hashes of email verification OTPs.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `email_otps`;
CREATE TABLE `email_otps` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `otp_hash` VARCHAR(255) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
    `max_attempts` INT UNSIGNED NOT NULL DEFAULT 5,
    `resend_cooldown_until` DATETIME NULL,
    `is_used` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT `fk_email_otps_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 3: password_resets
-- Stores secure hashes of password reset tokens.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `token_hash` VARCHAR(255) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT `uq_password_resets_token_hash` UNIQUE (`token_hash`),
    CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 4: two_factor_auth
-- Stores TOTP secrets and 2FA enrollment status.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `two_factor_auth`;
CREATE TABLE `two_factor_auth` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `secret` VARCHAR(255) NOT NULL,
    `enabled` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT `uq_two_factor_auth_user` UNIQUE (`user_id`),
    CONSTRAINT `fk_two_factor_auth_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 5: audit_logs
-- System security audit trail.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NULL,
    `event_type` VARCHAR(100) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `user_agent` TEXT NULL,
    `details` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT `fk_audit_logs_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 6: login_attempts
-- Rate-limiting tracker for authentication endpoint.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `identifier` VARCHAR(191) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `attempt_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `success` TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 7: patients
-- Stores patient demographical details and PAT- references.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `patient_reference` VARCHAR(50) NOT NULL,
    `full_name` VARCHAR(150) NOT NULL,
    `guardian_name` VARCHAR(150) NULL,
    `date_of_birth` DATE NOT NULL,
    `gender` ENUM('Male', 'Female', 'Other') NOT NULL,
    `phone` VARCHAR(30) NULL,
    `alt_phone` VARCHAR(30) NULL,
    `email` VARCHAR(255) NULL,
    `guardian_phone` VARCHAR(30) NULL,
    `address` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT `uq_patients_reference` UNIQUE (`patient_reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 8: claims
-- Stores insurance claim details and CLM- references.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `claims`;
CREATE TABLE `claims` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `claim_reference` VARCHAR(50) NOT NULL,
    `patient_id` BIGINT UNSIGNED NOT NULL,
    `hospital_name` VARCHAR(150) NOT NULL,
    `admission_date` DATE NOT NULL,
    `treatment_details` TEXT NOT NULL,
    `insurance_company` VARCHAR(150) NOT NULL,
    `policy_number` VARCHAR(100) NOT NULL,
    `policy_valid_date` DATE NULL,
    `status` VARCHAR(50) NOT NULL DEFAULT 'EVIDENCE_SUBMITTED',
    `officer_notes` TEXT NULL,
    `ekyc_data` LONGTEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT `uq_claims_reference` UNIQUE (`claim_reference`),
    CONSTRAINT `fk_claims_patient` FOREIGN KEY (`patient_id`)
        REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `idx_claims_hospital` ON `claims` (`hospital_name`);
CREATE INDEX `idx_claims_status` ON `claims` (`status`);

-- --------------------------------------------------------------------
-- Table 9: patient_documents
-- Stores Policy Card, Treatment Document, and eKYC Screenshot metadata.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `patient_documents`;
CREATE TABLE `patient_documents` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `claim_id` BIGINT UNSIGNED NOT NULL,
    `document_type` ENUM('POLICY_CARD', 'TREATMENT_DOCUMENT', 'EKYC_SCREENSHOT') NOT NULL,
    `original_filename` VARCHAR(255) NOT NULL,
    `stored_filename` VARCHAR(255) NOT NULL,
    `mime_type` VARCHAR(100) NOT NULL,
    `file_size` INT UNSIGNED NOT NULL,
    `storage_path` VARCHAR(500) NOT NULL,
    `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT `fk_patient_documents_claim` FOREIGN KEY (`claim_id`)
        REFERENCES `claims` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table 10: esign_transactions
-- Stores eSign / emSign transactions and status tracking.
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `esign_transactions`;
CREATE TABLE `esign_transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    `claim_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,

    `transaction_id` VARCHAR(255) NULL,
    `document_id` VARCHAR(255) NULL,

    `document_name` VARCHAR(255) NOT NULL,
    `document_hash` VARCHAR(255) NULL,

    `status` ENUM(
        'PENDING',
        'INITIATED',
        'SIGNED',
        'FAILED',
        'CANCELLED'
    ) NOT NULL DEFAULT 'PENDING',

    `signed_document_path` VARCHAR(500) NULL,
    `provider_response` TEXT NULL,
    `error_message` TEXT NULL,

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT `fk_esign_transactions_claim`
        FOREIGN KEY (`claim_id`)
        REFERENCES `claims` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT `fk_esign_transactions_user`
        FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE

) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `idx_esign_claim`
ON `esign_transactions` (`claim_id`);

CREATE INDEX `idx_esign_transaction`
ON `esign_transactions` (`transaction_id`);

CREATE INDEX `idx_esign_status`
ON `esign_transactions` (`status`);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
