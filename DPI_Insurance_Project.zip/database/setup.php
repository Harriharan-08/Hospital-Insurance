<?php
/**
 * Database Setup & Initialization Controller
 * 
 * Executes database/schema.sql to create database and 6 authentication tables.
 */

require_once __DIR__ . '/../config/security.php';

$host = '127.0.0.1';
$port = '3306';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $schemaSql = file_get_contents(__DIR__ . '/schema.sql');
    if (!$schemaSql) {
        throw new Exception("Unable to read database/schema.sql file.");
    }

    $pdo->exec($schemaSql);

    echo "<h3 style='color: green;'>Success! Database `hospital_insurance_db` and tables created/updated successfully.</h3>";
    echo "<ul>";
    echo "<li>Table <code>users</code>: Created/Updated (Roles: admin, officer)</li>";
    echo "<li>Table <code>email_otps</code>: Created</li>";
    echo "<li>Table <code>password_resets</code>: Created</li>";
    echo "<li>Table <code>two_factor_auth</code>: Created</li>";
    echo "<li>Table <code>audit_logs</code>: Created</li>";
    echo "<li>Table <code>login_attempts</code>: Created</li>";
    echo "<li>Table <code>patients</code>: Created</li>";
    echo "<li>Table <code>claims</code>: Created</li>";
    echo "<li>Table <code>patient_documents</code>: Created</li>";
    echo "<li>Table <code>esign_transactions</code>: Created</li>";
    echo "</ul>";

} catch (Exception $e) {
    echo "<h3 style='color: red;'>Error Setting Up Database:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
