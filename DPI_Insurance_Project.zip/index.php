<?php
/**
 * Application Entry Point Redirector
 * Directs visitors arriving at root domain to the Patient Portal
 */
header("Location: /patient/index.php");
exit();
