<?php
/**
 * Insurance Administrator Control Portal (Phase 16)
 * 
 * Enforces requireAdmin() backend guard.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

requireAdmin();

$pdo = getDBConnection();
$adminName  = $_SESSION['user_name'] ?? 'Admin';
$adminEmail = $_SESSION['user_email'] ?? '';
$is2FA      = $_SESSION['user_2fa_enabled'] ?? false;

// Fetch all registered users
$usersStmt = $pdo->query("SELECT id, role, full_name, username, hospital_name, department, email, email_verified, two_factor_enabled, status, created_at FROM users ORDER BY (role = 'admin') DESC, id ASC");
$users = $usersStmt->fetchAll();

// Fetch latest audit logs
$auditStmt = $pdo->query("
    SELECT a.id, a.event_type, a.ip_address, a.details, a.created_at, u.username 
    FROM audit_logs a 
    LEFT JOIN users u ON u.id = a.user_id 
    ORDER BY a.id DESC LIMIT 15
");
$auditLogs = $auditStmt->fetchAll();

// Fetch ONLY officer-verified patient claims for Admin Final Approval
$adminClaimsStmt = $pdo->query("
    SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
           c.insurance_company, c.policy_number, c.status, c.officer_notes, c.created_at AS claim_date,
           p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.alt_phone, p.email, p.guardian_phone, p.address
    FROM claims c
    JOIN patients p ON p.id = c.patient_id
    WHERE c.status IN ('OFFICER_VERIFIED', 'APPROVED', 'REJECTED')
    ORDER BY c.id DESC
");
$adminClaims = $adminClaimsStmt->fetchAll();

$adminSuccess = $_SESSION['admin_success'] ?? null;
$adminErrors  = $_SESSION['admin_errors'] ?? [];
unset($_SESSION['admin_success']);
unset($_SESSION['admin_errors']);

// Helper to fetch documents for a claim
function getClaimDocs(PDO $pdo, int $claimId): array {
    $dStmt = $pdo->prepare("SELECT id, document_type, original_filename, mime_type, file_size FROM patient_documents WHERE claim_id = :claim_id");
    $dStmt->execute([':claim_id' => $claimId]);
    return $dStmt->fetchAll();
}

$adminAvatar   = $_SESSION['user_profile_image'] ?? ($_SESSION['user_avatar'] ?? null);
$adminProvider = $_SESSION['provider'] ?? 'local';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; color: #1e293b; }
        .navbar-custom { background-color: #0f172a; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .user-nav-avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; border: 2px solid #ffffff; }
    </style>
</head>
<body>

    <!-- Header Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom py-2 shadow-sm">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold text-white d-flex align-items-center" href="#"><i class="bi bi-shield-lock-fill text-danger me-2 fs-5"></i>Insurance Admin Dashboard</a>
            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2 text-white small">
                    <?php if (!empty($adminAvatar)): ?>
                        <img src="<?= htmlspecialchars($adminAvatar) ?>" alt="Avatar" class="user-nav-avatar">
                    <?php else: ?>
                        <i class="bi bi-person-circle fs-4"></i>
                    <?php endif; ?>
                    <div class="d-none d-md-block text-start lh-1">
                        <div class="fw-bold"><?= htmlspecialchars($adminName) ?> <span class="badge bg-danger ms-1" style="font-size: 10px;">ADMIN</span></div>
                        <div class="text-white-50" style="font-size: 11px;"><?= htmlspecialchars($adminEmail) ?></div>
                    </div>
                </div>
                <a href="../auth/setup-2fa.php" class="btn btn-outline-light btn-sm"><i class="bi bi-shield-gear me-1"></i>2FA Settings</a>
                <a href="../public/logout.php" class="btn btn-danger btn-sm fw-bold"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4 my-4">

        <!-- Notification Alerts -->
        <?php if (!empty($adminErrors)): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 shadow-sm">
                <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Error:</h6>
                <ul class="mb-0 small ps-3">
                    <?php foreach ($adminErrors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($adminSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 shadow-sm">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i><?= $adminSuccess ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- PATIENT CLAIMS FOR ADMIN FINAL APPROVAL TABLE -->
        <div class="card card-custom p-4 bg-white mb-4 border-start border-4 border-danger shadow-sm">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h5 class="fw-bold mb-1 text-dark"><i class="bi bi-patch-check-fill text-danger me-2"></i>Patient Claims Pending Admin Final Approval</h5>
                    <p class="text-muted small mb-0">Hospital Officers verify patient details & documents. Admin performs the final claim approval or rejection.</p>
                </div>
                <span class="badge bg-danger fs-6 px-3 py-2"><i class="bi bi-shield-check me-1"></i><?= count($adminClaims) ?> Claims Total</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Claim Ref</th>
                            <th>Patient Info</th>
                            <th>Hospital & Diagnosis</th>
                            <th>Insurance & Policy</th>
                            <th>Documents</th>
                            <th>Officer Remarks</th>
                            <th>Status</th>
                            <th>Admin Final Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($adminClaims)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No officer-verified patient claims pending admin approval.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($adminClaims as $ac): 
                                $acDocs = getClaimDocs($pdo, (int)$ac['claim_id']);
                            ?>
                                <tr>
                                    <td>
                                        <strong class="text-primary"><?= htmlspecialchars($ac['claim_reference']) ?></strong><br>
                                        <small class="text-muted">Pat: <code><?= htmlspecialchars($ac['patient_reference']) ?></code></small>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($ac['patient_name']) ?></div>
                                        <div class="small text-muted">
                                            <?= htmlspecialchars($ac['gender']) ?> | DOB: <?= htmlspecialchars($ac['date_of_birth']) ?><br>
                                            <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($ac['phone'] ?: $ac['guardian_phone']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($ac['hospital_name']) ?></div>
                                        <div class="small text-muted">
                                            Adm: <?= htmlspecialchars($ac['admission_date']) ?><br>
                                            <em><?= htmlspecialchars(substr($ac['treatment_details'], 0, 45)) ?>...</em>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($ac['insurance_company']) ?></div>
                                        <div class="small text-muted">Pol: <code><?= htmlspecialchars($ac['policy_number']) ?></code></div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column gap-1">
                                            <?php foreach ($acDocs as $doc): ?>
                                                <a href="../public/view-patient-doc.php?id=<?= (int)$doc['id'] ?>" target="_blank" class="btn btn-outline-secondary btn-sm py-0 px-2 text-start text-truncate" style="max-width: 170px;">
                                                    <i class="bi bi-file-pdf text-danger me-1"></i><?= htmlspecialchars($doc['document_type']) ?>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td class="small text-muted" style="max-width: 200px;">
                                        <?= htmlspecialchars($ac['officer_notes'] ?: 'No officer remarks entered.') ?>
                                    </td>
                                    <td>
                                        <?php if ($ac['status'] === 'OFFICER_VERIFIED'): ?>
                                            <span class="badge bg-info text-dark px-3 py-2 fs-6"><i class="bi bi-shield-check me-1"></i>OFFICER VERIFIED</span>
                                        <?php elseif ($ac['status'] === 'APPROVED'): ?>
                                            <span class="badge bg-success px-3 py-2 fs-6"><i class="bi bi-check-circle-fill me-1"></i>APPROVED</span>
                                        <?php elseif ($ac['status'] === 'REJECTED' || $ac['status'] === 'OFFICER_REJECTED'): ?>
                                            <span class="badge bg-danger px-3 py-2 fs-6"><i class="bi bi-x-circle-fill me-1"></i>OFFICER REJECTED</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark px-3 py-2 font-monospace"><?= htmlspecialchars($ac['status']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column gap-1">
                                            <?php if ($ac['status'] === 'APPROVED'): ?>
                                                <a href="view-patient-form.php?id=<?= (int)$ac['claim_id'] ?>" class="btn btn-sm btn-outline-primary fw-bold text-nowrap">
                                                    <i class="bi bi-file-earmark-text me-1"></i>Inspect Form
                                                </a>
                                                <a href="../public/view-approval-letter.php?id=<?= (int)$ac['claim_id'] ?>" target="_blank" class="btn btn-sm btn-success fw-bold text-nowrap">
                                                    <i class="bi bi-file-earmark-medical-fill me-1"></i>View Signed Letter
                                                </a>
                                            <?php elseif ($ac['status'] === 'REJECTED' || $ac['status'] === 'OFFICER_REJECTED'): ?>
                                                <a href="view-patient-form.php?id=<?= (int)$ac['claim_id'] ?>" class="btn btn-sm btn-secondary fw-bold text-nowrap">
                                                    <i class="bi bi-file-earmark-text me-1"></i>Inspect Form
                                                </a>
                                                <span class="badge bg-danger-subtle text-danger border border-danger fw-bold py-1 px-2 mt-1">
                                                    <i class="bi bi-x-circle-fill me-1"></i>Officer Rejected
                                                </span>
                                            <?php else: ?>
                                                <a href="view-patient-form.php?id=<?= (int)$ac['claim_id'] ?>" class="btn btn-sm btn-primary fw-bold text-nowrap">
                                                    <i class="bi bi-file-earmark-text me-1"></i>Inspect Form & Approve
                                                </a>
                                                <div class="d-flex gap-1 mt-1">
                                                    <a href="view-patient-form.php?id=<?= (int)$ac['claim_id'] ?>&action=esign#admin-action-section" class="btn btn-outline-success btn-sm fw-bold w-50">
                                                        <i class="bi bi-pen-fill me-1"></i>eSign
                                                    </a>
                                                    <a href="view-patient-form.php?id=<?= (int)$ac['claim_id'] ?>&action=reject#admin-action-section" class="btn btn-outline-danger btn-sm fw-bold w-50">
                                                        <i class="bi bi-x-lg me-1"></i>Reject
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <?php if ($ac['status'] === 'OFFICER_VERIFIED'): ?>
                                        <!-- eSIGN APPROVE MODAL -->
                                        <div class="modal fade text-start" id="adminApproveModal<?= (int)$ac['claim_id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
                                                    <div class="modal-header bg-dark text-white p-4">
                                                        <div>
                                                            <h5 class="modal-title fw-bold"><i class="bi bi-shield-lock-fill text-success me-2"></i>emSigner (eMudhra) Gateway</h5>
                                                            <p class="small text-muted mb-0">Authorize Final Approval for Claim #<?= htmlspecialchars($ac['claim_reference']) ?></p>
                                                        </div>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form action="approve-claim.php" method="POST">
                                                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                                                        <input type="hidden" name="claim_id" value="<?= (int)$ac['claim_id'] ?>">
                                                        <input type="hidden" name="action" value="approve">

                                                        <div class="modal-body p-4">
                                                            <div class="bg-light p-3 rounded-3 border mb-3 small">
                                                                <div><strong>Patient:</strong> <?= htmlspecialchars($ac['patient_name']) ?></div>
                                                                <div><strong>Hospital:</strong> <?= htmlspecialchars($ac['hospital_name']) ?></div>
                                                                <div><strong>Insurance:</strong> <?= htmlspecialchars($ac['insurance_company']) ?></div>
                                                            </div>
                                                            
                                                            <div class="mb-3">
                                                                <label for="approved_amount_<?= (int)$ac['claim_id'] ?>" class="form-label fw-bold text-success small mb-1">
                                                                    <i class="bi bi-currency-rupee me-1"></i>Approved Claim Amount
                                                                </label>
                                                                <input type="text" class="form-control form-control-sm fw-bold text-dark" id="approved_amount_<?= (int)$ac['claim_id'] ?>" name="approved_amount" value="₹1,50,000" placeholder="e.g. ₹1,50,000" required>
                                                            </div>

                                                            <div class="p-3 mb-3 bg-white border border-success rounded-3 small">
                                                                <div class="d-flex justify-content-between align-items-center mb-1">
                                                                    <label for="emsigner_authtoken_<?= (int)$ac['claim_id'] ?>" class="form-label fw-bold text-success mb-0">
                                                                        <i class="bi bi-key-fill me-1"></i>Manage AuthToken Key
                                                                    </label>
                                                                    <span class="badge bg-success-subtle text-success border border-success">
                                                                        <i class="bi bi-check-circle-fill me-1"></i>Verified
                                                                    </span>
                                                                </div>
                                                                <input type="text" class="form-control form-control-sm font-monospace fw-bold text-dark mb-2" id="emsigner_authtoken_<?= (int)$ac['claim_id'] ?>" name="emsigner_authtoken" value="<?= htmlspecialchars(EMSIGNER_AUTH_TOKEN) ?>" required>
                                                                <div class="p-2 bg-light rounded border text-center mb-2">
                                                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                                                        <span class="fw-bold text-dark" style="font-size: 11px;">Attached DSC Signature:</span>
                                                                        <span class="badge bg-success" style="font-size: 10px;">Harriharan S</span>
                                                                    </div>
                                                                    <img src="../public/assets/signatures/harriharan_signature.png" alt="Signature of Harriharan S" style="max-height: 40px; max-width: 180px; object-fit: contain;">
                                                                </div>
                                                                <div class="text-muted" style="font-size: 11px;">Provider: eMudhra emSigner PKI Gateway (SHA256withRSA)</div>
                                                            </div>
                                                            <div class="mb-2">
                                                                <label for="admin_notes_app<?= (int)$ac['claim_id'] ?>" class="form-label fw-bold small">Approval Remarks (Optional)</label>
                                                                <input type="text" class="form-control form-control-sm" id="admin_notes_app<?= (int)$ac['claim_id'] ?>" name="admin_notes" placeholder="e.g. Approved after verifying officer notes.">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer bg-light p-3">
                                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-success fw-bold px-3">
                                                                <i class="bi bi-shield-check me-1"></i>APPROVE & SIGN LETTER
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- REJECT MODAL -->
                                        <div class="modal fade text-start" id="adminRejectModal<?= (int)$ac['claim_id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
                                                    <div class="modal-header bg-danger text-white p-4">
                                                        <h5 class="modal-title fw-bold"><i class="bi bi-x-circle-fill me-2"></i>Reject Patient Claim</h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form action="approve-claim.php" method="POST">
                                                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                                                        <input type="hidden" name="claim_id" value="<?= (int)$ac['claim_id'] ?>">
                                                        <input type="hidden" name="action" value="reject">

                                                        <div class="modal-body p-4">
                                                            <p class="small text-muted mb-3">Rejecting claim <strong><?= htmlspecialchars($ac['claim_reference']) ?></strong> for <strong><?= htmlspecialchars($ac['patient_name']) ?></strong> will notify the patient by email.</p>
                                                            <div class="mb-3">
                                                                <label for="admin_notes_rej<?= (int)$ac['claim_id'] ?>" class="form-label fw-bold small">Rejection Reason <span class="text-danger">*</span></label>
                                                                <textarea class="form-control" id="admin_notes_rej<?= (int)$ac['claim_id'] ?>" name="admin_notes" rows="3" required placeholder="e.g. Policy not active / Missing hospitalization bills."></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer bg-light p-3">
                                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger fw-bold"><i class="bi bi-x-circle-fill me-1"></i>CONFIRM REJECTION & SEND EMAIL</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Status Bar -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-custom p-3 bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted small fw-bold text-uppercase">Total Users</span>
                            <h3 class="fw-bold mb-0 text-primary"><?= count($users) ?></h3>
                        </div>
                        <i class="bi bi-people-fill display-6 text-primary text-opacity-25"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom p-3 bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted small fw-bold text-uppercase">Role Policy</span>
                            <h5 class="fw-bold mb-0 text-danger">Single Admin</h5>
                        </div>
                        <i class="bi bi-shield-fill-check display-6 text-danger text-opacity-25"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom p-3 bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted small fw-bold text-uppercase">2FA Protection</span>
                            <h5 class="fw-bold mb-0 <?= $is2FA ? 'text-success' : 'text-warning' ?>"><?= $is2FA ? 'Active' : 'Disabled' ?></h5>
                        </div>
                        <i class="bi bi-shield-lock display-6 text-opacity-25"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom p-3 bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted small fw-bold text-uppercase">Audit Trail</span>
                            <h3 class="fw-bold mb-0 text-info"><?= count($auditLogs) ?></h3>
                        </div>
                        <i class="bi bi-journal-text display-6 text-info text-opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Accounts Table -->
        <div class="card card-custom p-4 bg-white mb-4">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-people me-2 text-primary"></i>System User Accounts</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Role</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Hospital / Dept</th>
                            <th>Email</th>
                            <th>Verified</th>
                            <th>2FA</th>
                            <th>Status</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $index => $u): ?>
                            <tr>
                                <td class="fw-semibold">#<?= $index + 1 ?></td>
                                <td>
                                    <?php if ($u['role'] === 'admin'): ?>
                                        <span class="badge bg-danger">ADMIN</span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">OFFICER</span>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold"><?= htmlspecialchars($u['full_name']) ?></td>
                                <td><code><?= htmlspecialchars($u['username']) ?></code></td>
                                <td class="small"><?= htmlspecialchars($u['hospital_name'] ?? 'N/A') ?><br><span class="text-muted"><?= htmlspecialchars($u['department'] ?? '') ?></span></td>
                                <td class="small"><?= htmlspecialchars($u['email']) ?></td>
                                <td>
                                    <?= $u['email_verified'] ? '<span class="badge bg-success">VERIFIED</span>' : '<span class="badge bg-warning text-dark">PENDING</span>' ?>
                                </td>
                                <td>
                                    <?= $u['two_factor_enabled'] ? '<span class="badge bg-success">2FA ON</span>' : '<span class="badge bg-secondary">OFF</span>' ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $u['status'] === 'active' ? 'success' : ($u['status'] === 'pending' ? 'warning' : 'danger') ?>">
                                        <?= strtoupper($u['status']) ?>
                                    </span>
                                </td>
                                <td class="small text-muted"><?= htmlspecialchars($u['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Security Audit Log Table -->
        <div class="card card-custom p-4 bg-white">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-clock-history me-2 text-info"></i>Recent Security Audit Logs</h5>
            <div class="table-responsive">
                <table class="table table-sm table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Log ID</th>
                            <th>Timestamp</th>
                            <th>Event Type</th>
                            <th>User</th>
                            <th>IP Address</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($auditLogs as $log): ?>
                            <tr>
                                <td>#<?= (int)$log['id'] ?></td>
                                <td class="small text-muted"><?= htmlspecialchars($log['created_at']) ?></td>
                                <td><span class="badge bg-dark font-monospace"><?= htmlspecialchars($log['event_type']) ?></span></td>
                                <td><?= htmlspecialchars($log['username'] ?? 'Anonymous') ?></td>
                                <td><code><?= htmlspecialchars($log['ip_address']) ?></code></td>
                                <td class="small text-muted"><?= htmlspecialchars($log['details'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Session Keep-Alive Heartbeat (Runs every 5 minutes to guarantee persistent lifelong session) -->
    <script>
    setInterval(() => {
        fetch('../public/keep-alive.php')
            .then(res => res.json())
            .then(data => {
                if (data.status === 'ok') {
                    console.log('[Session Keep-Alive] Active session verified at ' + new Date().toLocaleTimeString());
                }
            })
            .catch(err => console.warn('[Session Keep-Alive] Ping warning:', err));
    }, 300000);
    </script>
</body>
</html>
