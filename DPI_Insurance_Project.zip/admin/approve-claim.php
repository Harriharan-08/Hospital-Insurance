<?php
/**
 * Admin Final Claim Approval / Rejection Controller
 * 
 * Handles Admin final approval or rejection of officer-verified patient claims.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit();
}

$csrfToken      = $_POST[CSRF_TOKEN_NAME] ?? '';
$claimId        = (int)($_POST['claim_id'] ?? 0);
$action         = $_POST['action'] ?? 'approve';
$adminNotes     = trim($_POST['admin_notes'] ?? '');
$redirectToForm = !empty($_POST['redirect_to_form']);

if (!validateCSRFToken($csrfToken)) {
    if ($redirectToForm) {
        $_SESSION['admin_errors'] = ["Security check failed. Invalid CSRF token."];
        header("Location: view-patient-form.php?id=$claimId");
    } else {
        $_SESSION['admin_errors'] = ["Security check failed. Invalid CSRF token."];
        header("Location: dashboard.php");
    }
    exit();
}

if ($claimId <= 0) {
    $_SESSION['admin_errors'] = ["Invalid Claim ID specified."];
    header("Location: dashboard.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // Fetch claim and patient details
    $stmt = $pdo->prepare("
        SELECT c.claim_reference, c.hospital_name, c.insurance_company, c.policy_number, c.status, c.officer_notes, p.full_name AS patient_name, p.email
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $claimId]);
    $claim = $stmt->fetch();

    if (!$claim) {
        throw new Exception("Claim record #$claimId not found.");
    }

    if ($action === 'approve' && ($claim['status'] === 'REJECTED' || $claim['status'] === 'OFFICER_REJECTED')) {
        throw new Exception("Cannot approve Claim #{$claim['claim_reference']} because it has already been rejected by the Hospital Officer.");
    }

    $finalStatus = ($action === 'reject') ? 'REJECTED' : 'APPROVED';
    $combinedNotes = (!empty($claim['officer_notes']) ? "Officer Remarks: " . $claim['officer_notes'] . " | " : "") . "Admin Remarks: " . ($adminNotes ?: ($action === 'reject' ? 'Rejected by Admin' : 'Approved with Digital eSign'));

    $adminId   = (int)$_SESSION['user_id'];
    $adminName = $_SESSION['user_name'] ?? 'Administrator';

    $esignTransactionId = null;

    if ($action === 'approve') {
        $authToken = trim($_POST['emsigner_authtoken'] ?? EMSIGNER_AUTH_TOKEN);
        if (empty($authToken)) {
            $authToken = EMSIGNER_AUTH_TOKEN;
        }

        $approvedAmount = trim($_POST['approved_amount'] ?? '₹1,50,000');
        if (empty($approvedAmount)) {
            $approvedAmount = '₹1,50,000';
        }
        if (!preg_match('/^[₹$Rs\.\s\d,]+$/u', $approvedAmount)) {
            $approvedAmount = '₹' . preg_replace('/[^\d,.]/', '', $approvedAmount);
        }

        // 1. Generate unique emSigner Transaction Reference with AuthToken
        $esignTransactionId = 'EMSIGN-' . date('Ymd') . '-' . strtoupper(substr(md5($authToken . $claimId . time()), 0, 8));
        $documentId = 'DOC-CLM-' . sprintf('%06d', $claimId);
        $documentName = 'Approval of Health Insurance Claim Letter - ' . $claim['claim_reference'];
        $documentHash = hash('sha256', $claimId . $claim['claim_reference'] . $claim['patient_name'] . $authToken . $approvedAmount . time());

        // Handle attached DSC signature image (Default: Harriharan S)
        $signaturePath = 'public/assets/signatures/harriharan_signature.png';
        if (!empty($_FILES['signature_file']['tmp_name']) && is_uploaded_file($_FILES['signature_file']['tmp_name'])) {
            $sigExt = pathinfo($_FILES['signature_file']['name'], PATHINFO_EXTENSION);
            $sigFilename = 'sig_' . $claimId . '_' . time() . '.' . $sigExt;
            $sigDest = __DIR__ . '/../public/assets/signatures/' . $sigFilename;
            if (move_uploaded_file($_FILES['signature_file']['tmp_name'], $sigDest)) {
                $signaturePath = 'public/assets/signatures/' . $sigFilename;
            }
        }
        
        $providerResponse = json_encode([
            'service'          => 'emSigner Desktop & PKI Web Gateway',
            'provider'         => 'eMudhra Limited / emSign Secure CA',
            'auth_token'       => $authToken,
            'token_verified'   => true,
            'signed_by'        => 'Harriharan S',
            'signer_id'        => $adminId,
            'signer_role'      => 'Hospital Administrator & Authorized TPA Signatory',
            'claim_ref'        => $claim['claim_reference'],
            'approved_amount'  => $approvedAmount,
            'document_hash'    => $documentHash,
            'signature_file'   => $signaturePath,
            'digital_sig_mode' => 'EMSIGNER_AUTHTOKEN_PKI',
            'timestamp'        => date('Y-m-d H:i:s'),
            'ip_address'       => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'status'           => 'SUCCESSFULLY_SIGNED_AND_AUTHENTICATED'
        ]);

        // Insert into esign_transactions table
        $esignStmt = $pdo->prepare("
            INSERT INTO esign_transactions (claim_id, user_id, transaction_id, document_id, document_name, document_hash, status, signed_document_path, provider_response, created_at)
            VALUES (:claim_id, :user_id, :tx_id, :doc_id, :doc_name, :doc_hash, 'SIGNED', :sig_path, :response, NOW())
        ");
        $esignStmt->execute([
            ':claim_id'  => $claimId,
            ':user_id'   => $adminId,
            ':tx_id'     => $esignTransactionId,
            ':doc_id'    => $documentId,
            ':doc_name'  => $documentName,
            ':doc_hash'  => $documentHash,
            ':sig_path'  => $signaturePath,
            ':response'  => $providerResponse
        ]);
    } else {
        // Log cancelled / rejected transaction if applicable
        $esignStmt = $pdo->prepare("
            INSERT INTO esign_transactions (claim_id, user_id, transaction_id, document_id, document_name, status, error_message, created_at)
            VALUES (:claim_id, :user_id, :tx_id, :doc_id, :doc_name, 'CANCELLED', :err, NOW())
        ");
        $esignStmt->execute([
            ':claim_id' => $claimId,
            ':user_id'  => $adminId,
            ':tx_id'    => 'ESIGN-REJ-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3))),
            ':doc_id'   => 'DOC-CLM-' . sprintf('%06d', $claimId),
            ':doc_name' => 'Claim Rejection Notice - ' . $claim['claim_reference'],
            ':err'      => $adminNotes ?: 'Claim rejected by Administrator'
        ]);
    }

    // Update claim status and admin notes in MySQL
    $updateStmt = $pdo->prepare("UPDATE claims SET status = :status, officer_notes = :notes, updated_at = NOW() WHERE id = :id");
    $updateStmt->execute([':status' => $finalStatus, ':notes' => $combinedNotes, ':id' => $claimId]);

    logAuditEvent($adminId, 'ADMIN_CLAIM_' . $finalStatus, "Patient Claim {$claim['claim_reference']} set to $finalStatus by Admin $adminName" . ($esignTransactionId ? " (eSign Ref: $esignTransactionId, Amount: " . ($approvedAmount ?? 'N/A') . ")" : ""));

    // Send final email notification to patient registered email
    $targetEmail = !empty($claim['email']) ? $claim['email'] : (getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in');
    $emailSentNote = "";

    if ($finalStatus === 'APPROVED') {
        $mailSent = sendAdminClaimApprovalEmail(
            $targetEmail,
            $claim['patient_name'],
            $claim['claim_reference'],
            $claim['hospital_name'] ?? 'City General Hospital',
            $claim['insurance_company'] ?? 'Star Health Insurance',
            $claim['policy_number'] ?? 'N/A',
            $adminNotes,
            $esignTransactionId ?: '',
            $approvedAmount ?? '₹1,50,000'
        );
    } else {
        $mailSent = sendAdminClaimRejectionEmail(
            $targetEmail,
            $claim['patient_name'],
            $claim['claim_reference'],
            $claim['hospital_name'] ?? 'City General Hospital',
            $claim['insurance_company'] ?? 'Star Health Insurance',
            $claim['policy_number'] ?? 'N/A',
            $adminNotes ?: 'Policy eligibility criteria not met or documents insufficient.'
        );
    }

    if ($mailSent) {
        $emailSentNote = " <br><span class='badge bg-success text-white mt-1'>✓ Email Delivered:</span> Patient notification sent to <strong>" . htmlspecialchars($targetEmail) . "</strong>.";
    } else {
        $emailSentNote = " <br><small class='text-muted'><i class='bi bi-envelope-check me-1'></i>Notification queued for <strong>" . htmlspecialchars($targetEmail) . "</strong> (Configure live Gmail SMTP in <code>.env</code> to deliver).</small>";
    }

    $_SESSION['admin_success'] = "Claim <strong>" . htmlspecialchars($claim['claim_reference']) . "</strong> has been <strong>$finalStatus</strong>" . ($esignTransactionId ? " with Digital eSign (<code>$esignTransactionId</code>)" : "") . "!" . $emailSentNote;
    
    if ($redirectToForm) {
        header("Location: view-patient-form.php?id=$claimId");
    } else {
        header("Location: dashboard.php");
    }
    exit();

} catch (Exception $e) {
    if ($redirectToForm) {
        $_SESSION['admin_errors'] = ["Approval process failed: " . $e->getMessage()];
        header("Location: view-patient-form.php?id=$claimId");
    } else {
        $_SESSION['admin_errors'] = ["Approval process failed: " . $e->getMessage()];
        header("Location: dashboard.php");
    }
    exit();
}
