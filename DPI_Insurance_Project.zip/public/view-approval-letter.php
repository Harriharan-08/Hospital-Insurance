<?php
/**
 * Official Signed Health Insurance Claim Approval Document Viewer & Printable Certificate
 * 
 * Displays the complete official Approval Letter with digital eSign signature,
 * emSigner PKI verification certificate, and one-click print/PDF functionality.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/approval_document_template.php';

$pdo = getDBConnection();
$claimId = (int)($_GET['id'] ?? 0);
$claimRef = trim($_GET['ref'] ?? '');

if ($claimId <= 0 && empty($claimRef)) {
    die("Invalid request. Claim ID or reference required.");
}

// Fetch claim and patient details
if ($claimId > 0) {
    $stmt = $pdo->prepare("
        SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
               c.insurance_company, c.policy_number, c.policy_valid_date, c.status, c.officer_notes, c.ekyc_data, c.created_at AS claim_date, c.updated_at AS last_updated,
               p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.alt_phone, p.email, p.address
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        WHERE c.id = :id
    ");
    $stmt->execute([':id' => $claimId]);
} else {
    $stmt = $pdo->prepare("
        SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
               c.insurance_company, c.policy_number, c.policy_valid_date, c.status, c.officer_notes, c.ekyc_data, c.created_at AS claim_date, c.updated_at AS last_updated,
               p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.alt_phone, p.email, p.address
        FROM claims c
        JOIN patients p ON p.id = c.patient_id
        WHERE c.claim_reference = :ref
    ");
    $stmt->execute([':ref' => $claimRef]);
}

$claim = $stmt->fetch();
if (!$claim) {
    die("Claim document record not found.");
}

$patient = [
    'full_name' => $claim['patient_name'],
    'address'   => $claim['address'],
    'email'     => $claim['email'],
    'phone'     => $claim['phone']
];

// Fetch latest eSign transaction
$esignRecord = null;
try {
    $esignStmt = $pdo->prepare("SELECT * FROM esign_transactions WHERE claim_id = :claim_id AND status = 'SIGNED' ORDER BY id DESC LIMIT 1");
    $esignStmt->execute([':claim_id' => $claim['claim_id']]);
    $esignRecord = $esignStmt->fetch();
} catch (Exception $e) {
    // Ignore
}

$approvedAmount = '₹1,50,000';
if ($esignRecord && !empty($esignRecord['provider_response'])) {
    $pResp = json_decode($esignRecord['provider_response'], true);
    if (!empty($pResp['approved_amount'])) {
        $approvedAmount = $pResp['approved_amount'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval Letter - Claim <?= htmlspecialchars($claim['claim_reference']) ?> - <?= htmlspecialchars(APP_NAME) ?></title>
    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8fafc;
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: #0f172a;
            padding: 30px 0;
        }
        .action-toolbar {
            max-width: 860px;
            margin: 0 auto 20px auto;
            background: #ffffff;
            border-radius: 12px;
            padding: 14px 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: gap;
        }
        .document-container {
            max-width: 860px;
            margin: 0 auto;
        }
        @media print {
            body {
                background: #ffffff !important;
                padding: 0 !important;
            }
            .action-toolbar {
                display: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="action-toolbar no-print">
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-success-subtle text-success border border-success fw-bold px-3 py-2">
                <i class="bi bi-patch-check-fill me-1"></i>Official eSigned Approval Document
            </span>
            <span class="text-muted small">Ref: <strong><?= htmlspecialchars($claim['claim_reference']) ?></strong></span>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="download-approval-letter.php?ref=<?= urlencode($claim['claim_reference']) ?>" class="btn btn-success btn-sm fw-bold shadow-sm">
                <i class="bi bi-file-earmark-arrow-down-fill me-1"></i>Download Official PDF
            </a>
            <button onclick="window.print()" class="btn btn-primary btn-sm fw-bold">
                <i class="bi bi-printer-fill me-1"></i>Print Document
            </button>
            <button onclick="window.close()" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-x-lg me-1"></i>Close
            </button>
        </div>
    </div>

    <div class="document-container">
        <?= renderApprovalDocument($claim, $patient, $esignRecord, $approvedAmount, false) ?>
        
        <div class="d-block text-center mt-4 mb-5 no-print">
            <a href="download-approval-letter.php?ref=<?= urlencode($claim['claim_reference']) ?>" class="btn btn-success btn-lg fw-bold shadow px-4 py-2">
                <i class="bi bi-file-earmark-pdf-fill me-2 fs-5"></i>Download Official PDF Certificate
            </a>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
