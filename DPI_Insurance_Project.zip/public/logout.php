<?php
/**
 * Secure Logout Controller
 * 
 * Clears session superglobals, invalidates session cookie, destroys session storage,
 * removes any remember cookies, logs audit event, and redirects to login page.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';

$userId = $_SESSION['user_id'] ?? null;

if ($userId) {
    logAuditEvent($userId, 'LOGOUT_SUCCESS', "User signed out securely (Session terminated)");
}

// Unset all session variables
$_SESSION = [];

// Destroy session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Clear any persistent remember cookies
if (isset($_COOKIE['remember_user_profile'])) {
    setcookie('remember_user_profile', '', time() - 42000, '/');
}

// Destroy session storage
if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

// Redirect to login page
header("Location: " . APP_BASE_URL . "/public/login.php");
exit();
