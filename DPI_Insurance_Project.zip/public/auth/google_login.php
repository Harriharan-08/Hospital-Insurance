<?php
/**
 * Route alias for Google OAuth 2.0 login
 * Resolves both /public/auth/google_login.php and /public/auth/google-login.php
 */
require_once __DIR__ . '/../../auth/google-login.php';
