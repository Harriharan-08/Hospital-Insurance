<?php
/**
 * Route alias for Google OAuth 2.0 login
 */
require_once __DIR__ . '/../../auth/google-login.php';
