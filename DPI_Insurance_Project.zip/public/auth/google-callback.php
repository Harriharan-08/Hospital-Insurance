<?php
/**
 * Route alias for Google OAuth 2.0 callback
 */
require_once __DIR__ . '/../../auth/google-callback.php';
