<?php
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';

$captcha = generateMathCaptcha();
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'code'    => $captcha['code']
]);
