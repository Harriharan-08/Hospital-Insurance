<?php
/**
 * Email Verification UI (Phase 9)
 * 
 * Prompts user for 6-digit OTP code sent to email.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';

$userId    = $_SESSION['verify_user_id'] ?? 0;
$userEmail = $_SESSION['verify_email'] ?? '';
$devOtp    = $_SESSION['dev_otp_display'] ?? null;

if ($userId <= 0 || empty($userEmail)) {
    header("Location: register.php");
    exit();
}

$csrfToken = generateCSRFToken();

$errors  = $_SESSION['otp_errors'] ?? [];
$success = $_SESSION['otp_success'] ?? null;

unset($_SESSION['otp_errors']);
unset($_SESSION['otp_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-verify { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card card-verify p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-envelope-check-fill text-primary display-4"></i>
                        <h3 class="fw-bold mt-2">Verify Email Address</h3>
                        <p class="text-muted small">We sent a 6-digit OTP code to <strong><?= htmlspecialchars($userEmail) ?></strong>.</p>
                    </div>

                    <?php if ($devOtp): ?>
                        <div class="alert alert-info border-info p-3 mb-4 text-center">
                            <i class="bi bi-info-circle me-1"></i><strong>Development Mode OTP Code:</strong>
                            <div class="fs-4 fw-bold text-dark mt-1"><?= htmlspecialchars($devOtp) ?></div>
                            <span class="small text-muted">(Sent via SMTP to <?= htmlspecialchars($userEmail) ?>)</span>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0 small">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success mb-4 text-center">
                            <i class="bi bi-check-circle-fill me-1"></i><?= htmlspecialchars($success) ?>
                        </div>
                    <?php endif; ?>

                    <form action="../auth/verify-otp.php" method="POST" class="mb-3">
                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">

                        <div class="mb-4">
                            <label for="otp_code" class="form-label fw-bold">6-Digit Verification Code *</label>
                            <input type="text" class="form-control form-control-lg text-center fs-3 fw-bold letter-spacing-2" id="otp_code" name="otp_code" required maxlength="6" autofocus placeholder="000000" autocomplete="off">
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 fs-6 fw-bold"><i class="bi bi-shield-check me-1"></i>Verify OTP & Activate Account</button>
                    </form>

                    <form action="../auth/resend-otp.php" method="POST" class="text-center">
                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                        <button type="submit" class="btn btn-link text-decoration-none small text-muted p-0"><i class="bi bi-arrow-clockwise me-1"></i>Didn't receive code? Click to Resend OTP</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
