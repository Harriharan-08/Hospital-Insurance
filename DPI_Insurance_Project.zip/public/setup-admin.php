<?php
/**
 * One-Time Admin Setup & Seeding Endpoint (Phase 4)
 * 
 * Enforces the strict single-admin security constraint.
 * If an admin account already exists in MySQL, creation is permanently blocked.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$adminExists = false;
$errors = [];
$successMessage = null;

try {
    $pdo = getDBConnection();

    // Check if an Admin account already exists in MySQL
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminCount = (int)$stmt->fetchColumn();

    if ($adminCount > 0) {
        $adminExists = true;
    }
} catch (Exception $e) {
    $errors[] = "Database connection error: " . $e->getMessage();
}

// Process POST Form Submission ONLY if Admin does NOT exist
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$adminExists) {
    $fullName        = sanitizeInput($_POST['full_name'] ?? '');
    $username        = sanitizeInput($_POST['username'] ?? '');
    $email           = sanitizeInput($_POST['email'] ?? '');
    $hospitalName    = sanitizeInput($_POST['hospital_name'] ?? 'City Central Hospital');
    $department      = sanitizeInput($_POST['department'] ?? 'Administration');
    $password        = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Validation Rules
    if (empty($fullName) || empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        $errors[] = "All required fields must be filled.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please provide a valid email address.";
    }

    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Password confirmation does not match.";
    }

    if (empty($errors)) {
        try {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            $insertStmt = $pdo->prepare("
                INSERT INTO users (role, full_name, username, hospital_name, department, email, password_hash, email_verified, status, created_at)
                VALUES ('admin', :full_name, :username, :hospital_name, :department, :email, :password_hash, 1, 'active', NOW())
            ");

            $insertStmt->execute([
                ':full_name'     => $fullName,
                ':username'      => $username,
                ':hospital_name' => $hospitalName,
                ':department'    => $department,
                ':email'         => $email,
                ':password_hash' => $passwordHash
            ]);

            $adminId = (int)$pdo->lastInsertId();
            $adminExists = true;
            $successMessage = "System Administrator account '$username' initialized successfully!";

            logAuditEvent($adminId, 'ADMIN_SEEDED', "One-time Insurance Admin account initialized");

        } catch (Exception $e) {
            $errors[] = "Failed to create Admin account: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>One-Time Admin Setup - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-setup { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-setup p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-lock-fill text-danger display-4"></i>
                        <h3 class="fw-bold mt-2">One-Time Admin Setup</h3>
                        <p class="text-muted small">Initialize the single Insurance Administrator account for the system.</p>
                    </div>

                    <?php if ($adminExists): ?>
                        <div class="alert alert-warning text-center p-4">
                            <i class="bi bi-lock-fill display-5 text-warning mb-3"></i>
                            <h4 class="fw-bold">Admin Initialization Locked</h4>
                            <p class="mb-3">An Insurance Administrator account already exists in the system database. Single-Admin security policy prohibits creating additional admin accounts.</p>
                            <a href="login.php" class="btn btn-primary"><i class="bi bi-box-arrow-in-right me-1"></i>Proceed to Login Portal</a>
                        </div>
                    <?php else: ?>

                        <?php if ($successMessage): ?>
                            <div class="alert alert-success p-3 text-center mb-4">
                                <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($successMessage) ?>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger mb-4">
                                <ul class="mb-0 small">
                                    <?php foreach ($errors as $err): ?>
                                        <li><?= htmlspecialchars($err) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="setup-admin.php" method="POST">
                            <div class="mb-3">
                                <label for="full_name" class="form-label fw-bold">Full Name *</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" required placeholder="System Administrator" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
                            </div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label for="username" class="form-label fw-bold">Username *</label>
                                    <input type="text" class="form-control" id="username" name="username" required placeholder="admin" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label for="email" class="form-label fw-bold">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" required placeholder="admin@hospital.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label for="password" class="form-label fw-bold">Password *</label>
                                    <input type="password" class="form-control" id="password" name="password" required placeholder="Min. 8 characters">
                                </div>
                                <div class="col-md-6">
                                    <label for="confirm_password" class="form-label fw-bold">Confirm Password *</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Re-enter password">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-danger w-100 py-2 fw-bold"><i class="bi bi-shield-check me-1"></i>Create System Administrator Account</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
