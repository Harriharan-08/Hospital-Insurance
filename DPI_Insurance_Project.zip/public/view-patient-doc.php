<?php
/**
 * Protected Patient Document Stream Viewer
 * 
 * Enforces session authentication before streaming uploaded PDFs and images.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

$docId = (int)($_GET['id'] ?? 0);
if ($docId <= 0) {
    http_response_code(400);
    die("Invalid Document ID.");
}

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT original_filename, stored_filename, mime_type, storage_path FROM patient_documents WHERE id = :id");
    $stmt->execute([':id' => $docId]);
    $doc = $stmt->fetch();

    if (!$doc) {
        http_response_code(404);
        die("Document record not found.");
    }

    $filePath = __DIR__ . '/../' . $doc['storage_path'];
    if (!file_exists($filePath)) {
        http_response_code(404);
        die("Document file does not exist on server storage.");
    }

    if (ob_get_level()) {
        ob_end_clean();
    }

    header("Content-Type: " . $doc['mime_type']);
    header("Content-Disposition: inline; filename=\"" . basename($doc['original_filename']) . "\"");
    header("Content-Length: " . filesize($filePath));
    header("Cache-Control: private, max-age=86400");

    readfile($filePath);
    exit();

} catch (Exception $e) {
    http_response_code(500);
    die("Document streamer error: " . htmlspecialchars($e->getMessage()));
}
