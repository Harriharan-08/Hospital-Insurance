<?php
/**
 * Forgot Password Email Request UI (Phase 12)
 * 
 * Includes Math CAPTCHA. Enforces anti-enumeration user feedback.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$csrfToken = generateCSRFToken();
$captcha   = generateMathCaptcha();

$errors  = $_SESSION['forgot_errors'] ?? [];
$success = $_SESSION['forgot_success'] ?? null;

unset($_SESSION['forgot_errors']);
unset($_SESSION['forgot_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-forgot { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
        .captcha-box { background-color: #e9ecef; border-radius: 6px; padding: 10px; font-weight: bold; font-size: 1.2rem; letter-spacing: 2px; }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card card-forgot p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-key-fill text-primary display-4"></i>
                        <h3 class="fw-bold mt-2">Forgot Password</h3>
                        <p class="text-muted small">Enter your registered email address to receive password reset instructions.</p>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0 small">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success p-3 mb-4 text-center">
                            <i class="bi bi-info-circle-fill me-1"></i><?= htmlspecialchars($success) ?>
                        </div>
                    <?php endif; ?>

                    <form action="../auth/forgot-password-process.php" method="POST">
                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">

                        <div class="mb-3">
                            <label for="email" class="form-label fw-bold">Email Address *</label>
                            <input type="email" class="form-control" id="email" name="email" required placeholder="name@hospital.com">
                        </div>

                        <!-- Security CAPTCHA -->
                        <div class="mb-4 p-3 bg-light rounded border">
                            <label for="captcha_answer" class="form-label fw-bold small">Security Verification (CAPTCHA) *</label>
                            <div class="row align-items-center g-2">
                                <div class="col-5">
                                    <div class="captcha-box text-center text-white bg-primary border rounded py-2 fw-bold fs-5" style="letter-spacing: 4px; font-family: monospace;">
                                        <?= htmlspecialchars($captcha['question']) ?>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <input type="text" class="form-control fw-bold" id="captcha_answer" name="captcha_answer" required placeholder="Enter Captcha" maxlength="6" style="letter-spacing: 2px;">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 fs-6 fw-bold mb-3"><i class="bi bi-send me-1"></i>Send Reset Link</button>

                        <div class="text-center">
                            <a href="login.php" class="text-muted small text-decoration-none"><i class="bi bi-arrow-left me-1"></i>Back to Sign In</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
