<?php
/**
 * 2FA TOTP Verification Challenge UI (Phase 15)
 * 
 * Guards dashboard access. Enforces require2FAPending().
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require2FAPending();

$csrfToken = generateCSRFToken();

$errors  = $_SESSION['2fa_errors'] ?? [];
$userName= $_SESSION['user_name'] ?? 'User';

unset($_SESSION['2fa_errors']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2FA Verification Challenge - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-2fa { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card card-2fa p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-lock-fill text-primary display-4"></i>
                        <h3 class="fw-bold mt-2">2FA Security Challenge</h3>
                        <p class="text-muted small">Welcome <strong><?= htmlspecialchars($userName) ?></strong>. Please enter the 6-digit code from your Authenticator app.</p>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0 small">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="../auth/verify-2fa-process.php" method="POST">
                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">

                        <div class="mb-4">
                            <label for="totp_code" class="form-label fw-bold">6-Digit Authenticator Code *</label>
                            <input type="text" 
                                   class="form-control form-control-lg text-center fs-3 fw-bold letter-spacing-2" 
                                   id="totp_code" 
                                   name="totp_code" 
                                   required 
                                   maxlength="6" 
                                   inputmode="numeric"
                                   placeholder="000000" 
                                   autofocus 
                                   autocomplete="off">
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 fs-6 fw-bold mb-3">
                            <i class="bi bi-shield-check me-1"></i>Verify 2FA & Access Dashboard
                        </button>

                        <div class="text-center">
                            <a href="logout.php" class="text-muted small text-decoration-none"><i class="bi bi-box-arrow-left me-1"></i>Cancel & Sign Out</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
