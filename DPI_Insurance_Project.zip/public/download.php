<?php
/**
 * Direct Project Download Script
 */
$zipPath = __DIR__ . '/insurancee_project.zip';

if (!file_exists($zipPath)) {
    $zipPath = __DIR__ . '/../insurancee_project.zip';
}

if (file_exists($zipPath)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="insurancee_project.zip"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
    exit;
} else {
    http_response_code(404);
    echo "Zip file not found.";
    exit;
}
