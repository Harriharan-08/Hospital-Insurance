<?php
/**
 * Database Diagnostic & Table Verification Controller
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Diagnostic - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0 rounded-3 p-4 bg-white">
                    <h4 class="fw-bold text-primary mb-3"><i class="bi bi-database-gear me-2"></i>PDO MySQL Connection Diagnostic</h4>
                    <hr>

                    <?php
                    try {
                        $pdo = getDBConnection();
                        echo "<div class='alert alert-success d-flex align-items-center mb-4'>";
                        echo "<i class='bi bi-check-circle-fill display-6 me-3'></i>";
                        echo "<div><h5 class='mb-1 fw-bold'>Connected Successfully!</h5>";
                        echo "PDO connection established to MySQL database <code>" . DB_NAME . "</code> on <code>" . DB_HOST . ":" . DB_PORT . "</code>.</div>";
                        echo "</div>";

                        $tables = $pdo->query("SHOW TABLES FROM " . DB_NAME)->fetchAll(PDO::FETCH_COLUMN);

                        echo "<h6 class='fw-bold mb-2'>Existing Database Tables (" . count($tables) . "):</h6>";
                        if (empty($tables)) {
                            echo "<div class='alert alert-warning'>No tables found in database. Run database setup script below.</div>";
                        } else {
                            echo "<ul class='list-group mb-4'>";
                            foreach ($tables as $table) {
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
                                echo "<code>" . htmlspecialchars($table) . "</code>";
                                echo "<span class='badge bg-success rounded-pill'>Active</span>";
                                echo "</li>";
                            }
                            echo "</ul>";
                        }

                    } catch (Exception $e) {
                        echo "<div class='alert alert-danger d-flex align-items-center mb-4'>";
                        echo "<i class='bi bi-exclamation-triangle-fill display-6 me-3'></i>";
                        echo "<div><h5 class='mb-1 fw-bold'>Connection Failed</h5>";
                        echo htmlspecialchars($e->getMessage()) . "</div>";
                        echo "</div>";
                    }
                    ?>

                    <div class="d-flex gap-2">
                        <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-1"></i>Back to Index</a>
                        <a href="../database/setup.php" class="btn btn-primary"><i class="bi bi-play-circle me-1"></i>Run Database Setup Script</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
