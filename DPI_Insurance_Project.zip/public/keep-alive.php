<?php
/**
 * Session Keep-Alive Endpoint
 * 
 * Silently pings and refreshes the session activity timestamp for Hospital Officers and Admins
 * ensuring lifetime persistent access during daily routines.
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';

$_SESSION['last_activity'] = time();

$response = [
    'status'       => 'ok',
    'authenticated'=> isLoggedIn(),
    'role'         => $_SESSION['user_role'] ?? null,
    'user_id'      => $_SESSION['user_id'] ?? null,
    'timestamp'    => time()
];

echo json_encode($response);
exit();
