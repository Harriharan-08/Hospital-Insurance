<?php
/**
 * Interactive Robot Doctor Developer Login Interface
 * 
 * Styled with pixel-perfect fidelity to the reference design:
 * - Warm retro-modern claymorphic aesthetic with bold line borders
 * - Robot character holding the card with cute hands and feet
 * - Dynamic speech bubble with witty, reactive dialogue
 * - Full 3D head-turn animation on password focus ("A secret? Say no more. *turns around*")
 * - Dynamic eye-tracking cursor following and expression morphs
 * - Seamless integration with PHP/XAMPP auth backend with AJAX & POST fallback
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$csrfToken = generateCSRFToken();
$captcha   = generateMathCaptcha();

$errors  = $_SESSION['login_errors'] ?? [];
$success = $_SESSION['login_success'] ?? null;

if (isset($_COOKIE['remember_user_profile'])) {
    setcookie('remember_user_profile', '', time() - 42000, '/');
    unset($_COOKIE['remember_user_profile']);
}

unset($_SESSION['login_errors']);
unset($_SESSION['login_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="pageTitle">Hospital Officer & Insurance Approver Portal — <?= htmlspecialchars(APP_NAME) ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- Google Identity Services (GIS) JS Client -->
    <script src="https://accounts.google.com/gsi/client" async defer></script>

    <style>
        :root {
            --bg-color: #f8fafc;
            --card-bg: #eae8e3;
            --card-inner: #f4f3ef;
            --input-bg: #dedcd7;
            --input-focus-bg: #ffffff;
            --border-color: #262626;
            --text-main: #242424;
            --text-muted: #737373;
            --btn-orange: #d96338;
            --btn-orange-hover: #c4532b;
            --btn-shadow: #1c1c1c;
            --font-main: 'Plus Jakarta Sans', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: var(--font-main);
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 15px;
            color: var(--text-main);
            overflow-x: hidden;
            user-select: none;
        }

        /* Container for Card + Character */
        .login-wrapper {
            width: 100%;
            max-width: 410px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            margin-top: 50px;
        }

        /* Speech Bubble */
        .speech-bubble-container {
            position: relative;
            margin-bottom: 12px;
            z-index: 30;
            min-height: 48px;
            display: flex;
            justify-content: center;
        }

        .speech-bubble {
            background: #ffffff;
            border: 2px solid var(--border-color);
            border-radius: 14px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 700;
            color: var(--text-main);
            text-align: center;
            box-shadow: 3px 3px 0px var(--border-color);
            position: relative;
            transition: all 0.25s ease;
            max-width: 320px;
            line-height: 1.35;
        }

        /* Speech bubble pointer */
        .speech-bubble::after {
            content: '';
            position: absolute;
            bottom: -9px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-top: 9px solid #ffffff;
            z-index: 2;
        }

        .speech-bubble::before {
            content: '';
            position: absolute;
            bottom: -12px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 10px solid transparent;
            border-right: 10px solid transparent;
            border-top: 11px solid var(--border-color);
            z-index: 1;
        }

        /* Robot Character Stage */
        .robot-stage {
            width: 130px;
            height: 105px;
            margin-bottom: -15px;
            position: relative;
            z-index: 15;
            perspective: 800px;
        }

        /* 3D Rotating Head Card */
        .robot-head-wrapper {
            width: 100%;
            height: 100%;
            position: relative;
            transform-style: preserve-3d;
            transition: transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .robot-head-wrapper.is-turned-around {
            transform: rotateY(180deg);
        }

        .robot-head-front,
        .robot-head-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            -webkit-backface-visibility: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .robot-head-back {
            transform: rotateY(180deg);
        }

        /* Robot Head Outer Shell */
        .head-shell {
            width: 114px;
            height: 94px;
            background: #e5e3de;
            border: 2.5px solid var(--border-color);
            border-radius: 26px;
            box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        /* Robot Ears / Bolts */
        .head-ear {
            position: absolute;
            width: 8px;
            height: 24px;
            background: #d4d1cb;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            top: 50%;
            transform: translateY(-50%);
        }
        .head-ear.left { left: -7px; }
        .head-ear.right { right: -7px; }

        /* Doctor Headlamp / Antenna */
        .doctor-antenna {
            position: absolute;
            top: -10px;
            width: 18px;
            height: 9px;
            background: #d96338;
            border: 2px solid var(--border-color);
            border-radius: 6px;
            box-shadow: 0 0 6px rgba(217, 99, 56, 0.5);
        }

        /* Front Screen */
        .screen-display {
            width: 82px;
            height: 66px;
            background: #202428;
            border: 2px solid var(--border-color);
            border-radius: 18px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 8px;
            position: relative;
            overflow: hidden;
        }

        /* Screen Reflection */
        .screen-display::before {
            content: '';
            position: absolute;
            top: -20px;
            left: -20px;
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, rgba(255,255,255,0.18) 0%, transparent 60%);
            border-radius: 50%;
            pointer-events: none;
        }

        /* Robot Eyes Container */
        .eyes-row {
            display: flex;
            align-items: center;
            gap: 16px;
            transition: transform 0.1s ease-out;
        }

        .robot-eye {
            width: 13px;
            height: 19px;
            background: #ffffff;
            border-radius: 7px;
            box-shadow: 0 0 8px rgba(255, 255, 255, 0.8);
            transition: all 0.15s ease;
            position: relative;
        }

        /* Eye Blinking */
        .robot-eye.blink {
            height: 2px;
            margin-top: 8.5px;
            margin-bottom: 8.5px;
            border-radius: 2px;
        }

        /* Happy Eyes (^ ^) */
        .robot-eye.happy {
            height: 10px;
            border-top: 4px solid #ffffff;
            border-radius: 10px 10px 0 0;
            background: transparent;
            box-shadow: none;
        }

        /* Concerned / Error Eyes */
        .robot-eye.error {
            background: #f43f5e;
            box-shadow: 0 0 10px #f43f5e;
        }

        /* Robot Mouth / Status LED */
        .robot-mouth {
            width: 10px;
            height: 3px;
            background: #ffffff;
            border-radius: 2px;
            opacity: 0.8;
            transition: all 0.2s ease;
        }

        /* Back of Head */
        .back-details {
            width: 82px;
            height: 66px;
            background: #d4d1cb;
            border: 2px solid var(--border-color);
            border-radius: 18px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .vent-line {
            width: 44px;
            height: 3px;
            background: #a8a29e;
            border-radius: 2px;
        }

        .doctor-cross-badge {
            width: 18px;
            height: 18px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .doctor-cross-badge::before,
        .doctor-cross-badge::after {
            content: '';
            position: absolute;
            background: var(--btn-orange);
            border-radius: 2px;
        }
        .doctor-cross-badge::before { width: 14px; height: 4px; }
        .doctor-cross-badge::after { width: 4px; height: 14px; }

        .admin-shield-badge {
            display: none;
            color: #2563eb;
            font-size: 16px;
            line-height: 1;
        }

        .is-admin-mode .doctor-cross-badge {
            display: none;
        }

        .is-admin-mode .admin-shield-badge {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .is-admin-mode .doctor-antenna {
            background: #2563eb;
            box-shadow: 0 0 8px rgba(37, 99, 235, 0.6);
        }

        /* Robot Hands gripping the card */
        .robot-hands-container {
            position: absolute;
            top: -11px;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            padding: 0 32px;
            z-index: 25;
            pointer-events: none;
        }

        .robot-hand {
            width: 28px;
            height: 22px;
            background: #eae8e3;
            border: 2px solid var(--border-color);
            border-radius: 10px 10px 4px 4px;
            box-shadow: 0 2px 0 rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .robot-hand::after {
            content: '';
            position: absolute;
            top: 4px;
            left: 50%;
            transform: translateX(-50%);
            width: 14px;
            height: 10px;
            border-left: 2px solid var(--border-color);
            border-right: 2px solid var(--border-color);
        }

        /* Robot Feet peeking from bottom */
        .robot-feet-container {
            position: absolute;
            bottom: -15px;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            padding: 0 54px;
            z-index: 5;
            pointer-events: none;
        }

        .robot-foot {
            width: 38px;
            height: 24px;
            background: #eae8e3;
            border: 2px solid var(--border-color);
            border-radius: 6px 6px 14px 14px;
            box-shadow: 2px 3px 0px rgba(0, 0, 0, 0.15);
        }

        /* Main Login Card */
        .card-frame {
            width: 100%;
            background: var(--card-bg);
            border: 2.5px solid var(--border-color);
            border-radius: 30px;
            box-shadow: 6px 6px 0px var(--border-color);
            padding: 34px 28px 28px 28px;
            position: relative;
            z-index: 10;
        }

        /* Role Switcher Tabs */
        .role-selector {
            display: flex;
            background: #dedcd7;
            border: 2px solid var(--border-color);
            border-radius: 14px;
            padding: 4px;
            margin-bottom: 14px;
            gap: 6px;
        }

        .role-tab {
            flex: 1;
            border: none;
            background: transparent;
            border-radius: 10px;
            padding: 7px 8px;
            font-size: 11.5px;
            font-weight: 700;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: var(--font-main);
            user-select: none;
        }

        .role-tab i {
            font-size: 13px;
            margin-right: 5px;
        }

        .role-tab:hover {
            color: var(--text-main);
        }

        .role-tab.active {
            background: #ffffff;
            color: var(--text-main);
            border: 2px solid var(--border-color);
            box-shadow: 2px 2px 0px var(--border-color);
        }

        .is-admin-mode .btn-logmein {
            background-color: #2563eb;
        }

        .is-admin-mode .btn-logmein:hover {
            background-color: #1d4ed8;
        }

        /* Card Title */
        .card-header-title {
            font-size: 20px;
            font-weight: 800;
            color: var(--text-main);
            letter-spacing: -0.4px;
            margin-top: 4px;
            margin-bottom: 18px;
            transition: color 0.2s ease;
        }

        /* Form Inputs */
        .form-group-custom {
            margin-bottom: 14px;
            position: relative;
        }

        .input-box {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon-left {
            position: absolute;
            left: 14px;
            color: #8c8983;
            font-size: 15px;
            pointer-events: none;
            display: flex;
            align-items: center;
        }

        .input-field {
            width: 100%;
            height: 48px;
            padding: 10px 42px 10px 42px;
            font-family: var(--font-main);
            font-size: 14px;
            font-weight: 600;
            color: var(--text-main);
            background-color: var(--input-bg);
            border: 1.5px solid transparent;
            border-radius: 14px;
            outline: none;
            transition: all 0.2s ease;
        }

        .input-field::placeholder {
            color: #8c8983;
            font-weight: 500;
        }

        .input-field:focus {
            background-color: var(--input-focus-bg);
            border-color: var(--border-color);
            box-shadow: 0 0 0 3px rgba(36, 36, 36, 0.08);
        }

        /* Show/Hide password eye */
        .btn-eye-toggle {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            color: #8c8983;
            font-size: 16px;
            cursor: pointer;
            padding: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            transition: color 0.2s ease;
        }

        .btn-eye-toggle:hover {
            color: var(--text-main);
        }

        /* Captcha row */
        .captcha-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 14px;
        }

        .captcha-pill {
            background: #dedcd7;
            border: 1.5px solid #cac6be;
            border-radius: 12px;
            padding: 10px 14px;
            font-family: var(--font-mono);
            font-size: 13.5px;
            font-weight: 700;
            color: var(--text-main);
            white-space: nowrap;
        }

        /* Submit Button ("LOG ME IN") */
        .btn-logmein {
            width: 100%;
            height: 52px;
            background-color: var(--btn-orange);
            border: 2px solid var(--border-color);
            border-radius: 14px;
            color: #ffffff;
            font-family: var(--font-main);
            font-size: 16px;
            font-weight: 800;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            cursor: pointer;
            box-shadow: 0 4px 0px var(--btn-shadow);
            transition: all 0.15s ease;
            margin-top: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-logmein:hover {
            background-color: var(--btn-orange-hover);
            transform: translateY(-1px);
            box-shadow: 0 5px 0px var(--btn-shadow);
        }

        .btn-logmein:active {
            transform: translateY(3px);
            box-shadow: 0 1px 0px var(--btn-shadow);
        }

        .btn-logmein:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 2px 0px var(--btn-shadow);
        }

        /* Divider */
        .divider-or {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 14px 0 10px 0;
            color: var(--text-muted);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.8px;
            text-transform: uppercase;
        }

        .divider-or::before,
        .divider-or::after {
            content: '';
            flex: 1;
            border-bottom: 1.5px solid #cac6be;
        }

        .divider-or:not(:empty)::before {
            margin-right: 10px;
        }

        .divider-or:not(:empty)::after {
            margin-left: 10px;
        }

        /* Continue with Google Button */
        .btn-google {
            width: 100%;
            height: 48px;
            background-color: #ffffff;
            border: 2px solid var(--border-color);
            border-radius: 14px;
            color: var(--text-main);
            font-family: var(--font-main);
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            box-shadow: 0 3px 0px var(--btn-shadow);
            transition: all 0.15s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-google:hover {
            background-color: #f8fafc;
            transform: translateY(-1px);
            box-shadow: 0 4px 0px var(--btn-shadow);
            color: var(--text-main);
        }

        .btn-google:active {
            transform: translateY(2px);
            box-shadow: 0 1px 0px var(--btn-shadow);
        }

        /* Quick Autofill & Links */
        .bottom-links {
            margin-top: 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .bottom-links a {
            color: var(--text-main);
            text-decoration: none;
            border-bottom: 1.5px solid transparent;
            transition: border-color 0.2s ease;
        }

        .bottom-links a:hover {
            border-bottom-color: var(--text-main);
        }



        /* Alert Box */
        .login-alert {
            background: #fee2e2;
            border: 1.5px solid #ef4444;
            color: #991b1b;
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 14px;
            display: none;
        }

        @media (max-width: 480px) {
            .login-wrapper { max-width: 340px; margin-top: 30px; }
            .card-frame { padding: 24px 18px 20px 18px; border-radius: 24px; }
            .robot-hands-container { padding: 0 20px; }
            .robot-feet-container { padding: 0 35px; }
            .role-tab { font-size: 10.5px; padding: 6px 3px; }
            .role-tab i { font-size: 11px; margin-right: 3px; }
        }
    </style>
</head>
<body>

    <div class="login-wrapper">
        
        <!-- Interactive Speech Bubble -->
        <div class="speech-bubble-container">
            <div class="speech-bubble" id="speechBubble">
                Hello Hospital Officer! Who's checking in?
            </div>
        </div>

        <!-- 3D Flipping Robot Character -->
        <div class="robot-stage">
            <div class="robot-head-wrapper" id="robotHeadWrapper">
                
                <!-- FRONT: Friendly Screen Display with Eyes -->
                <div class="robot-head-front">
                    <div class="head-shell">
                        <div class="head-ear left"></div>
                        <div class="head-ear right"></div>
                        <div class="doctor-antenna"></div>

                        <div class="screen-display">
                            <div class="eyes-row" id="eyesRow">
                                <div class="robot-eye" id="eyeL"></div>
                                <div class="robot-eye" id="eyeR"></div>
                            </div>
                            <div class="robot-mouth" id="robotMouth"></div>
                        </div>
                    </div>
                </div>

                <!-- BACK: Head Turned Around for Password Privacy -->
                <div class="robot-head-back">
                    <div class="head-shell">
                        <div class="head-ear left"></div>
                        <div class="head-ear right"></div>
                        <div class="doctor-antenna"></div>

                        <div class="back-details">
                            <div class="doctor-cross-badge" title="Hospital Verification"></div>
                            <div class="admin-shield-badge" title="Insurance Authority"><i class="bi bi-shield-check"></i></div>
                            <div class="vent-line"></div>
                            <div class="vent-line" style="width: 32px;"></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Main Login Card with Robot Hands & Feet -->
        <div class="card-frame">
            <!-- Hands gripping top -->
            <div class="robot-hands-container">
                <div class="robot-hand"></div>
                <div class="robot-hand"></div>
            </div>

            <!-- Feet peeking bottom -->
            <div class="robot-feet-container">
                <div class="robot-foot"></div>
                <div class="robot-foot"></div>
            </div>

            <!-- Interactive Role Selector -->
            <div class="role-selector" id="roleSelector">
                <button type="button" class="role-tab active" id="tabOfficer" data-role="officer">
                    <i class="bi bi-hospital"></i> Hospital Officer
                </button>
                <button type="button" class="role-tab" id="tabAdmin" data-role="admin">
                    <i class="bi bi-shield-check"></i> Insurance Admin
                </button>
            </div>

            <h1 class="card-header-title" id="cardHeaderTitle">Hospital Officer Login</h1>

            <!-- Error Banner -->
            <div class="login-alert" id="loginAlert" style="<?= !empty($errors) ? 'display: block;' : 'display: none;' ?>">
                <i class="bi bi-exclamation-circle me-1"></i>
                <span id="alertMsg"><?= !empty($errors) ? htmlspecialchars($errors[0]) : '' ?></span>
            </div>

            <!-- Primary Form -->
            <form id="beepLoginForm" action="../auth/login-process.php" method="POST" novalidate>
                <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="is_ajax" value="1">

                <!-- Name / Username / Email -->
                <div class="form-group-custom">
                    <div class="input-box">
                        <span class="input-icon-left"><i class="bi bi-person"></i></span>
                        <input 
                            type="text" 
                            class="input-field" 
                            id="inputIdentifier" 
                            name="identifier" 
                            placeholder="Officer username or hospital email" 
                            required 
                            autocomplete="username"
                            spellcheck="false"
                        >
                    </div>
                </div>

                <!-- Password Input -->
                <div class="form-group-custom">
                    <div class="input-box">
                        <span class="input-icon-left"><i class="bi bi-lock"></i></span>
                        <input 
                            type="password" 
                            class="input-field" 
                            id="inputPassword" 
                            name="password" 
                            placeholder="Super secret password" 
                            required 
                            autocomplete="current-password"
                        >
                        <button type="button" class="btn-eye-toggle" id="btnEyeToggle" title="Toggle password visibility">
                            <i class="bi bi-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <!-- Alphanumeric CAPTCHA with click-to-refresh -->
                <div class="captcha-row">
                    <div class="captcha-pill" id="captchaBadge" title="Click to refresh CAPTCHA code" style="cursor: pointer;">
                        <i class="bi bi-robot me-1"></i><span id="captchaText"><?= htmlspecialchars($captcha['question']) ?></span>
                        <i class="bi bi-arrow-clockwise ms-1" style="font-size: 11px; opacity: 0.7;"></i>
                    </div>
                    <div class="input-box flex-grow-1">
                        <input 
                            type="text" 
                            class="input-field" 
                            id="inputCaptcha" 
                            name="captcha_answer" 
                            placeholder="Enter captcha code" 
                            required 
                            autocomplete="off"
                            autocorrect="off"
                            spellcheck="false"
                            style="padding-left: 14px; font-family: var(--font-mono); letter-spacing: 1px;"
                        >
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn-logmein" id="btnSubmit">
                    <span id="btnLabel">LOG ME IN</span>
                </button>

                <!-- Divider -->
                <div class="divider-or"><span>OR</span></div>

                <!-- Continue with Google Button -->
                <a href="../auth/google-login.php" class="btn-google" id="btnGoogleLogin">
                    <svg width="18" height="18" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                    <span>Continue with Google</span>
                </a>

                <!-- Helper Options -->
                <div class="bottom-links">
                    <a href="../public/forgot-password.php">Forgot password?</a>
                    <a href="../public/register.php">Create account</a>
                </div>

            </form>
        </div>

    </div>

    <!-- Interactive Controller Script -->
    <script>

        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('beepLoginForm');
            const inputIdentifier = document.getElementById('inputIdentifier');
            const inputPassword = document.getElementById('inputPassword');
            const inputCaptcha = document.getElementById('inputCaptcha');
            const btnEyeToggle = document.getElementById('btnEyeToggle');
            const eyeIcon = document.getElementById('eyeIcon');
            const speechBubble = document.getElementById('speechBubble');
            const robotHeadWrapper = document.getElementById('robotHeadWrapper');
            const eyesRow = document.getElementById('eyesRow');
            const eyeL = document.getElementById('eyeL');
            const eyeR = document.getElementById('eyeR');
            const robotMouth = document.getElementById('robotMouth');
            const btnSubmit = document.getElementById('btnSubmit');
            const btnLabel = document.getElementById('btnLabel');
            const loginAlert = document.getElementById('loginAlert');
            const alertMsg = document.getElementById('alertMsg');

            // Role Switcher Elements
            const tabOfficer = document.getElementById('tabOfficer');
            const tabAdmin = document.getElementById('tabAdmin');
            const cardHeaderTitle = document.getElementById('cardHeaderTitle');
            const loginWrapper = document.querySelector('.login-wrapper');
            const pageTitle = document.getElementById('pageTitle');

            let currentRole = 'officer'; // 'officer' or 'admin'
            let isTurnedAround = false;
            let isPasswordVisible = false;
            let blinkTimer = null;

            // Role Profile Definitions
            const roleProfiles = {
                officer: {
                    title: "Hospital Officer Login",
                    placeholder: "Officer username or hospital email",
                    greeting: "Hello Hospital Officer! Who's checking in?",
                    pageTitle: "Hospital Officer Portal — <?= htmlspecialchars(APP_NAME) ?>",
                    focusGreeting: "Welcome Officer! Please enter your hospital credentials.",
                    passwordTurn: "Protecting hospital officer credentials. *turns around*",
                    submitting: "*verifying officer credentials* Connecting to Hospital Portal...",
                    emptyMsg: "Hospital Officer, please complete all fields (Username/Email, Password, CAPTCHA)!",
                    googlePrompt: "Sign in with authorized Hospital Officer Google account"
                },
                admin: {
                    title: "Insurance Admin Login",
                    placeholder: "Admin username or insurance email",
                    greeting: "Welcome Insurance Admin! Who's checking in?",
                    pageTitle: "Insurance Admin Portal — <?= htmlspecialchars(APP_NAME) ?>",
                    focusGreeting: "Welcome Admin! Please enter your insurance credentials.",
                    passwordTurn: "Protecting insurance admin credentials. *turns around*",
                    submitting: "*verifying admin credentials* Connecting to Insurance Portal...",
                    emptyMsg: "Insurance Admin, please complete all fields (Username/Email, Password, CAPTCHA)!",
                    googlePrompt: "Sign in with authorized Insurance Admin Google account"
                }
            };

            // Speech Bubble update helper
            function setSpeech(text) {
                speechBubble.style.opacity = '0';
                speechBubble.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    speechBubble.textContent = text;
                    speechBubble.style.opacity = '1';
                    speechBubble.style.transform = 'scale(1)';
                }, 120);
            }

            // Role Switcher Function
            function switchRole(role, notifySpeech = true) {
                if (role === currentRole && !notifySpeech) return;
                currentRole = role;

                if (role === 'admin') {
                    tabAdmin.classList.add('active');
                    tabOfficer.classList.remove('active');
                    loginWrapper.classList.add('is-admin-mode');
                } else {
                    tabOfficer.classList.add('active');
                    tabAdmin.classList.remove('active');
                    loginWrapper.classList.remove('is-admin-mode');
                }

                const profile = roleProfiles[role];
                if (cardHeaderTitle) cardHeaderTitle.textContent = profile.title;
                if (inputIdentifier) inputIdentifier.placeholder = profile.placeholder;
                if (pageTitle) pageTitle.textContent = profile.pageTitle;

                triggerBlink();

                if (notifySpeech) {
                    setSpeech(profile.greeting);
                }
            }

            if (tabOfficer) {
                tabOfficer.addEventListener('click', () => switchRole('officer', true));
            }
            if (tabAdmin) {
                tabAdmin.addEventListener('click', () => switchRole('admin', true));
            }

            // Natural Blink Loop
            function triggerBlink() {
                if (isTurnedAround) return;
                eyeL.classList.add('blink');
                eyeR.classList.add('blink');
                setTimeout(() => {
                    eyeL.classList.remove('blink');
                    eyeR.classList.remove('blink');
                }, 150);
            }

            blinkTimer = setInterval(() => {
                if (Math.random() > 0.3) triggerBlink();
            }, 3200);

            // Eye tracking on typing & Smart role auto-detection
            inputIdentifier.addEventListener('input', () => {
                const len = inputIdentifier.value.length;
                const progress = Math.min(len / 20, 1);
                const shiftX = -5 + (progress * 10);
                eyesRow.style.transform = `translate(${shiftX}px, 2px)`;

                // Smart role auto-detection
                const val = inputIdentifier.value.toLowerCase().trim();
                if (val.includes('admin') || val.includes('11239a107') || val.includes('approv')) {
                    if (currentRole !== 'admin') {
                        switchRole('admin', false);
                        setSpeech("Insurance Admin recognized! Welcome back.");
                    }
                } else if (val.includes('officer') || val.includes('sarah') || val.includes('test_off') || val.includes('11239a089')) {
                    if (currentRole !== 'officer') {
                        switchRole('officer', false);
                        setSpeech("Hospital Officer recognized! Welcome back.");
                    }
                }
            });

            inputIdentifier.addEventListener('focus', () => {
                turnFront();
                setSpeech(roleProfiles[currentRole].focusGreeting);
            });

            inputIdentifier.addEventListener('blur', () => {
                eyesRow.style.transform = 'translate(0, 0)';
                if (!inputPassword.matches(':focus') && !inputCaptcha.matches(':focus')) {
                    setSpeech(roleProfiles[currentRole].greeting);
                }
            });

            // Password Field Focus -> Head turns around!
            inputPassword.addEventListener('focus', () => {
                if (!isPasswordVisible) {
                    turnBack();
                    setSpeech(roleProfiles[currentRole].passwordTurn);
                } else {
                    turnFront();
                    setSpeech("I see you're viewing in plain text!");
                }
            });

            inputPassword.addEventListener('blur', () => {
                if (!isPasswordVisible && !inputIdentifier.matches(':focus') && !inputCaptcha.matches(':focus')) {
                    turnFront();
                    setSpeech(roleProfiles[currentRole].greeting);
                }
            });

            // Toggle Password Visibility (Eye icon)
            btnEyeToggle.addEventListener('click', () => {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    inputPassword.type = 'text';
                    eyeIcon.className = 'bi bi-eye-slash';
                    turnFront();
                    setSpeech("Oh, you're peeking? I'll turn back around!");
                } else {
                    inputPassword.type = 'password';
                    eyeIcon.className = 'bi bi-eye';
                    if (document.activeElement === inputPassword) {
                        turnBack();
                        setSpeech("A secret? Say no more. *turns around*");
                    }
                }
            });

            // Captcha Focus
            inputCaptcha.addEventListener('focus', () => {
                turnFront();
                setSpeech("Calculate this quick security problem!");
            });

            const btnGoogleLogin = document.getElementById('btnGoogleLogin');
            if (btnGoogleLogin) {
                btnGoogleLogin.addEventListener('mouseenter', () => {
                    turnFront();
                    setSpeech(roleProfiles[currentRole].googlePrompt);
                });
            }

            function turnBack() {
                isTurnedAround = true;
                robotHeadWrapper.classList.add('is-turned-around');
            }

            function turnFront() {
                isTurnedAround = false;
                robotHeadWrapper.classList.remove('is-turned-around');
            }


            // Initial server errors if any
            if (alertMsg.textContent.trim().length > 0) {
                loginAlert.style.display = 'block';
                setSpeech("Bzzzt! " + alertMsg.textContent.trim());
            }

            // AJAX Form Submit with Strict Validation
            form.addEventListener('submit', async (e) => {
                e.preventDefault();

                const enteredIdentifier = inputIdentifier.value.trim();
                const enteredPassword   = inputPassword.value;
                const enteredCaptcha    = inputCaptcha.value.trim();
                const currentCaptcha    = document.getElementById('captchaText')?.textContent?.trim() || '';

                if (!enteredIdentifier || !enteredPassword || !enteredCaptcha) {
                    loginAlert.style.display = 'block';
                    alertMsg.textContent = 'Please fill out all fields (Username/Email, Password, and CAPTCHA)!';
                    setSpeech(roleProfiles[currentRole].emptyMsg);
                    return;
                }

                // 1. Strict Client-Side CAPTCHA Pre-Verification
                if (currentCaptcha && enteredCaptcha.toLowerCase() !== currentCaptcha.toLowerCase()) {
                    eyeL.classList.add('error');
                    eyeR.classList.add('error');
                    setTimeout(() => {
                        eyeL.classList.remove('error');
                        eyeR.classList.remove('error');
                    }, 1200);

                    loginAlert.style.display = 'block';
                    alertMsg.textContent = 'Incorrect CAPTCHA code. Please enter the exact code shown.';
                    setSpeech("Bzzzt! Wrong CAPTCHA code. Please try again!");
                    btnSubmit.disabled = false;
                    btnLabel.textContent = 'LOG ME IN';
                    inputCaptcha.focus();
                    inputCaptcha.select();
                    return; // NEVER proceed to next step
                }

                loginAlert.style.display = 'none';
                turnFront();
                setSpeech(roleProfiles[currentRole].submitting);
                btnSubmit.disabled = true;
                btnLabel.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>VERIFYING...';

                try {
                    const formData = new FormData(form);
                    const response = await fetch(form.action, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json'
                        }
                    });

                    let data = null;
                    const contentType = response.headers.get('content-type');
                    if (contentType && contentType.includes('application/json')) {
                        data = await response.json();
                    } else {
                        const rawText = await response.text();
                        try {
                            data = JSON.parse(rawText);
                        } catch (parseErr) {
                            throw new Error("Unexpected server response format.");
                        }
                    }

                    if (data && data.success && data.redirect) {
                        eyeL.classList.add('happy');
                        eyeR.classList.add('happy');
                        robotMouth.style.width = '18px';
                        robotMouth.style.borderRadius = '0 0 10px 10px';
                        robotMouth.style.height = '8px';

                        const userRole = (data.user?.role || currentRole).toLowerCase();
                        const userName = data.user?.name || '';
                        if (userRole === 'admin') {
                            setSpeech(`Access granted! Welcome Insurance Admin ${userName}!`);
                        } else {
                            setSpeech(`Access granted! Welcome Hospital Officer ${userName}!`);
                        }

                        btnLabel.textContent = 'LOGGED IN ✓';
                        btnSubmit.style.backgroundColor = '#16a34a';

                        setTimeout(() => {
                            window.location.href = data.redirect;
                        }, 800);
                    } else {
                        eyeL.classList.add('error');
                        eyeR.classList.add('error');
                        setTimeout(() => {
                            eyeL.classList.remove('error');
                            eyeR.classList.remove('error');
                        }, 1200);

                        // If server provided new captcha, update immediately
                        if (data && data.new_captcha) {
                            document.getElementById('captchaText').textContent = data.new_captcha;
                            inputCaptcha.value = '';
                        } else {
                            refreshCaptcha();
                        }

                        loginAlert.style.display = 'block';
                        alertMsg.textContent = (data && data.error) ? data.error : 'Invalid username, password, or CAPTCHA.';
                        setSpeech("Bzzzt! " + ((data && data.error) ? data.error : 'Access denied. Check credentials.'));
                        btnSubmit.disabled = false;
                        btnLabel.textContent = 'LOG ME IN';
                        inputCaptcha.focus();
                    }
                } catch (err) {
                    console.error("Login verification error:", err);
                    loginAlert.style.display = 'block';
                    alertMsg.textContent = err.message || 'Connection error with authentication server.';
                    setSpeech("Bzzzt! Network error. Please try again.");
                    btnSubmit.disabled = false;
                    btnLabel.textContent = 'LOG ME IN';
                    refreshCaptcha();
                }
            });

            // Refresh Captcha function
            async function refreshCaptcha() {
                try {
                    const res = await fetch('get-captcha.php');
                    const json = await res.json();
                    if (json.success && json.code) {
                        document.getElementById('captchaText').textContent = json.code;
                        inputCaptcha.value = '';
                    }
                } catch (e) {
                    console.warn("Could not refresh captcha", e);
                }
            }

            document.getElementById('captchaBadge')?.addEventListener('click', () => {
                refreshCaptcha();
                setSpeech("New security code generated!");
            });

            // Google Identity Services (GIS) Token Receiver & Auto-Verify Handler
            const googleClientId = <?= json_encode(GOOGLE_CLIENT_ID) ?>;
            const csrfTokenValue = <?= json_encode($csrfToken) ?>;
            const btnGoogle = document.getElementById('btnGoogleLogin');

            window.handleGoogleCredentialResponse = async function(response) {
                if (!response || !response.credential) {
                    if (loginAlert && alertMsg) {
                        loginAlert.style.display = 'block';
                        alertMsg.textContent = 'Google Sign-In failed to return credentials.';
                    }
                    setSpeech("Bzzzt! Google Sign-In could not get your credentials.");
                    return;
                }

                setSpeech("Verifying " + (currentRole === 'admin' ? "Insurance Admin" : "Hospital Officer") + " Google account...");
                if (btnGoogle) {
                    btnGoogle.style.opacity = '0.7';
                    btnGoogle.style.pointerEvents = 'none';
                }

                try {
                    const res = await fetch('../auth/google-verify-token.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            id_token: response.credential,
                            csrf_token: csrfTokenValue
                        })
                    });

                    const data = await res.json();

                    if (data.success && data.redirect) {
                        const userRole = (data.user?.role || currentRole).toLowerCase();
                        const userName = data.user?.name || '';
                        if (userRole === 'admin') {
                            setSpeech(`Access granted! Welcome Insurance Admin ${userName}!`);
                        } else {
                            setSpeech(`Access granted! Welcome Hospital Officer ${userName}!`);
                        }
                        setTimeout(() => {
                            window.location.href = data.redirect;
                        }, 350);
                    } else {
                        if (loginAlert && alertMsg) {
                            loginAlert.style.display = 'block';
                            alertMsg.textContent = data.error || 'Google authentication failed.';
                        }
                        setSpeech("Bzzzt! " + (data.error || 'Google authentication failed.'));
                        if (btnGoogle) {
                            btnGoogle.style.opacity = '1';
                            btnGoogle.style.pointerEvents = 'auto';
                        }
                    }
                } catch (err) {
                    console.error("Google Token Verification Error:", err);
                    if (loginAlert && alertMsg) {
                        loginAlert.style.display = 'block';
                        alertMsg.textContent = 'Server connection error during Google verification.';
                    }
                    setSpeech("Bzzzt! Network error communicating with server.");
                    if (btnGoogle) {
                        btnGoogle.style.opacity = '1';
                        btnGoogle.style.pointerEvents = 'auto';
                    }
                }
            };

            function initGoogleIdentity() {
                if (googleClientId && window.google && window.google.accounts && window.google.accounts.id) {
                    try {
                        google.accounts.id.initialize({
                            client_id: googleClientId,
                            callback: handleGoogleCredentialResponse,
                            auto_select: false,
                            cancel_on_tap_outside: true
                        });
                        // Display Google One Tap overlay if available in browser
                        google.accounts.id.prompt();
                    } catch (gisErr) {
                        console.warn("Google Identity Services Initialization Note:", gisErr);
                    }
                }
            }

            if (btnGoogle) {
                btnGoogle.addEventListener('click', () => {
                    turnFront();
                    setSpeech("Redirecting to Google Sign-In...");
                });
            }

            if (window.google && window.google.accounts) {
                initGoogleIdentity();
            } else {
                window.addEventListener('load', initGoogleIdentity);
            }
        });
    </script>
</body>
</html>
