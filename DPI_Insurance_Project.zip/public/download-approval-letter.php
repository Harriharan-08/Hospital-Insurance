<?php
/**
 * Public Direct PDF Downloader & Streamer for Claim Approval Letter
 * 
 * Allows patients, officers, and administrators to directly download or view
 * the official cryptographically signed Claim Approval Certificate PDF.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/approvalLetterPdfGenerator.php';

$claimId  = (int)($_GET['id'] ?? 0);
$claimRef = trim($_GET['ref'] ?? '');
$viewMode = (isset($_GET['view']) && $_GET['view'] === '1');

if ($claimId <= 0 && empty($claimRef)) {
    http_response_code(400);
    die("Invalid request. Claim ID or Claim Reference is required.");
}

try {
    $pdo = getDBConnection();

    if ($claimId > 0) {
        $stmt = $pdo->prepare("
            SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
                   c.insurance_company, c.policy_number, c.policy_valid_date, c.status, c.officer_notes, c.ekyc_data, c.created_at AS claim_date,
                   p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.email, p.address
            FROM claims c
            JOIN patients p ON p.id = c.patient_id
            WHERE c.id = :id
        ");
        $stmt->execute([':id' => $claimId]);
    } else {
        $stmt = $pdo->prepare("
            SELECT c.id AS claim_id, c.claim_reference, c.hospital_name, c.admission_date, c.treatment_details, 
                   c.insurance_company, c.policy_number, c.policy_valid_date, c.status, c.officer_notes, c.ekyc_data, c.created_at AS claim_date,
                   p.id AS patient_id, p.patient_reference, p.full_name AS patient_name, p.guardian_name, p.date_of_birth, p.gender, p.phone, p.email, p.address
            FROM claims c
            JOIN patients p ON p.id = c.patient_id
            WHERE c.claim_reference = :ref
        ");
        $stmt->execute([':ref' => $claimRef]);
    }

    $claim = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$claim) {
        http_response_code(404);
        die("Approval letter not found for the specified claim.");
    }

    $patient = [
        'full_name' => $claim['patient_name'],
        'address'   => $claim['address'],
        'email'     => $claim['email'],
        'phone'     => $claim['phone']
    ];

    // Fetch latest eSign transaction
    $esignRecord = null;
    try {
        $esignStmt = $pdo->prepare("SELECT * FROM esign_transactions WHERE claim_id = :claim_id AND status = 'SIGNED' ORDER BY id DESC LIMIT 1");
        $esignStmt->execute([':claim_id' => $claim['claim_id']]);
        $esignRecord = $esignStmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Ignore
    }

    $approvedAmount = '₹1,50,000';
    if ($esignRecord && !empty($esignRecord['provider_response'])) {
        $pResp = json_decode($esignRecord['provider_response'], true);
        if (!empty($pResp['approved_amount'])) {
            $approvedAmount = $pResp['approved_amount'];
        }
    }

    $pdfBinary = ApprovalLetterPdfGenerator::generatePdfBinary($claim, $patient, $esignRecord, $approvedAmount);

    if (ob_get_level()) {
        ob_end_clean();
    }

    $filename = 'Claim_Approval_Letter_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $claim['claim_reference']) . '.pdf';
    $disposition = $viewMode ? 'inline' : 'attachment';

    header('Content-Type: application/pdf');
    header('Content-Disposition: ' . $disposition . '; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($pdfBinary));
    header('Cache-Control: private, max-age=86400, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    echo $pdfBinary;
    exit();

} catch (Exception $e) {
    http_response_code(500);
    die("Error generating PDF: " . htmlspecialchars($e->getMessage()));
}
