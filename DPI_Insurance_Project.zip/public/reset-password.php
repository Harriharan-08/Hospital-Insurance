<?php
/**
 * Password Reset UI Form (Phase 12)
 * 
 * Verifies token validity from URL parameter.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

$rawToken = sanitizeInput($_GET['token'] ?? ($_POST['token'] ?? ''));
$validToken = false;
$tokenRecord = null;
$errors = [];

if (!empty($rawToken)) {
    try {
        $pdo = getDBConnection();
        $tokenHash = hash('sha256', $rawToken);

        $stmt = $pdo->prepare("
            SELECT id, user_id, expires_at, used 
            FROM password_resets 
            WHERE token_hash = :hash AND used = 0
        ");
        $stmt->execute([':hash' => $tokenHash]);
        $tokenRecord = $stmt->fetch();

        if ($tokenRecord && strtotime($tokenRecord['expires_at']) > time()) {
            $validToken = true;
        }
    } catch (Exception $e) {
        $errors[] = "Error validating token: " . $e->getMessage();
    }
}

$csrfToken = generateCSRFToken();
$sessionErrors = $_SESSION['reset_errors'] ?? [];
unset($_SESSION['reset_errors']);
$errors = array_merge($errors, $sessionErrors);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-reset { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card card-reset p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-lock-fill text-primary display-4"></i>
                        <h3 class="fw-bold mt-2">Reset Password</h3>
                        <p class="text-muted small">Please enter your new password below.</p>
                    </div>

                    <?php if (!$validToken): ?>
                        <div class="alert alert-danger text-center p-4">
                            <i class="bi bi-exclamation-octagon-fill display-5 text-danger mb-3"></i>
                            <h5 class="fw-bold">Invalid or Expired Reset Token</h5>
                            <p class="small text-muted mb-3">This password reset link is invalid, expired, or has already been used.</p>
                            <a href="forgot-password.php" class="btn btn-outline-primary btn-sm"><i class="bi bi-arrow-left me-1"></i>Request New Reset Link</a>
                        </div>
                    <?php else: ?>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger mb-4">
                                <ul class="mb-0 small">
                                    <?php foreach ($errors as $err): ?>
                                        <li><?= htmlspecialchars($err) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="../auth/reset-password-process.php" method="POST">
                            <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="token" value="<?= htmlspecialchars($rawToken) ?>">

                            <div class="mb-3">
                                <label for="password" class="form-label fw-bold">New Password *</label>
                                <input type="password" class="form-control" id="password" name="password" required placeholder="Min 8 characters">
                            </div>

                            <div class="mb-4">
                                <label for="confirm_password" class="form-label fw-bold">Confirm New Password *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Re-enter new password">
                            </div>

                            <button type="submit" class="btn btn-primary w-100 py-2 fs-6 fw-bold"><i class="bi bi-check-lg me-1"></i>Save New Password</button>
                        </form>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
