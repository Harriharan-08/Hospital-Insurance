<?php
/**
 * Hospital Officer Self-Registration UI (Phase 5 & 6)
 * 
 * Automatically assigns role = 'officer'. Public users CANNOT select Admin role.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$csrfToken = generateCSRFToken();
$captcha   = generateMathCaptcha();

$errors = $_SESSION['register_errors'] ?? [];
$formData = $_SESSION['register_form_data'] ?? [];

unset($_SESSION['register_errors']);
unset($_SESSION['register_form_data']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Registration - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-register { border: none; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
        .captcha-box { background-color: #e9ecef; border-radius: 6px; padding: 10px; font-weight: bold; font-size: 1.2rem; letter-spacing: 2px; }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="card card-register p-4 p-md-5 bg-white">
                    <div class="text-center mb-4">
                        <i class="bi bi-person-plus-fill text-primary display-4"></i>
                        <h3 class="fw-bold mt-2">Hospital Officer Registration</h3>
                        <p class="text-muted small">Register an account to manage patient submissions and hospital insurance claims.</p>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0 small">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="../auth/register-process.php" method="POST" autocomplete="off">
                        <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">

                        <div class="mb-3">
                            <label for="full_name" class="form-label fw-bold">Full Name *</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" required placeholder="Officer Sarah Connor" value="<?= htmlspecialchars($formData['full_name'] ?? '') ?>" autocomplete="off">
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label for="username" class="form-label fw-bold">Username *</label>
                                <input type="text" class="form-control" id="username" name="username" required placeholder="sarah_officer" value="<?= htmlspecialchars($formData['username'] ?? '') ?>" autocomplete="off">
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label fw-bold">Email Address *</label>
                                <input type="email" class="form-control" id="email" name="email" required placeholder="officer@hospital.com" value="<?= htmlspecialchars($formData['email'] ?? '') ?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label for="hospital_name" class="form-label fw-bold">Hospital Name</label>
                                <input type="text" class="form-control" id="hospital_name" name="hospital_name" placeholder="City General Hospital" value="<?= htmlspecialchars($formData['hospital_name'] ?? '') ?>" autocomplete="off">
                            </div>
                            <div class="col-md-6">
                                <label for="department" class="form-label fw-bold">Department</label>
                                <input type="text" class="form-control" id="department" name="department" placeholder="Claims & Billing" value="<?= htmlspecialchars($formData['department'] ?? '') ?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label fw-bold">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="+91 9876543210" value="<?= htmlspecialchars($formData['phone'] ?? '') ?>" autocomplete="off">
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label for="password" class="form-label fw-bold">Password *</label>
                                <input type="password" class="form-control" id="password" name="password" required placeholder="Min 8 chars, 1 upper, 1 num" autocomplete="new-password">
                            </div>
                            <div class="col-md-6">
                                <label for="confirm_password" class="form-label fw-bold">Confirm Password *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Re-enter password" autocomplete="new-password">
                            </div>
                        </div>

                        <!-- Security CAPTCHA -->
                        <div class="mb-4 p-3 bg-light rounded border">
                            <label for="captcha_answer" class="form-label fw-bold"><i class="bi bi-shield-check text-primary me-1"></i>Security Verification (CAPTCHA) *</label>
                            <div class="row align-items-center g-3">
                                <div class="col-md-4">
                                    <div class="captcha-box text-center text-white bg-primary border rounded py-2 fw-bold fs-5" style="letter-spacing: 4px; font-family: monospace;">
                                        <?= htmlspecialchars($captcha['question']) ?>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control fw-bold" id="captcha_answer" name="captcha_answer" required placeholder="Enter Captcha" maxlength="6" style="letter-spacing: 2px;">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold mb-3"><i class="bi bi-person-check-fill me-1"></i>Register Officer Account</button>

                        <div class="text-center small">
                            Already have an account? <a href="login.php" class="fw-bold text-decoration-none">Sign In Here</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
