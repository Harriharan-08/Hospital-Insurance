<?php
/**
 * Google Account Email OTP Verification Interface
 * 
 * Verifies the 6-digit OTP dispatched to the user's authenticated Google email.
 * Displays ONLY a masked email address for privacy and security.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';

$userId      = (int)($_SESSION['google_auth_pending_user_id'] ?? 0);
$googleEmail = $_SESSION['google_auth_pending_email'] ?? '';
$googleName  = $_SESSION['google_auth_pending_name'] ?? 'User';
$googlePic   = $_SESSION['google_auth_pending_pic'] ?? '';

// Session Loss / Unauthorized Access Guard
if ($userId <= 0 || empty($googleEmail)) {
    $_SESSION['login_errors'] = ["Google authentication session has expired. Please sign in again."];
    header("Location: login.php");
    exit();
}

$csrfToken   = generateCSRFToken();
$maskedEmail = maskEmailAddress($googleEmail);

$errors  = $_SESSION['google_otp_errors'] ?? [];
$success = $_SESSION['google_otp_success'] ?? "An OTP has been sent to your Google email address.";

unset($_SESSION['google_otp_errors']);
unset($_SESSION['google_otp_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Google Email OTP — <?= htmlspecialchars(APP_NAME) ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@600;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        :root {
            --bg-color: #f8fafc;
            --card-bg: #eae8e3;
            --input-bg: #dedcd7;
            --input-focus-bg: #ffffff;
            --border-color: #262626;
            --text-main: #242424;
            --text-muted: #64748b;
            --btn-orange: #d96338;
            --btn-orange-hover: #c4532b;
            --btn-shadow: #1c1c1c;
            --font-main: 'Plus Jakarta Sans', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: var(--font-main);
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 15px;
            color: var(--text-main);
        }

        .verify-wrapper {
            width: 100%;
            max-width: 440px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }

        /* Claymorphic Card */
        .card-frame {
            width: 100%;
            background: var(--card-bg);
            border: 2.5px solid var(--border-color);
            border-radius: 28px;
            box-shadow: 6px 6px 0px var(--border-color);
            padding: 34px 28px 28px 28px;
            position: relative;
        }

        .google-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #ffffff;
            border: 2px solid var(--border-color);
            padding: 6px 14px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
            box-shadow: 2px 2px 0px var(--border-color);
            margin-bottom: 16px;
        }

        .google-badge img {
            width: 18px;
            height: 18px;
        }

        .card-title {
            font-size: 21px;
            font-weight: 800;
            color: var(--text-main);
            letter-spacing: -0.4px;
            margin-bottom: 6px;
        }

        .info-pill {
            background: #ffffff;
            border: 1.5px solid #d4d0c7;
            border-radius: 12px;
            padding: 12px 14px;
            margin: 16px 0;
            text-align: center;
        }

        .info-pill-title {
            font-size: 13px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 2px;
        }

        .masked-email {
            font-family: var(--font-mono);
            font-size: 14px;
            font-weight: 700;
            color: #2563eb;
            letter-spacing: 0.5px;
        }

        /* 6-Digit OTP Input Box */
        .otp-input-group {
            margin: 20px 0 16px 0;
        }

        .otp-input {
            width: 100%;
            height: 56px;
            font-family: var(--font-mono);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: 8px;
            text-align: center;
            background-color: var(--input-bg);
            border: 2px solid var(--border-color);
            border-radius: 14px;
            color: var(--text-main);
            outline: none;
            transition: all 0.2s ease;
            box-shadow: 2px 2px 0px var(--border-color);
        }

        .otp-input:focus {
            background-color: var(--input-focus-bg);
            box-shadow: 3px 3px 0px var(--border-color);
        }

        .otp-input::placeholder {
            letter-spacing: 6px;
            color: #9ca3af;
            opacity: 0.6;
        }

        /* Submit Button */
        .btn-verify {
            width: 100%;
            height: 52px;
            background-color: var(--btn-orange);
            border: 2px solid var(--border-color);
            border-radius: 14px;
            color: #ffffff;
            font-family: var(--font-main);
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.6px;
            text-transform: uppercase;
            cursor: pointer;
            box-shadow: 0 4px 0px var(--btn-shadow);
            transition: all 0.15s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-verify:hover {
            background-color: var(--btn-orange-hover);
            transform: translateY(-1px);
            box-shadow: 0 5px 0px var(--btn-shadow);
        }

        .btn-verify:active {
            transform: translateY(3px);
            box-shadow: 0 1px 0px var(--btn-shadow);
        }

        .alert-custom-danger {
            background: #fee2e2;
            border: 1.5px solid #ef4444;
            color: #991b1b;
            padding: 10px 14px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 14px;
        }

        .alert-custom-success {
            background: #dcfce7;
            border: 1.5px solid #22c55e;
            color: #166534;
            padding: 10px 14px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 14px;
        }

        .cooldown-text {
            font-size: 12px;
            color: var(--text-muted);
            font-weight: 600;
            margin-top: 8px;
        }

        .resend-btn {
            background: none;
            border: none;
            color: var(--text-main);
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: underline;
            padding: 4px;
        }

        .resend-btn:hover {
            color: #d96338;
        }

        .resend-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <div class="verify-wrapper">
        <div class="card-frame text-center">
            
            <!-- Google Sign-in Badge -->
            <div class="google-badge">
                <svg width="18" height="18" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Google Verification</span>
            </div>

            <h1 class="card-title">Enter Verification Code</h1>
            
            <!-- Requirement Message & Masked Email -->
            <div class="info-pill">
                <div class="info-pill-title">
                    <i class="bi bi-envelope-check me-1 text-primary"></i>An OTP has been sent to your Google email address.
                </div>
                <div class="masked-email mt-1"><?= htmlspecialchars($maskedEmail) ?></div>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert-custom-danger">
                    <i class="bi bi-exclamation-triangle-fill me-1"></i><?= htmlspecialchars($errors[0]) ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success) && empty($errors)): ?>
                <div class="alert-custom-success">
                    <i class="bi bi-shield-check me-1"></i><?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <!-- OTP Submission Form -->
            <form action="../auth/verify-google-otp-process.php" method="POST" id="otpForm">
                <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                
                <div class="otp-input-group">
                    <input 
                        type="text" 
                        class="otp-input" 
                        name="otp_code" 
                        id="otpCode" 
                        maxlength="6" 
                        pattern="[0-9]{6}" 
                        inputmode="numeric" 
                        placeholder="••••••" 
                        autocomplete="one-time-code"
                        required 
                        autofocus
                    >
                </div>

                <button type="submit" class="btn-verify" id="btnVerify">
                    <i class="bi bi-check2-circle fs-5"></i>
                    <span>Verify & Continue</span>
                </button>
            </form>

            <!-- Resend Form -->
            <div class="mt-4 pt-2 border-top border-secondary border-opacity-25">
                <form action="../auth/resend-google-otp.php" method="POST" id="resendForm">
                    <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                    <button type="submit" class="resend-btn" id="btnResend">
                        <i class="bi bi-arrow-clockwise me-1"></i>Resend OTP Code
                    </button>
                </form>
                <div class="cooldown-text" id="cooldownText">
                    Code valid for <?= OTP_EXPIRATION_MINUTES ?> minutes.
                </div>
            </div>

            <!-- Cancel / Sign In with Another Account -->
            <div class="mt-3">
                <a href="login.php" class="small text-muted text-decoration-none">
                    <i class="bi bi-arrow-left me-1"></i>Back to Sign In
                </a>
            </div>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const otpInput = document.getElementById('otpCode');
            const otpForm  = document.getElementById('otpForm');

            // Automatically submit when 6 digits are typed
            otpInput.addEventListener('input', (e) => {
                e.target.value = e.target.value.replace(/[^0-9]/g, '');
                if (e.target.value.length === 6) {
                    otpForm.submit();
                }
            });
        });
    </script>

</body>
</html>
