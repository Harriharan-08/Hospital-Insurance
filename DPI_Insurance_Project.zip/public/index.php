<?php
/**
 * System Overview & Diagnostic Dashboard
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';

$dbConnected = false;
$tableStatuses = [];
$dbError = null;

try {
    $pdo = getDBConnection();
    $dbConnected = true;

    $requiredTables = [
        'users', 'email_otps', 'password_resets',
        'two_factor_auth', 'login_attempts', 'audit_logs'
    ];

    $existingTables = $pdo->query("SHOW TABLES FROM " . DB_NAME)->fetchAll(PDO::FETCH_COLUMN);

    foreach ($requiredTables as $tbl) {
        $tableStatuses[$tbl] = in_array($tbl, $existingTables);
    }
} catch (Exception $e) {
    $dbError = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(APP_NAME) ?> - Phase 1 Overview</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; color: #1e293b; }
        .hero-section { background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); color: white; padding: 60px 0; }
        .card-custom { border: none; border-radius: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

    <!-- Header Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#"><i class="bi bi-shield-check text-primary me-2"></i><?= htmlspecialchars(APP_NAME) ?></a>
            <div class="d-flex gap-2">
                <a href="login.php" class="btn btn-primary btn-sm fw-bold"><i class="bi bi-box-arrow-in-right me-1"></i>Sign In</a>
                <a href="register.php" class="btn btn-outline-light btn-sm"><i class="bi bi-person-plus me-1"></i>Register Officer</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-5 fw-bold mb-3"><?= htmlspecialchars(APP_NAME) ?></h1>
            <p class="lead text-light text-opacity-75 mb-4">Phase 1: Real Full-Stack PHP 8.x + MySQL System Architecture Setup</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="test-db.php" class="btn btn-primary px-4 py-2 fw-bold"><i class="bi bi-database me-1"></i>Test Database Connection</a>
                <a href="../database/setup.php" class="btn btn-outline-light px-4 py-2 fw-bold"><i class="bi bi-gear me-1"></i>Run Database Setup</a>
            </div>
        </div>
    </section>

    <!-- Diagnostic Summary -->
    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card card-custom p-4 bg-white h-100">
                    <h5 class="fw-bold text-primary mb-3"><i class="bi bi-activity me-2"></i>Database Connection Status</h5>
                    <hr>
                    <?php if ($dbConnected): ?>
                        <div class="alert alert-success d-flex align-items-center">
                            <i class="bi bi-check-circle-fill display-6 me-3"></i>
                            <div>
                                <strong>Connected to MySQL Successfully!</strong><br>
                                <small>Database: <code><?= DB_NAME ?></code> on <code><?= DB_HOST ?>:<?= DB_PORT ?></code></small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger d-flex align-items-center">
                            <i class="bi bi-x-circle-fill display-6 me-3"></i>
                            <div>
                                <strong>Database Connection Error</strong><br>
                                <small><?= htmlspecialchars($dbError) ?></small>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-custom p-4 bg-white h-100">
                    <h5 class="fw-bold text-primary mb-3"><i class="bi bi-shield-lock me-2"></i>Security Environment</h5>
                    <hr>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><strong>PHP Version:</strong> <span class="badge bg-info text-dark"><?= PHP_VERSION ?></span></li>
                        <li class="mb-2"><strong>Session ID:</strong> <code><?= htmlspecialchars(session_id()) ?></code></li>
                        <li class="mb-2"><strong>HttpOnly Cookie:</strong> <span class="badge bg-success">ENABLED</span></li>
                        <li><strong>SameSite Cookie:</strong> <span class="badge bg-success">Lax</span></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="card card-custom p-4 bg-white mt-4">
            <h5 class="fw-bold text-dark mb-3"><i class="bi bi-database-check me-2 text-success"></i>Database Tables Status</h5>
            <div class="row g-3">
                <?php foreach ($tableStatuses as $tbl => $exists): ?>
                    <div class="col-md-4 col-6">
                        <div class="p-3 border rounded bg-light d-flex justify-content-between align-items-center">
                            <code><?= htmlspecialchars($tbl) ?></code>
                            <?php if ($exists): ?>
                                <span class="badge bg-success"><i class="bi bi-check me-1"></i>Found</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><i class="bi bi-x me-1"></i>Missing</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
