# DPI-Enabled Cashless Health Insurance Claim Authentication & Settlement System

[![PHP Version](https://img.shields.io/badge/PHP-8.2%2B-blue.svg)](https://www.php.net/)
[![Database](https://img.shields.io/badge/MySQL-8.0%2B-orange.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

A secure, paperless, and fraud-resistant health insurance claim settlement platform powered by India's **Digital Public Infrastructure (DPI)**: **Aadhaar Offline Paperless eKYC** and **Cryptographic Digital eSign**.

---

## 📌 Problem Statement
Traditional cashless health insurance claim processing is heavily burdened by:
* **Identity Fraud & Impersonation**: Forged physical policy cards and fake patient identity documents leading to wrongful claims.
* **Prolonged Discharge Delays**: Manual document verification by hospital billing staff taking 4 to 8 hours.
* **Lack of Cryptographic Authenticity**: Paper-based approval letters and scanned signatures lack non-repudiation and can easily be forged.
* **Mobile Inaccessibility**: Patients cannot easily access or download official signed approval letters directly to their mobile devices.

---

## 🎯 Key Objectives
* **Instant DPI Identity Verification**: Leverage **Aadhaar Offline eKYC (XML/ZIP with 4-digit Share Code)** to verify patients without exposing or storing raw 12-digit Aadhaar numbers.
* **Two-Tier Role-Based Workflow**: Streamline review between **Hospital Claims Officers** (evidence & demographic audit) and **Hospital Administrators / TPAs** (financial limits & authorization).
* **Legally Validated Digital eSign**: Implement digital signature authorization compliant with **Section 10A of the IT Act, 2000**.
* **Automated Mobile Delivery**: Deliver official, tamper-proof **Claim Approval Certificate PDFs** directly via email attachment and dedicated mobile download routes.

---

## 🛠️ Architecture & Tech Stack

* **Backend**: PHP 8.2 (Object-Oriented, PDO with prepared statements)
* **Database**: MySQL 8.0 / MariaDB with strict relational integrity
* **DPI Components**:
  * **UIDAI Aadhaar Offline eKYC**: Password-protected AES-128 & ZipCrypto XML/ZIP parser
  * **eMudhra emSigner PKI**: Cryptographic digital signature stamping & SHA-256 integrity verification
* **Frontend**: HTML5, Vanilla CSS3, Bootstrap 5, Responsive Design
* **PDF Engine**: Pure-PHP Vector PDF 1.4 Generation Engine
* **Notifications**: PHPMailer (SMTP with STARTTLS)
* **Security**: Google OAuth 2.0 Single Sign-On, TOTP Two-Factor Authentication (2FA), Bcrypt password hashing, Rate-limiting

---

## 🚀 Installation & Local Setup

### Prerequisites
* [XAMPP](https://www.apachefriends.org/) (Apache & MySQL) with PHP 8.2+
* Enabled PHP Extensions in `php.ini`: `pdo_mysql`, `zip`, `openssl`, `curl`

### Steps
1. **Clone the Repository**:
   ```bash
   git clone https://github.com/<your-username>/insurance-claim-system.git
   cd insurance-claim-system
   ```

2. **Configure Database**:
   * Open phpMyAdmin (`http://localhost/phpmyadmin`).
   * Create a database named `hospital_insurance_db`.
   * Import the schema file located at `database/schema.sql`.

3. **Configure Environment Variables**:
   * Copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
   * Update database credentials (`DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME`) and SMTP settings (`SMTP_HOST`, `SMTP_USERNAME`, `SMTP_PASSWORD`).

4. **Run the Project**:
   * Place the folder in your web root (`htdocs/insurancee`).
   * Start Apache and MySQL from the XAMPP Control Panel.
   * Access the portals:
     * **Patient Claim Form**: `http://localhost/insurancee/patient/index.php`
     * **Hospital Officer Dashboard**: `http://localhost/insurancee/officer/dashboard.php`
     * **Administrator Dashboard**: `http://localhost/insurancee/admin/dashboard.php`

---

## 📄 License
This project is licensed under the MIT License - see the LICENSE file for details.
