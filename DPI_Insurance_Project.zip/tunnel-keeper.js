/**
 * Auto-Reconnecting Watchdog Daemon for LocalTunnel
 * Enforces subdomain 'hospital-claim-10599' and keeps connection active 24/7 without fault.
 */

const localtunnel = require('localtunnel');
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8000;
const DESIRED_SUBDOMAIN = 'hospital-claim-10599';
const LOG_FILE = path.join(__dirname, 'scratch', 'tunnel-keeper.log');

function log(msg) {
    const timestamp = new Date().toISOString();
    const logLine = `[${timestamp}] ${msg}\n`;
    console.log(logLine.trim());
    try {
        const dir = path.dirname(LOG_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.appendFileSync(LOG_FILE, logLine);
    } catch (e) {}
}

let activeTunnel = null;
let isConnecting = false;

async function startTunnel() {
    if (isConnecting) return;
    isConnecting = true;

    if (activeTunnel) {
        try { activeTunnel.close(); } catch (e) {}
        activeTunnel = null;
    }

    log(`Attempting to request LocalTunnel subdomain '${DESIRED_SUBDOMAIN}' on port ${PORT}...`);

    try {
        const tunnel = await localtunnel({ port: PORT, subdomain: DESIRED_SUBDOMAIN });
        activeTunnel = tunnel;
        isConnecting = false;

        const assignedUrl = tunnel.url;
        log(`LocalTunnel connected: ${assignedUrl}`);

        if (!assignedUrl.includes(DESIRED_SUBDOMAIN)) {
            log(`Subdomain '${DESIRED_SUBDOMAIN}' is temporarily locked on localtunnel server. Retrying in 10s...`);
            try { tunnel.close(); } catch (e) {}
            activeTunnel = null;
            setTimeout(startTunnel, 10000);
            return;
        }

        log(`SUCCESS! Assigned exact target URL: ${tunnel.url}`);

        tunnel.on('close', () => {
            log('LocalTunnel connection CLOSED. Scheduling immediate reconnection in 3 seconds...');
            activeTunnel = null;
            setTimeout(startTunnel, 3000);
        });

        tunnel.on('error', (err) => {
            log(`LocalTunnel ERROR: ${err.message}. Reconnecting in 3 seconds...`);
            if (activeTunnel) {
                try { activeTunnel.close(); } catch (e) {}
                activeTunnel = null;
            }
            setTimeout(startTunnel, 3000);
        });

    } catch (err) {
        isConnecting = false;
        log(`Failed to create LocalTunnel: ${err.message}. Retrying in 5 seconds...`);
        setTimeout(startTunnel, 5000);
    }
}

// Health check ping every 15 seconds
setInterval(() => {
    http.get(`http://127.0.0.1:${PORT}/patient/index.php`, (res) => {
        if (res.statusCode !== 200) {
            log(`Health Warning: Local PHP server status ${res.statusCode}`);
        }
    }).on('error', (err) => {
        log(`Health Error: Local PHP server unreachable: ${err.message}`);
    });
}, 15000);

process.on('uncaughtException', (err) => {
    log(`Uncaught Exception: ${err.message}. Keeping daemon alive...`);
    setTimeout(startTunnel, 3000);
});

process.on('unhandledRejection', (reason) => {
    log(`Unhandled Rejection: ${reason}. Keeping daemon alive...`);
    setTimeout(startTunnel, 3000);
});

startTunnel();
