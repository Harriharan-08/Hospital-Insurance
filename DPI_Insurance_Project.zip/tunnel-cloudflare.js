/**
 * Cloudflare Tunnel Auto-Manager & Watchdog Daemon
 * 
 * - Automatically launches cloudflared.exe
 * - Extracts the public trycloudflare.com URL and saves to scratch/tunnel_url.txt
 * - Performs periodic health-check heartbeats to keep the tunnel alive
 * - Auto-restarts cloudflared immediately if connection drops or processes exit
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

const logFile = path.join(__dirname, 'scratch', 'cloudflared.log');
const urlFile = path.join(__dirname, 'scratch', 'tunnel_url.txt');

fs.mkdirSync(path.join(__dirname, 'scratch'), { recursive: true });

function log(msg) {
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    console.log(line.trim());
    try {
        fs.appendFileSync(logFile, line);
    } catch (e) {}
}

let child = null;
let currentUrl = '';
let isRestarting = false;
let heartbeatTimer = null;

function startCloudflared() {
    if (isRestarting) return;
    isRestarting = true;

    if (child) {
        try { child.kill('SIGTERM'); } catch (e) {}
        child = null;
    }

    log("Starting Cloudflare Tunnel process for http://127.0.0.1:80...");

    const cloudflaredExe = path.join(__dirname, 'cloudflared.exe');

    child = spawn(cloudflaredExe, ['tunnel', '--protocol', 'http2', '--url', 'http://127.0.0.1:80'], {
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe']
    });

    isRestarting = false;

    function handleData(data) {
        const text = data.toString();
        try {
            fs.appendFileSync(logFile, text);
        } catch (e) {}

        const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
        if (match && match[0] !== currentUrl) {
            currentUrl = match[0];
            log(`\n========================================\nPUBLIC CLOUDFLARE URL: ${currentUrl}\nPATIENT PORTAL: ${currentUrl}/insurancee/patient/index.php\n========================================\n`);
            try {
                fs.writeFileSync(urlFile, currentUrl);
            } catch (e) {}

            startHeartbeat(currentUrl);
        }
    }

    child.stdout.on('data', handleData);
    child.stderr.on('data', handleData);

    child.on('close', (code) => {
        log(`Cloudflare process exited with code ${code}. Reconnecting in 3s...`);
        child = null;
        setTimeout(startCloudflared, 3000);
    });

    child.on('error', (err) => {
        log(`Cloudflare process error: ${err.message}. Reconnecting in 3s...`);
        child = null;
        setTimeout(startCloudflared, 3000);
    });
}

function startHeartbeat(url) {
    if (heartbeatTimer) clearInterval(heartbeatTimer);

    // Keep-alive heartbeat every 20 seconds to maintain connection
    heartbeatTimer = setInterval(() => {
        if (!currentUrl) return;

        // Ping local origin
        http.get('http://127.0.0.1:80/insurancee/patient/index.php', (res) => {
            // Local origin responsive
        }).on('error', (err) => {
            log(`[Origin Warning] Local Apache on port 80 not responding: ${err.message}`);
        });

        // Ping public tunnel
        try {
            https.get(`${currentUrl}/insurancee/patient/index.php`, (res) => {
                // Public edge responsive
            }).on('error', () => {});
        } catch (e) {}
    }, 20000);
}

process.on('uncaughtException', (err) => {
    log(`Uncaught Exception: ${err.message}`);
    setTimeout(startCloudflared, 3000);
});

process.on('unhandledRejection', (reason) => {
    log(`Unhandled Rejection: ${reason}`);
    setTimeout(startCloudflared, 3000);
});

startCloudflared();
