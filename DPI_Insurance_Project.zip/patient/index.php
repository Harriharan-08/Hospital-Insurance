<?php
/**
 * Public Patient Claim Form - Google Forms Material Design Edition
 * 
 * Publicly accessible form for patients anywhere on the web.
 * Submissions save directly into the Hospital Officer Dashboard.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/database.php';

$csrfToken = generateCSRFToken();

$errors = $_SESSION['patient_errors'] ?? [];
$formData = $_SESSION['patient_form_data'] ?? [];

unset($_SESSION['patient_errors']);
unset($_SESSION['patient_form_data']);

// Available hospitals for claim submission
$hospitals = [
    'City Central Hospital',
    'City General Hospital'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Patient Insurance Claim Submission - Google Forms Edition</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Roboto', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: #f8fafc;
            min-height: 100vh;
            color: #0f172a;
            padding-bottom: 60px;
        }

        /* Google Forms Header Card */
        .gform-container {
            max-width: 770px;
            margin: 0 auto;
        }

        .gform-header-card {
            background-color: #ffffff;
            border-radius: 12px;
            border: 1px solid #cbd5e1;
            overflow: hidden;
            margin-top: 20px;
            margin-bottom: 14px;
            box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.12);
        }

        .gform-header-accent {
            height: 10px;
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        }

        .gform-header-body {
            padding: 24px 28px;
        }

        .gform-title {
            font-size: 30px;
            font-weight: 400;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .gform-desc {
            font-size: 14px;
            color: #475569;
            line-height: 1.5;
            margin-bottom: 16px;
        }

        .gform-required-note {
            color: #dc2626;
            font-size: 13px;
            font-weight: 400;
            border-top: 1px solid #e2e8f0;
            padding-top: 12px;
        }

        /* Google Forms Question Cards */
        .gform-card {
            background-color: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 14px;
            box-shadow: 0 4px 12px rgba(15, 23, 42, 0.06);
            transition: border-color 0.2s, box-shadow 0.2s, border-left-width 0.2s;
            border-left: 1px solid #cbd5e1;
        }

        .gform-card:focus-within, .gform-card.active-card {
            border-left: 6px solid #2563eb !important;
            box-shadow: 0 10px 25px -5px rgba(37, 99, 235, 0.15);
        }

        .gform-section-title {
            font-size: 18px;
            font-weight: 600;
            color: #2563eb;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .gform-label {
            font-size: 15px;
            font-weight: 500;
            color: #1e293b;
            margin-bottom: 8px;
            display: block;
        }

        .gform-asterisk {
            color: #dc2626;
            margin-left: 3px;
        }

        .gform-input {
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            padding: 12px 14px;
            font-size: 15px;
            color: #0f172a;
            background-color: #ffffff;
            width: 100%;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .gform-input:focus {
            border-color: #2563eb;
            outline: none;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }

        .gform-hint {
            font-size: 12px;
            color: #64748b;
            margin-top: 6px;
        }

        /* Action Buttons */
        .btn-gform-submit {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            color: #ffffff;
            border: none;
            border-radius: 6px;
            padding: 12px 32px;
            font-weight: 600;
            font-size: 14px;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
            transition: all 0.2s ease;
        }

        .btn-gform-submit:hover {
            background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
            color: #ffffff;
            box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
        }

        .btn-gform-clear {
            color: #2563eb;
            background: transparent;
            border: none;
            font-weight: 600;
            font-size: 14px;
            padding: 10px 16px;
            border-radius: 6px;
            transition: background-color 0.2s;
        }

        .btn-gform-clear:hover {
            background-color: #eff6ff;
            color: #1d4ed8;
        }

        .gform-footer {
            text-align: center;
            font-size: 12px;
            color: #70757a;
            margin-top: 24px;
        }

        @media (max-width: 768px) {
            .gform-container { padding: 0 10px; }
            .gform-header-body { padding: 20px 18px; }
            .gform-card { padding: 18px 16px; }
            .gform-input { font-size: 16px !important; min-height: 48px; }
        }
    </style>
</head>
<body>

    <div class="gform-container">

        <!-- GOOGLE FORMS HEADER CARD -->
        <div class="gform-header-card">
            <div class="gform-header-accent"></div>
            <div class="gform-header-body">
                <h1 class="gform-title"><i class="bi bi-file-earmark-medical-fill text-primary me-2"></i>Patient Insurance Claim Form</h1>
                <p class="gform-desc">
                    Official Public Patient Insurance Claim Portal. Please complete all questions below. Submissions are transmitted directly to the <strong>Hospital Officer Dashboard</strong> for verification and claim processing.
                </p>
                <div class="gform-required-note">
                    <span class="gform-asterisk">*</span> Indicates required question
                </div>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="gform-card border-danger">
                <h6 class="fw-bold text-danger mb-2"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following issues:</h6>
                <ul class="mb-0 small ps-3 text-danger">
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="submit-process.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">

            <!-- CARD 1: PATIENT PERSONAL DETAILS -->
            <div class="gform-card" onclick="setActiveCard(this)">
                <div class="gform-section-title">
                    <i class="bi bi-person-circle"></i> Section 1: Patient Personal Information
                </div>

                <div class="mb-4">
                    <label for="full_name" class="gform-label">Patient Full Name <span class="gform-asterisk">*</span></label>
                    <input type="text" class="gform-input" id="full_name" name="full_name" required placeholder="Enter your complete legal name" value="<?= htmlspecialchars($formData['full_name'] ?? '') ?>">
                </div>

                <!-- ROW 1: DOB & AGE -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="date_of_birth" class="gform-label">Date of Birth <span class="gform-asterisk">*</span></label>
                        <input type="date" class="gform-input" id="date_of_birth" name="date_of_birth" required max="<?= date('Y-m-d') ?>" min="1920-01-01" value="<?= htmlspecialchars($formData['date_of_birth'] ?? '') ?>" onchange="updateAgeAndFields()" oninput="updateAgeAndFields()">
                    </div>
                    <div class="col-md-6">
                        <label for="calculated_age" class="gform-label">Age <span class="gform-asterisk">*</span></label>
                        <input type="text" class="gform-input bg-light fw-bold text-primary" id="calculated_age" name="calculated_age" readonly value="<?= htmlspecialchars($formData['calculated_age'] ?? '') ?>">
                    </div>
                </div>

                <!-- ROW 2: GENDER & EMAIL -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="gender" class="gform-label">Gender <span class="gform-asterisk">*</span></label>
                        <select class="gform-input" id="gender" name="gender" required>
                            <option value="">Choose Gender</option>
                            <option value="Male" <?= ($formData['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                            <option value="Female" <?= ($formData['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                            <option value="Other" <?= ($formData['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="gform-label">Email <span class="gform-asterisk">*</span></label>
                        <input type="email" class="gform-input" id="email" name="email" required placeholder="patient@gmail.com" value="<?= htmlspecialchars($formData['email'] ?? '') ?>">
                        <div class="gform-hint">Claim verification status will be emailed to this address.</div>
                    </div>
                </div>

                <!-- ADULT PATIENT CONTACT FIELDS (Visible if Age >= 18) -->
                <div id="adultFieldsBox" class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="phone" class="gform-label">Patient Primary Phone Number <span class="gform-asterisk">*</span></label>
                        <input type="tel" class="gform-input" id="phone" name="phone" placeholder="Enter 10-digit mobile number" value="<?= htmlspecialchars($formData['phone'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="alt_phone" class="gform-label">Alternate Mobile Number (Optional)</label>
                        <input type="tel" class="gform-input" id="alt_phone" name="alt_phone" placeholder="Enter secondary contact number" value="<?= htmlspecialchars($formData['alt_phone'] ?? '') ?>">
                    </div>
                </div>

                <!-- MINOR PATIENT GUARDIAN FIELDS (Visible if Age < 18) -->
                <div id="minorFieldsBox" class="row g-3 mb-4" style="display: none;">
                    <div class="col-md-6">
                        <label for="guardian_name" class="gform-label">Parent / Guardian Name <span class="gform-asterisk">*</span></label>
                        <input type="text" class="gform-input" id="guardian_name" name="guardian_name" placeholder="Enter parent or guardian's full name" value="<?= htmlspecialchars($formData['guardian_name'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="guardian_phone" class="gform-label">Parent / Guardian Mobile Number <span class="gform-asterisk">*</span></label>
                        <input type="tel" class="gform-input" id="guardian_phone" name="guardian_phone" placeholder="Enter parent or guardian contact number" value="<?= htmlspecialchars($formData['guardian_phone'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-2">
                    <label for="address" class="gform-label">Residential Address <span class="gform-asterisk">*</span></label>
                    <textarea class="gform-input" id="address" name="address" rows="3" required placeholder="Enter full residential address"><?= htmlspecialchars($formData['address'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- CARD 2: TREATMENT & HOSPITAL DETAILS -->
            <div class="gform-card" onclick="setActiveCard(this)">
                <div class="gform-section-title">
                    <i class="bi bi-hospital"></i> Section 2: Hospital & Treatment Details
                </div>

                <div class="mb-4">
                    <label for="hospital_name" class="gform-label">Hospital Name <span class="gform-asterisk">*</span></label>
                    <select class="gform-input" id="hospital_name" name="hospital_name" required>
                        <option value="">Select Hospital</option>
                        <?php foreach ($hospitals as $h): ?>
                            <option value="<?= htmlspecialchars($h) ?>" <?= ($formData['hospital_name'] ?? '') === $h ? 'selected' : '' ?>><?= htmlspecialchars($h) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="admission_date" class="gform-label">Admission Date <span class="gform-asterisk">*</span></label>
                    <input type="date" class="gform-input" id="admission_date" name="admission_date" required value="<?= htmlspecialchars($formData['admission_date'] ?? date('Y-m-d')) ?>">
                </div>

                <div class="mb-2">
                    <label for="treatment_details" class="gform-label">Treatment Details / Diagnosis Summary <span class="gform-asterisk">*</span></label>
                    <textarea class="gform-input" id="treatment_details" name="treatment_details" rows="3" required placeholder="Describe diagnosis, treatment received, or surgery"><?= htmlspecialchars($formData['treatment_details'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- CARD 3: INSURANCE POLICY DETAILS -->
            <div class="gform-card" onclick="setActiveCard(this)">
                <div class="gform-section-title">
                    <i class="bi bi-shield-check"></i> Section 3: Insurance Policy Information
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label for="insurance_company" class="gform-label">Insurance Provider Company <span class="gform-asterisk">*</span></label>
                        <input type="text" class="gform-input" id="insurance_company" name="insurance_company" required placeholder="e.g. Star Health / ICICI Lombard" value="<?= htmlspecialchars($formData['insurance_company'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="policy_number" class="gform-label">Policy Number <span class="gform-asterisk">*</span></label>
                        <input type="text" class="gform-input" id="policy_number" name="policy_number" required placeholder="e.g. POL-98765432" value="<?= htmlspecialchars($formData['policy_number'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="policy_valid_date" class="gform-label">Policy Valid Date <span class="gform-asterisk">*</span></label>
                        <input type="date" class="gform-input" id="policy_valid_date" name="policy_valid_date" required value="<?= htmlspecialchars($formData['policy_valid_date'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-2">
                    <label for="policy_card" class="gform-label">Upload Policy Card (PDF Format) <span class="gform-asterisk">*</span></label>
                    <input type="file" class="gform-input" id="policy_card" name="policy_card" accept=".pdf,application/pdf" required>
                    <div class="gform-hint">Upload your insurance policy document in PDF format (Max 10MB).</div>
                </div>
            </div>

            <!-- CARD 4: TREATMENT DOCUMENT UPLOAD -->
            <div class="gform-card" onclick="setActiveCard(this)">
                <div class="gform-section-title">
                    <i class="bi bi-paperclip"></i> Section 4: Hospital Treatment Bill / Medical Summary
                </div>

                <div class="mb-2">
                    <label for="treatment_doc" class="gform-label">Upload Hospital Treatment Document (PDF Format) <span class="gform-asterisk">*</span></label>
                    <input type="file" class="gform-input" id="treatment_doc" name="treatment_doc" accept=".pdf,application/pdf" required>
                    <div class="gform-hint">Upload hospital discharge summary or medical treatment bill in PDF format (Max 10MB).</div>
                </div>
            </div>

            <!-- CARD 5: AADHAAR eKYC IN-PAGE VERIFICATION -->
            <div class="gform-card" onclick="setActiveCard(this)">
                <div class="gform-section-title">
                    <i class="bi bi-fingerprint"></i> Section 5: Aadhaar Offline eKYC Verification
                </div>

                <div class="p-3 bg-light rounded border mb-3">
                    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3">
                        <div>
                            <h6 class="fw-bold mb-1"><i class="bi bi-shield-lock-fill text-primary me-2"></i>In-Page Aadhaar eKYC Verification</h6>
                            <p class="small text-muted mb-0">Upload your Aadhaar Offline XML / ZIP file and enter your 4-digit password to verify your Name & Date of Birth in-page.</p>
                        </div>
                        <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2">
                            <span id="ekycBadgeContainer">
                                <span class="badge bg-warning text-dark px-3 py-2 fs-6"><i class="bi bi-exclamation-circle me-1"></i>NOT VERIFIED YET</span>
                            </span>
                            <button type="button" class="btn btn-primary fw-bold px-3 py-2 text-nowrap w-100 w-sm-auto" onclick="openEkycModal()">
                                <i class="bi bi-shield-lock-fill me-1"></i>VERIFY AADHAAR eKYC
                            </button>
                        </div>
                    </div>
                    <div id="ekycStatusAlert" class="mt-3 d-none alert"></div>
                </div>

                <input type="hidden" name="ekyc_verified" id="ekyc_verified" value="0">
            </div>

            <!-- GOOGLE FORMS ACTION BAR -->
            <div class="d-flex justify-content-between align-items-center mt-4 px-2">
                <div id="submitBtnContainer" style="display: none;">
                    <button type="submit" class="btn-gform-submit">
                        <i class="bi bi-send-fill me-2"></i>SUBMIT
                    </button>
                </div>
                <div id="submitBtnNotice" class="alert alert-warning text-center fw-bold py-2 px-3 mb-0 w-100 me-3">
                    <i class="bi bi-info-circle-fill me-2"></i>Please complete Section 5 Aadhaar eKYC verification above to unlock the SUBMIT button.
                </div>
                <button type="reset" class="btn-gform-clear" onclick="location.reload();">Clear form</button>
            </div>

        </form>

        <div class="gform-footer">
            This form was created inside Hospital Insurance Claim System. Submissions are transmitted directly to the Officer Dashboard.
        </div>

    </div>

    <!-- IN-PAGE eKYC VERIFICATION MODAL POPUP -->
    <div class="modal fade" id="ekycModal" tabindex="-1" aria-labelledby="ekycModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title fw-bold" id="ekycModalLabel"><i class="bi bi-shield-lock-fill me-2 text-primary"></i>Aadhaar Offline eKYC Verification Portal</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    
                    <div class="alert alert-info small mb-4">
                        <i class="bi bi-info-circle-fill me-2"></i>Upload your Aadhaar Offline eKYC XML file or password-protected ZIP file downloaded from myAadhaar portal. Enter your 4-digit Share Code / Password to verify in-page.
                    </div>

                    <form id="ekycForm" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="ekyc_file" class="form-label fw-bold">Select Aadhaar Offline ZIP or XML File *</label>
                            <input type="file" class="form-control" id="ekyc_file" name="ekyc_file" accept=".zip,.xml,application/zip,application/x-zip-compressed,text/xml,application/xml" required>
                            <div class="form-text small">Accepted formats: <code>.zip</code> or <code>.xml</code> (Max 5MB).</div>
                        </div>

                        <div class="mb-3">
                            <label for="share_code" class="form-label fw-bold">4-Digit Share Code / Password *</label>
                            <input type="password" class="form-control" id="share_code" name="share_code" maxlength="4" minlength="4" pattern="\d{4}" placeholder="Enter 4-digit numeric share code (e.g. 1234)" required>
                            <div class="form-text small">Must be the 4-digit password set when downloading the Aadhaar Offline ZIP file.</div>
                        </div>

                        <div id="modalAlert" class="alert d-none mb-3"></div>

                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="button" id="btnVerifyEkyc" class="btn btn-success fw-bold px-4" onclick="runEkycVerification()">
                                <i class="bi bi-shield-check me-1"></i>VERIFY AADHAAR eKYC
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script>
    function setActiveCard(cardEl) {
        document.querySelectorAll('.gform-card').forEach(c => c.classList.remove('active-card'));
        cardEl.classList.add('active-card');
    }

    function updateAgeAndFields() {
        const dobInput = document.getElementById('date_of_birth').value;
        const ageBadge = document.getElementById('ageBadge');
        const ageInput = document.getElementById('calculated_age');
        const adultBox = document.getElementById('adultFieldsBox');
        const minorBox = document.getElementById('minorFieldsBox');
        const phoneInput = document.getElementById('phone');
        const guardianNameInput = document.getElementById('guardian_name');
        const guardianPhoneInput = document.getElementById('guardian_phone');

        if (!dobInput) {
            if (ageBadge) {
                ageBadge.className = 'badge bg-secondary opacity-75';
                ageBadge.textContent = 'Select DOB';
            }
            if (ageInput) ageInput.value = '';
            return;
        }

        const dob = new Date(dobInput);
        const today = new Date();
        let age = today.getFullYear() - dob.getFullYear();
        const monthDiff = today.getMonth() - dob.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
            age--;
        }

        if (isNaN(age) || age < 0) {
            if (ageBadge) {
                ageBadge.className = 'badge bg-secondary';
                ageBadge.textContent = 'Invalid DOB';
            }
            if (ageInput) ageInput.value = '';
            return;
        }

        if (ageInput) {
            ageInput.value = age + ' (' + (age < 18 ? 'Minor' : 'Adult') + ')';
        }

        if (age < 18) {
            // MINOR PATIENT (< 18 YEARS)
            if (ageBadge) {
                ageBadge.className = 'badge bg-warning text-dark fs-6 px-3 py-1';
                ageBadge.innerHTML = '<i class="bi bi-person-fill me-1"></i>Age: ' + age + ' Years (Minor)';
            }
            
            // Hide Adult Phone Fields, Remove Required & Disable to avoid mobile HTML5 validation block
            adultBox.style.display = 'none';
            phoneInput.required = false;
            phoneInput.disabled = true;
            
            // Show Guardian Name & Guardian Phone Fields, Set Required & Enable
            minorBox.style.display = 'flex';
            guardianNameInput.required = true;
            guardianNameInput.disabled = false;
            guardianPhoneInput.required = true;
            guardianPhoneInput.disabled = false;
        } else {
            // ADULT PATIENT (>= 18 YEARS)
            if (ageBadge) {
                ageBadge.className = 'badge bg-success fs-6 px-3 py-1';
                ageBadge.innerHTML = '<i class="bi bi-person-check-fill me-1"></i>Age: ' + age + ' Years (Adult)';
            }
            
            // Show Adult Phone Fields, Set Required & Enable
            adultBox.style.display = 'flex';
            phoneInput.required = true;
            phoneInput.disabled = false;
            
            // Hide Guardian Fields, Remove Required & Disable to avoid mobile HTML5 validation block
            minorBox.style.display = 'none';
            guardianNameInput.required = false;
            guardianNameInput.disabled = true;
            guardianPhoneInput.required = false;
            guardianPhoneInput.disabled = true;
        }
    }

    function openEkycModal() {
        const modalEl = document.getElementById('ekycModal');
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            const modalObj = bootstrap.Modal.getOrCreateInstance(modalEl);
            modalObj.show();
        } else {
            modalEl.classList.add('show');
            modalEl.style.display = 'block';
            modalEl.removeAttribute('aria-hidden');
            document.body.classList.add('modal-open');
        }
    }

    function runEkycVerification() {
        const formName = document.getElementById('full_name').value.trim();
        const formDob = document.getElementById('date_of_birth').value.trim();
        const formPhone = (document.getElementById('phone')?.value || document.getElementById('guardian_phone')?.value || '').trim();
        const formEmail = document.getElementById('email')?.value.trim() || '';
        const fileInput = document.getElementById('ekyc_file');
        const shareCode = document.getElementById('share_code').value.trim();
        const modalAlert = document.getElementById('modalAlert');
        const btnVerify = document.getElementById('btnVerifyEkyc');

        modalAlert.className = 'alert d-none';

        if (!formName || !formDob) {
            modalAlert.className = 'alert alert-danger';
            modalAlert.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>Please enter Patient Full Name and Date of Birth on the form before performing eKYC.';
            return;
        }

        if (!fileInput.files || fileInput.files.length === 0) {
            modalAlert.className = 'alert alert-danger';
            modalAlert.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>Please select your Aadhaar Offline XML or ZIP file.';
            return;
        }

        if (!shareCode || !/^\d{4}$/.test(shareCode)) {
            modalAlert.className = 'alert alert-danger';
            modalAlert.innerHTML = '<i class="bi bi-key-fill me-2"></i>Please enter the valid 4-digit numeric Share Code / Password set during Aadhaar ZIP download.';
            document.getElementById('share_code').focus();
            return;
        }

        btnVerify.disabled = true;
        btnVerify.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Verifying Aadhaar...';

        const formData = new FormData();
        formData.append('form_name', formName);
        formData.append('form_dob', formDob);
        formData.append('form_phone', formPhone);
        formData.append('form_email', formEmail);
        formData.append('share_code', shareCode);
        formData.append('ekyc_file', fileInput.files[0]);

        fetch('verify-ekyc-api.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            btnVerify.disabled = false;
            btnVerify.innerHTML = '<i class="bi bi-shield-check me-1"></i>VERIFY AADHAAR eKYC';

            if (data.success && data.matched) {
                // SUCCESSFUL MATCH!
                modalAlert.className = 'alert alert-success';
                modalAlert.innerHTML = '<i class="bi bi-check-circle-fill me-2"></i>' + data.message;

                // Update main form state
                document.getElementById('ekyc_verified').value = '1';
                
                const badgeContainer = document.getElementById('ekycBadgeContainer');
                if (badgeContainer) {
                    badgeContainer.innerHTML = '<span class="badge bg-success px-3 py-2 fs-6"><i class="bi bi-patch-check-fill me-1"></i>✓ eKYC VERIFIED</span>';
                }

                const statusAlert = document.getElementById('ekycStatusAlert');
                if (statusAlert) {
                    statusAlert.className = 'mt-3 alert alert-success d-block';
                    statusAlert.innerHTML = '<strong><i class="bi bi-patch-check-fill me-2"></i>eKYC Verification Successful!</strong>';
                }

                // UNLOCK SUBMIT BUTTON!
                document.getElementById('submitBtnContainer').style.display = 'block';
                document.getElementById('submitBtnNotice').style.display = 'none';

                // Close modal after 1.5s
                setTimeout(() => {
                    const modalEl = document.getElementById('ekycModal');
                    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                        const modalObj = bootstrap.Modal.getInstance(modalEl);
                        if (modalObj) modalObj.hide();
                    } else {
                        modalEl.style.display = 'none';
                        document.body.classList.remove('modal-open');
                    }
                }, 1500);

            } else {
                // MATCH FAILED OR INVALID SHARE CODE
                modalAlert.className = 'alert alert-danger';
                modalAlert.innerHTML = '<i class="bi bi-x-circle-fill me-2"></i>' + (data.message || 'Aadhaar eKYC Verification Failed.');

                // LOCK SUBMIT BUTTON!
                document.getElementById('ekyc_verified').value = '0';
                document.getElementById('submitBtnContainer').style.display = 'none';
                document.getElementById('submitBtnNotice').style.display = 'block';

                const badgeContainer = document.getElementById('ekycBadgeContainer');
                if (badgeContainer) {
                    badgeContainer.innerHTML = '<span class="badge bg-danger px-3 py-2 fs-6"><i class="bi bi-x-circle-fill me-1"></i>VERIFICATION FAILED</span>';
                }

                const statusAlert = document.getElementById('ekycStatusAlert');
                if (statusAlert) {
                    statusAlert.className = 'mt-3 alert alert-danger d-block';
                    statusAlert.innerHTML = '<strong><i class="bi bi-x-circle-fill me-2"></i>Verification Failed:</strong> ' + data.message;
                }
            }
        })
        .catch(error => {
            btnVerify.disabled = false;
            btnVerify.innerHTML = '<i class="bi bi-shield-check me-1"></i>VERIFY AADHAAR eKYC';
            modalAlert.className = 'alert alert-danger';
            modalAlert.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>An error occurred during verification. Please try again.';
        });
    }

    function resetEkycVerification() {
        const isVerified = document.getElementById('ekyc_verified').value === '1';
        if (isVerified) {
            document.getElementById('ekyc_verified').value = '0';
            const badgeContainer = document.getElementById('ekycBadgeContainer');
            if (badgeContainer) {
                badgeContainer.innerHTML = '<span class="badge bg-secondary px-3 py-2 fs-6"><i class="bi bi-clock-history me-1"></i>VERIFICATION REQUIRED</span>';
            }
            const statusAlert = document.getElementById('ekycStatusAlert');
            if (statusAlert) {
                statusAlert.className = 'mt-3 alert alert-secondary d-block';
                statusAlert.innerHTML = '<small><i class="bi bi-info-circle me-1"></i>Form details modified. Please click <strong>VERIFY AADHAAR eKYC</strong> above to re-confirm your Aadhaar details.</small>';
            }
            // Lock SUBMIT button immediately!
            document.getElementById('submitBtnContainer').style.display = 'none';
            document.getElementById('submitBtnNotice').style.display = 'block';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        updateAgeAndFields();
        
        const nameInput = document.getElementById('full_name');
        const dobInput = document.getElementById('date_of_birth');
        if (nameInput) nameInput.addEventListener('input', resetEkycVerification);
        if (dobInput) dobInput.addEventListener('change', resetEkycVerification);
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
