<?php
/**
 * Patient Claim Submission Backend Processor
 * 
 * Enforces PDO Transaction, CSRF validation, strict MIME/extension file validation,
 * randomized SHA-256 file storage, unique PAT- / CLM- reference generation, and Audit Logging.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/eKycPdfGenerator.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

// 0. Check if POST data was discarded by PHP due to file upload size exceeding post_max_size
if (empty($_POST) && isset($_SERVER['CONTENT_LENGTH']) && (int)$_SERVER['CONTENT_LENGTH'] > 0) {
    $_SESSION['patient_errors'] = ["Uploaded file size exceeds the server's post_max_size limit. Please ensure each uploaded PDF is under 10MB."];
    session_write_close();
    header("Location: index.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['patient_errors'] = ["Security validation failed. Invalid CSRF token. Please refresh the page and try again."];
    session_write_close();
    header("Location: index.php");
    exit();
}

$_SESSION['patient_form_data'] = $_POST;
$errors = [];

// 1. Capture & Sanitize Text Fields
$fullName         = sanitizeInput($_POST['full_name'] ?? '');
$guardianName     = sanitizeInput($_POST['guardian_name'] ?? '');
$dob              = sanitizeInput($_POST['date_of_birth'] ?? '');
$gender           = sanitizeInput($_POST['gender'] ?? '');
$phone            = sanitizeInput($_POST['phone'] ?? '');
$altPhone         = sanitizeInput($_POST['alt_phone'] ?? '');
$email            = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$guardianPhone    = sanitizeInput($_POST['guardian_phone'] ?? '');
$address          = sanitizeInput($_POST['address'] ?? '');
$hospitalName     = sanitizeInput($_POST['hospital_name'] ?? '');
$admissionDate    = sanitizeInput($_POST['admission_date'] ?? '');
$treatmentDetails = sanitizeInput($_POST['treatment_details'] ?? '');
$insuranceCompany = sanitizeInput($_POST['insurance_company'] ?? '');
$policyNumber     = sanitizeInput($_POST['policy_number'] ?? '');
$policyValidDate  = sanitizeInput($_POST['policy_valid_date'] ?? '');

// Calculate patient age in years
$calcAge = 0;
try {
    $dobObj = new DateTime($dob);
    $todayObj = new DateTime('today');
    $calcAge = $dobObj->diff($todayObj)->y;
} catch (Exception $e) {
    $errors[] = "Please enter a valid Date of Birth.";
}

// 2. Validate Text Input Constraints
if (empty($fullName) || empty($dob) || empty($gender) || empty($address)) {
    $errors[] = "Please fill in all required patient details.";
}

if (!$email) {
    $errors[] = "Please enter a valid Email.";
}

if ($calcAge < 18) {
    // Minor Patient (< 18): Require Guardian Name and Guardian Phone
    if (empty($guardianName) || empty($guardianPhone)) {
        $errors[] = "For patients under 18 years old, Parent / Guardian Name and Mobile Number are required.";
    }
    if (empty($phone)) {
        $phone = $guardianPhone;
    }
    $altPhone = null;
} else {
    // Adult Patient (>= 18): Require Patient Phone Number
    if (empty($phone)) {
        $errors[] = "Please enter the patient's primary contact phone number.";
    }
    $guardianName = null;
    $guardianPhone = null;
}

if (!in_array($gender, ['Male', 'Female', 'Other'])) {
    $errors[] = "Please select a valid gender option.";
}

if (empty($hospitalName) || empty($admissionDate) || empty($treatmentDetails)) {
    $errors[] = "Please fill in all required treatment details.";
}

if (empty($insuranceCompany) || empty($policyNumber) || empty($policyValidDate)) {
    $errors[] = "Please fill in all required insurance details including Policy Valid Date.";
}

// 3. File Validation Helper Function
function validateAndPrepareUpload(array $file, array $allowedMimes, array $allowedExts, int $maxBytes, string $docType): array {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload failed for $docType. Code: " . ($file['error'] ?? UPLOAD_ERR_NO_FILE));
    }

    if ($file['size'] > $maxBytes) {
        $maxMB = round($maxBytes / 1048576, 1);
        throw new Exception("$docType file size exceeds maximum limit of {$maxMB}MB.");
    }

    $origName = basename($file['name']);
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

    // Reject dangerous executable extensions
    $forbidden = ['php', 'php3', 'php4', 'php5', 'phtml', 'phar', 'exe', 'pl', 'py', 'cgi', 'js', 'html', 'htm', 'sh', 'bat'];
    if (in_array($ext, $forbidden) || !in_array($ext, $allowedExts)) {
        throw new Exception("Invalid file extension '.{$ext}' for $docType. Allowed: " . implode(', ', $allowedExts));
    }

    // Verify MIME type using finfo
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $detectedMime = $finfo->file($file['tmp_name']);

    if (!in_array($detectedMime, $allowedMimes)) {
        throw new Exception("Invalid file type '$detectedMime' for $docType.");
    }

    // Generate randomized 32-hex storage filename
    $randomName = bin2hex(random_bytes(16)) . '.' . $ext;

    return [
        'doc_type'     => $docType,
        'tmp_name'     => $file['tmp_name'],
        'original_name'=> $origName,
        'stored_name'  => $randomName,
        'mime_type'    => $detectedMime,
        'size'         => $file['size']
    ];
}

$validatedFiles = [];
try {
    // Validate Policy Card (PDF Only)
    if (!isset($_FILES['policy_card']) || $_FILES['policy_card']['error'] == UPLOAD_ERR_NO_FILE) {
        throw new Exception("Insurance Policy Card PDF file is required.");
    }
    $validatedFiles['POLICY_CARD'] = validateAndPrepareUpload(
        $_FILES['policy_card'],
        ['application/pdf', 'application/x-pdf'],
        ['pdf'],
        10 * 1024 * 1024,
        'Policy Card'
    );

    // Validate Treatment Document (PDF Only)
    if (!isset($_FILES['treatment_doc']) || $_FILES['treatment_doc']['error'] == UPLOAD_ERR_NO_FILE) {
        throw new Exception("Treatment Document PDF file is required.");
    }
    $validatedFiles['TREATMENT_DOCUMENT'] = validateAndPrepareUpload(
        $_FILES['treatment_doc'],
        ['application/pdf', 'application/x-pdf'],
        ['pdf'],
        10 * 1024 * 1024,
        'Treatment Document'
    );

    // Validate In-Page eKYC Verification Status
    if (empty($_POST['ekyc_verified']) && empty($_SESSION['ekyc_verified_data'])) {
        throw new Exception("Aadhaar eKYC verification is required before submitting your claim. Please complete Section 5 eKYC verification.");
    }
} catch (Exception $e) {
    $errors[] = $e->getMessage();
}

if (!empty($errors)) {
    $_SESSION['patient_errors'] = $errors;
    session_write_close();
    header("Location: index.php");
    exit();
}

// Prepare Storage Directory
$uploadDir = __DIR__ . '/../uploads/documents/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$movedFiles = [];

try {
    $pdo = getDBConnection();
    $pdo->beginTransaction();

    // 4. Find Existing Patient Record or Generate New Unique Patient Reference (PAT-2026-XXXXXX)
    $existingPatient = null;

    // Search by Email (Primary identifier if provided)
    if (!empty($email)) {
        $checkEmail = $pdo->prepare("SELECT id, patient_reference FROM patients WHERE LOWER(TRIM(email)) = LOWER(TRIM(:email)) ORDER BY id ASC LIMIT 1");
        $checkEmail->execute([':email' => $email]);
        $existingPatient = $checkEmail->fetch(PDO::FETCH_ASSOC);
    }

    // Search by Full Name & Date of Birth (Secondary identifier if email was not matched)
    if (!$existingPatient && !empty($fullName) && !empty($dob)) {
        $checkNameDob = $pdo->prepare("SELECT id, patient_reference FROM patients WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(:full_name)) AND date_of_birth = :dob ORDER BY id ASC LIMIT 1");
        $checkNameDob->execute([':full_name' => $fullName, ':dob' => $dob]);
        $existingPatient = $checkNameDob->fetch(PDO::FETCH_ASSOC);
    }

    // Search by Phone Number + Name (Tertiary identifier)
    if (!$existingPatient && !empty($phone) && !empty($fullName)) {
        $checkPhone = $pdo->prepare("SELECT id, patient_reference FROM patients WHERE (phone = :phone1 OR alt_phone = :phone2 OR guardian_phone = :phone3) AND LOWER(TRIM(full_name)) = LOWER(TRIM(:full_name)) ORDER BY id ASC LIMIT 1");
        $checkPhone->execute([
            ':phone1'    => $phone,
            ':phone2'    => $phone,
            ':phone3'    => $phone,
            ':full_name' => $fullName
        ]);
        $existingPatient = $checkPhone->fetch(PDO::FETCH_ASSOC);
    }

    if ($existingPatient) {
        // Reuse the patient's existing ID and permanent Patient Reference
        $patientId  = (int)$existingPatient['id'];
        $patientRef = $existingPatient['patient_reference'];

        // Update patient demographic/contact information with latest submitted details
        $updatePatient = $pdo->prepare("
            UPDATE patients SET
                full_name      = :full_name,
                guardian_name  = COALESCE(:g_name, guardian_name),
                date_of_birth  = :dob,
                gender         = :gender,
                phone          = COALESCE(NULLIF(:phone, ''), phone),
                alt_phone      = COALESCE(NULLIF(:alt_phone, ''), alt_phone),
                email          = COALESCE(NULLIF(:email, ''), email),
                guardian_phone = COALESCE(NULLIF(:g_phone, ''), guardian_phone),
                address        = COALESCE(NULLIF(:address, ''), address),
                updated_at     = NOW()
            WHERE id = :id
        ");
        $updatePatient->execute([
            ':full_name'   => $fullName,
            ':g_name'      => $guardianName,
            ':dob'         => $dob,
            ':gender'      => $gender,
            ':phone'       => $phone,
            ':alt_phone'   => $altPhone,
            ':email'       => $email,
            ':g_phone'     => $guardianPhone,
            ':address'     => $address,
            ':id'          => $patientId
        ]);
    } else {
        // Brand new patient: Generate Unique Patient Reference (PAT-YYYY-XXXXXX)
        $patientRef = 'PAT-' . date('Y') . '-' . sprintf("%06d", random_int(100000, 999999));

        $insPatient = $pdo->prepare("
            INSERT INTO patients (patient_reference, full_name, guardian_name, date_of_birth, gender, phone, alt_phone, email, guardian_phone, address, created_at)
            VALUES (:patient_ref, :full_name, :g_name, :dob, :gender, :phone, :alt_phone, :email, :g_phone, :address, NOW())
        ");
        $insPatient->execute([
            ':patient_ref' => $patientRef,
            ':full_name'   => $fullName,
            ':g_name'      => $guardianName,
            ':dob'         => $dob,
            ':gender'      => $gender,
            ':phone'       => $phone,
            ':alt_phone'   => $altPhone,
            ':email'       => $email,
            ':g_phone'     => $guardianPhone,
            ':address'     => $address
        ]);
        $patientId = (int)$pdo->lastInsertId();
    }

    // 5. Generate Unique Claim Reference (CLM-2026-XXXXXX)
    $claimRef = 'CLM-' . date('Y') . '-' . sprintf("%06d", random_int(100000, 999999));

    $ekycVerifiedData = $_SESSION['ekyc_verified_data'] ?? null;
    $ekycJson = $ekycVerifiedData ? json_encode($ekycVerifiedData, JSON_UNESCAPED_UNICODE) : null;

    $insClaim = $pdo->prepare("
        INSERT INTO claims (claim_reference, patient_id, hospital_name, admission_date, treatment_details, insurance_company, policy_number, policy_valid_date, status, ekyc_data, created_at)
        VALUES (:claim_ref, :patient_id, :hospital_name, :admission_date, :treatment_details, :insurance_company, :policy_number, :policy_valid_date, 'EVIDENCE_SUBMITTED', :ekyc_data, NOW())
    ");
    $insClaim->execute([
        ':claim_ref'         => $claimRef,
        ':patient_id'        => $patientId,
        ':hospital_name'     => $hospitalName,
        ':admission_date'    => $admissionDate,
        ':treatment_details' => $treatmentDetails,
        ':insurance_company' => $insuranceCompany,
        ':policy_number'     => $policyNumber,
        ':policy_valid_date' => !empty($policyValidDate) ? $policyValidDate : null,
        ':ekyc_data'         => $ekycJson
    ]);
    $claimId = (int)$pdo->lastInsertId();

    // 6. Move Uploaded Files & Save Metadata into patient_documents Table
    $insDoc = $pdo->prepare("
        INSERT INTO patient_documents (claim_id, document_type, original_filename, stored_filename, mime_type, file_size, storage_path, uploaded_at)
        VALUES (:claim_id, :doc_type, :orig_name, :stored_name, :mime_type, :file_size, :storage_path, NOW())
    ");

    foreach ($validatedFiles as $typeKey => $fileInfo) {
        $targetPath = $uploadDir . $fileInfo['stored_name'];

        if (!move_uploaded_file($fileInfo['tmp_name'], $targetPath)) {
            throw new Exception("Failed to save uploaded file {$fileInfo['original_name']} to server storage.");
        }
        $movedFiles[] = $targetPath;

        $insDoc->execute([
            ':claim_id'    => $claimId,
            ':doc_type'     => $typeKey,
            ':orig_name'   => $fileInfo['original_name'],
            ':stored_name' => $fileInfo['stored_name'],
            ':mime_type'   => $fileInfo['mime_type'],
            ':file_size'   => $fileInfo['size'],
            ':storage_path'=> 'uploads/documents/' . $fileInfo['stored_name']
        ]);
    }

    // 6b. Automatically Generate and Store Official Aadhaar eKYC Verification Certificate PDF
    if ($ekycVerifiedData) {
        $ekycPdfStoredName = 'ekyc_cert_' . $claimRef . '_' . time() . '.pdf';
        $ekycPdfTarget = $uploadDir . $ekycPdfStoredName;

        $claimMeta = [
            'claim_reference'   => $claimRef,
            'patient_reference' => $patientRef,
            'hospital_name'     => $hospitalName,
            'full_name'         => $fullName,
            'date_of_birth'     => $dob,
            'gender'            => $gender,
            'guardian_name'     => $guardianName,
            'address'           => $address
        ];

        eKycPdfGenerator::generatePdf($ekycVerifiedData, $claimMeta, $ekycPdfTarget);

        if (file_exists($ekycPdfTarget)) {
            $insDoc->execute([
                ':claim_id'     => $claimId,
                ':doc_type'     => 'EKYC_SCREENSHOT',
                ':orig_name'    => 'Aadhaar_eKYC_Verification_Certificate.pdf',
                ':stored_name'  => $ekycPdfStoredName,
                ':mime_type'    => 'application/pdf',
                ':file_size'    => filesize($ekycPdfTarget),
                ':storage_path' => 'uploads/documents/' . $ekycPdfStoredName
            ]);
            $movedFiles[] = $ekycPdfTarget;
        }
    }

    $pdo->commit();

    // 7. Send Automated Email Alert Notification to Official Hospital Officers
    try {
        require_once __DIR__ . '/../config/mail.php';

        // Fetch official officer emails for the selected hospital or all active officers
        $offStmt = $pdo->prepare("SELECT email, username FROM users WHERE role = 'OFFICER' AND (hospital_name = :h_name OR hospital_name IS NULL OR hospital_name = '')");
        $offStmt->execute([':h_name' => $hospitalName]);
        $officers = $offStmt->fetchAll();

        if (empty($officers)) {
            $offStmt = $pdo->query("SELECT email, username FROM users WHERE role = 'OFFICER'");
            $officers = $offStmt->fetchAll();
        }

        // 7a. Send Acknowledgment Response Email to Patient
        if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendPatientSubmissionAcknowledgmentEmail($email, $fullName, $claimRef, $patientRef, $hospitalName, $insuranceCompany, $policyNumber);
        }

        // 7b. Send Alert Notification to Hospital Officers & Admin
        $sentEmails = [];
        foreach ($officers as $off) {
            if (!empty($off['email']) && filter_var($off['email'], FILTER_VALIDATE_EMAIL) && !in_array($off['email'], $sentEmails)) {
                sendNewClaimNotificationToOfficer($off['email'], $fullName, $claimRef, $hospitalName, $policyNumber, $insuranceCompany, $claimId);
                $sentEmails[] = $off['email'];
            }
        }

        $officialSystemEmail = getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in';
        if (!empty($officialSystemEmail) && filter_var($officialSystemEmail, FILTER_VALIDATE_EMAIL) && !in_array($officialSystemEmail, $sentEmails)) {
            sendNewClaimNotificationToOfficer($officialSystemEmail, $fullName, $claimRef, $hospitalName, $policyNumber, $insuranceCompany, $claimId);
        }

    } catch (Exception $e) {
        error_log("Failed sending official claim email notification: " . $e->getMessage());
    }

    logAuditEvent(null, 'PATIENT_CLAIM_SUBMITTED', "New Patient Claim $claimRef submitted for Patient $patientRef ($fullName) at $hospitalName");

    unset($_SESSION['patient_form_data']);
    $_SESSION['claim_success'] = [
        'patient_reference' => $patientRef,
        'claim_reference'   => $claimRef,
        'full_name'         => $fullName,
        'hospital_name'     => $hospitalName,
        'insurance_company' => $insuranceCompany
    ];

    session_write_close();
    header("Location: success.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Clean up any files moved before failure
    foreach ($movedFiles as $f) {
        if (file_exists($f)) {
            @unlink($f);
        }
    }

    $_SESSION['patient_errors'] = ["Submission error: " . $e->getMessage()];
    session_write_close();
    header("Location: index.php");
    exit();
}
