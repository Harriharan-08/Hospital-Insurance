<?php
/**
 * Patient Claim Submission Success Page - Google Forms Edition
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';

$successData = $_SESSION['claim_success'] ?? null;

if (!$successData) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Response Recorded - Patient Insurance Claim Form</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', -apple-system, sans-serif;
            background-color: #f8fafc;
            min-height: 100vh;
            color: #0f172a;
            padding-bottom: 60px;
        }

        .gform-container {
            max-width: 770px;
            margin: 0 auto;
        }

        .gform-header-card {
            background-color: #ffffff;
            border-radius: 12px;
            border: 1px solid #cbd5e1;
            overflow: hidden;
            margin-top: 24px;
            margin-bottom: 16px;
            box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.12);
        }

        .gform-header-accent {
            height: 10px;
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        }

        .gform-header-body {
            padding: 32px 28px;
        }

        .gform-title {
            font-size: 28px;
            font-weight: 400;
            color: #202124;
            margin-bottom: 12px;
        }

        .gform-desc {
            font-size: 15px;
            color: #3c4043;
            line-height: 1.6;
            margin-bottom: 24px;
        }

        .ref-box {
            background-color: #f8f9fa;
            border: 1px solid #dadce0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .gform-link {
            color: #673ab7;
            text-decoration: underline;
            font-weight: 500;
            font-size: 14px;
        }

        .gform-link:hover {
            color: #512da8;
        }
    </style>
</head>
<body>

    <div class="gform-container">

        <div class="gform-header-card">
            <div class="gform-header-accent"></div>
            <div class="gform-header-body">
                <h1 class="gform-title">Patient Insurance Claim Form</h1>
                <p class="gform-desc">
                    Your response has been recorded. Your claim details have been transmitted directly to the <strong>Hospital Officer Dashboard</strong> for verification.
                </p>

                <div class="ref-box">
                    <div class="row g-3 text-start">
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Claim Reference:</span>
                            <span class="fs-5 fw-bold text-primary"><?= htmlspecialchars($successData['claim_reference']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Patient Reference:</span>
                            <span class="fs-5 fw-bold text-primary"><?= htmlspecialchars($successData['patient_reference']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Patient Name:</span>
                            <span class="fw-bold text-dark"><?= htmlspecialchars($successData['full_name']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Hospital Name:</span>
                            <span class="fw-bold text-dark"><?= htmlspecialchars($successData['hospital_name']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Insurance Company:</span>
                            <span class="fw-bold text-dark"><?= htmlspecialchars($successData['insurance_company']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small fw-bold d-block text-uppercase">Status:</span>
                            <span class="badge bg-warning text-dark px-3 py-2 fs-6">EVIDENCE_SUBMITTED</span>
                        </div>
                    </div>
                </div>

                <div class="mb-4 text-start">
                    <a href="index.php" class="gform-link"><i class="bi bi-plus-circle me-1"></i>Submit another response</a>
                </div>
            </div>
        </div>

    </div>

</body>
</html>
