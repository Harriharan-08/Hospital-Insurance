@echo off
title Hospital Insurance Public Server & Tunnel Watchdog
cd /d "%~dp0"
echo ========================================================
echo  Hospital Insurance Public Server Launcher
echo ========================================================
echo.
echo Starting Apache, MySQL, and persistent Cloudflare Tunnel...
powershell -ExecutionPolicy Bypass -File "%~dp0scratch\run-tunnel-watchdog.ps1"
pause
