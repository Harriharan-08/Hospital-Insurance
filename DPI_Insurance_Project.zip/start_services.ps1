# Persistent Server & Tunnel Launcher for Hospital Insurance Claim System

$WorkDir = $PSScriptRoot

# 1. Find and Start MySQL Server if not running
$mysqlBin = if (Test-Path "C:\xampp\mysql\bin\mysqld.exe") { "C:\xampp\mysql\bin\mysqld.exe" } elseif (Test-Path "C:\x\mysql\bin\mysqld.exe") { "C:\x\mysql\bin\mysqld.exe" } else { $null }
$mysqlIni = if (Test-Path "C:\xampp\mysql\bin\my.ini") { "C:\xampp\mysql\bin\my.ini" } elseif (Test-Path "C:\x\mysql\bin\my.ini") { "C:\x\mysql\bin\my.ini" } else { $null }
$mysqlDir = if (Test-Path "C:\xampp\mysql") { "C:\xampp\mysql" } elseif (Test-Path "C:\x\mysql") { "C:\x\mysql" } else { $null }

$mysqlProc = Get-Process mysqld -ErrorAction SilentlyContinue
if (-not $mysqlProc -and $mysqlBin) {
    Write-Host "Starting MySQL Database Server..." -ForegroundColor Green
    Start-Process -FilePath $mysqlBin -ArgumentList "--defaults-file=$mysqlIni --standalone" -WorkingDirectory $mysqlDir -WindowStyle Hidden
} else {
    Write-Host "MySQL Database Server is running." -ForegroundColor Cyan
}

# 2. Find and Start Apache Web Server (Port 80) if not running
$apacheBin = if (Test-Path "C:\xampp\apache\bin\httpd.exe") { "C:\xampp\apache\bin\httpd.exe" } else { $null }
$apacheNet = Get-NetTCPConnection -LocalPort 80 -State Listen -ErrorAction SilentlyContinue
if (-not $apacheNet -and $apacheBin) {
    Write-Host "Starting Apache Web Server on Port 80..." -ForegroundColor Green
    Start-Process -FilePath $apacheBin -WorkingDirectory "C:\xampp\apache" -WindowStyle Hidden
} else {
    Write-Host "Apache Web Server is running on port 80." -ForegroundColor Cyan
}

# 3. Stop any orphaned cloudflared processes before starting daemon
Stop-Process -Name "cloudflared" -ErrorAction SilentlyContinue

# 4. Start Cloudflare Tunnel Auto-Manager Watchdog
Write-Host "Starting Cloudflare Public Tunnel..." -ForegroundColor Green
$tunnelScript = Join-Path $WorkDir "scratch\start-tunnel.ps1"
if (Test-Path $tunnelScript) {
    & powershell.exe -ExecutionPolicy Bypass -File $tunnelScript
}

Write-Host "All persistent services started successfully!" -ForegroundColor Green
