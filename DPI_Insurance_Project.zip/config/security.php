<?php
/**
 * Global Security Parameters, Timeouts & Session Constants
 */

// Automatically load .env file from project root if present
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
    $envLines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($envLines as $eLine) {
        $eLine = trim($eLine);
        if ($eLine === '' || strpos($eLine, '#') === 0) continue;
        if (strpos($eLine, '=') !== false) {
            list($eKey, $eVal) = explode('=', $eLine, 2);
            $eKey = trim($eKey);
            $eVal = trim($eVal, " \t\n\r\0\x0B\"'");
            if (!empty($eKey) && getenv($eKey) === false) {
                putenv("$eKey=$eVal");
                $_ENV[$eKey] = $eVal;
            }
        }
    }
}

define('APP_NAME', 'Hospital Insurance Claim System');

// Dynamically detect server protocol, host, and project base path
$subPath = '';
if (isset($_SERVER['SCRIPT_NAME'])) {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    // Normalize: remove recognized app subfolders to get project root
    $cleaned = preg_replace('#/(admin|officer|patient|public|auth|scratch|includes|config).*$#i', '', $scriptDir);
    $subPath = rtrim($cleaned, '/');
}

// Fallback subpath if running under Apache default symlink
if (empty($subPath) && isset($_SERVER['HTTP_HOST']) && (str_contains($_SERVER['HTTP_HOST'], 'localhost') || str_contains($_SERVER['HTTP_HOST'], '127.0.0.1'))) {
    $port = $_SERVER['SERVER_PORT'] ?? 80;
    if ($port != 8000) {
        $subPath = '/insurancee';
    }
}

if (isset($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_HOST'])) {
    $scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ? 'https' : 'http';
    $baseUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . $subPath;
} else {
    $envBaseUrl = getenv('APP_BASE_URL');
    $baseUrl = !empty($envBaseUrl) ? $envBaseUrl : 'http://localhost/insurancee';
}

$tunnelUrlFile = __DIR__ . '/../scratch/tunnel_url.txt';
$publicTunnelUrl = null;
if (file_exists($tunnelUrlFile)) {
    $rawUrl = trim(file_get_contents($tunnelUrlFile));
    if (!empty($rawUrl) && strpos($rawUrl, 'http') === 0) {
        $publicTunnelUrl = rtrim($rawUrl, '/') . '/insurancee';
    }
}

// Local network IP for same Wi-Fi mobile devices
$lanIp = gethostbyname(gethostname());
$lanBaseUrl = ($lanIp && $lanIp !== '127.0.0.1') ? "http://{$lanIp}/insurancee" : 'http://localhost/insurancee';

define('APP_BASE_URL', rtrim($baseUrl, '/'));
define('APP_PUBLIC_URL', $publicTunnelUrl ?: $lanBaseUrl);
define('APP_LAN_URL', $lanBaseUrl);

// emSigner (eMudhra) Manage AuthToken Key
define('EMSIGNER_AUTH_TOKEN', getenv('EMSIGNER_AUTH_TOKEN') ?: '460ce3ef-fca2-4cc0-82d6-638ed1d2f31c');

// Rate Limiting & Lockout Parameters
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_MINUTES', 15);

// Email OTP Bounds
define('OTP_EXPIRATION_MINUTES', 10);
define('RESEND_COOLDOWN_SECONDS', 60);
define('MAX_OTP_ATTEMPTS', 5);

// Password Reset Bounds
define('PASSWORD_RESET_EXPIRATION_HOURS', 1);

// CSRF & Session Form Token Key
define('CSRF_TOKEN_NAME', 'csrf_token');

// Session Lifetime Parameters (30 Days Persistent Access)
define('SESSION_LIFETIME', 2592000); // 30 days in seconds

// Session Authentication States
define('AUTH_STATE_UNAUTHENTICATED', 'UNAUTHENTICATED');
define('AUTH_STATE_2FA_PENDING', '2FA_PENDING');
define('AUTH_STATE_FULLY_AUTHENTICATED', 'FULLY_AUTHENTICATED');

// Google OAuth 2.0 Configuration
define('GOOGLE_CLIENT_ID', getenv('GOOGLE_CLIENT_ID') ?: '');
define('GOOGLE_CLIENT_SECRET', getenv('GOOGLE_CLIENT_SECRET') ?: '');
define('GOOGLE_REDIRECT_URI', getenv('GOOGLE_REDIRECT_URI') ?: (APP_BASE_URL . '/auth/google-callback.php'));

/**
 * Masks an email address for privacy (e.g., johndoe@gmail.com -> j***e@gmail.com)
 */
function maskEmailAddress(string $email): string {
    $email = trim($email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return $email;
    }
    list($name, $domain) = explode('@', $email, 2);
    $len = strlen($name);
    if ($len <= 2) {
        $maskedName = substr($name, 0, 1) . '***';
    } else {
        $maskedName = substr($name, 0, 1) . str_repeat('*', min(4, $len - 2)) . substr($name, -1);
    }
    return $maskedName . '@' . $domain;
}


