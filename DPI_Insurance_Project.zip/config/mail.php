<?php
/**
 * Real PHPMailer SMTP Transport & Email Template Engine
 */

require_once __DIR__ . '/security.php';

// Automatically load .env file from project root if present
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
    $envLines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($envLines as $eLine) {
        $eLine = trim($eLine);
        if ($eLine === '' || strpos($eLine, '#') === 0) continue;
        if (strpos($eLine, '=') !== false) {
            list($eKey, $eVal) = explode('=', $eLine, 2);
            $eKey = trim($eKey);
            $eVal = trim($eVal, " \t\n\r\0\x0B\"'");
            if (!empty($eKey) && getenv($eKey) === false) {
                putenv("$eKey=$eVal");
                $_ENV[$eKey] = $eVal;
            }
        }
    }
}

// Composer Autoloader for PHPMailer
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

// SMTP Transport Parameters
define('SMTP_HOST', getenv('SMTP_HOST') ?: 'smtp.gmail.com');
define('SMTP_PORT', getenv('SMTP_PORT') ?: 587);
define('SMTP_USERNAME', getenv('SMTP_USERNAME') ?: 'noreply.hospital.insurance@gmail.com');
define('SMTP_PASSWORD', getenv('SMTP_PASSWORD') ?: 'sample_app_password');
define('MAIL_FROM', getenv('MAIL_FROM') ?: (getenv('SMTP_USERNAME') ?: 'noreply.hospital.insurance@gmail.com'));
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: 'Hospital Insurance Claim System');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Sends a real HTML Email OTP via SMTP.
 */
function sendOTPEmail(string $toEmail, string $toName, string $rawOtp): bool {
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer class not found. Ensure composer install has been executed.");
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = 'Email OTP Verification Code - ' . APP_NAME;
        
        $body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;'>
            <h2 style='color: #2563eb; text-align: center;'>" . htmlspecialchars(APP_NAME) . "</h2>
            <hr style='border: 0; border-top: 1px solid #eeeeee;'>
            <p>Dear <strong>" . htmlspecialchars($toName) . "</strong>,</p>
            <p>Thank you for registering as a Hospital Officer. Please use the 6-digit verification OTP code below to verify your email address:</p>
            <div style='background-color: #f1f5f9; text-align: center; padding: 15px; border-radius: 6px; font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #1e293b; margin: 20px 0;'>
                " . htmlspecialchars($rawOtp) . "
            </div>
            <p style='color: #64748b; font-size: 14px;'>This code is valid for <strong>" . OTP_EXPIRATION_MINUTES . " minutes</strong>. Do not share this OTP code with anyone.</p>
            <hr style='border: 0; border-top: 1px solid #eeeeee;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center;'>If you did not request this registration, please ignore this email.</p>
        </div>";

        $mail->Body    = $body;
        $mail->AltBody = "Your verification OTP code for " . APP_NAME . " is: " . $rawOtp;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer SMTP Exception: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Sends a HTML Email OTP for Google Sign-In verification via SMTP.
 */
function sendGoogleOTPEmail(string $toEmail, ?string $toName, string $rawOtp): bool {
    $toName = !empty($toName) ? $toName : 'Google User';
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer class not found. Ensure composer install has been executed.");
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = 'Google Login Verification Code - ' . APP_NAME;
        
        $body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e0e0e0; border-radius: 12px; background-color: #ffffff;'>
            <div style='text-align: center; margin-bottom: 20px;'>
                <h2 style='color: #2563eb; margin-bottom: 4px;'>" . htmlspecialchars(APP_NAME) . "</h2>
                <span style='color: #64748b; font-size: 14px;'>Google Sign-In Verification</span>
            </div>
            <hr style='border: 0; border-top: 1px solid #eeeeee;'>
            <p style='font-size: 15px; color: #1e293b;'>Hello <strong>" . htmlspecialchars($toName) . "</strong>,</p>
            <p style='color: #475569; font-size: 14px; line-height: 1.5;'>
                You recently signed in with Google using <strong>" . htmlspecialchars($toEmail) . "</strong>. Please use the 6-digit OTP verification code below to complete your login:
            </p>
            <div style='background-color: #f1f5f9; text-align: center; padding: 18px; border-radius: 8px; font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #0f172a; margin: 24px 0; border: 1px dashed #cbd5e1;'>
                " . htmlspecialchars($rawOtp) . "
            </div>
            <p style='color: #64748b; font-size: 13px;'>This code is valid for <strong>" . OTP_EXPIRATION_MINUTES . " minutes</strong>. Do not share this OTP code with anyone.</p>
            <hr style='border: 0; border-top: 1px solid #eeeeee;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center;'>If you did not initiate this sign-in request, please ignore this email.</p>
        </div>";

        $mail->Body    = $body;
        $mail->AltBody = "Your Google Sign-In verification OTP code for " . APP_NAME . " is: " . $rawOtp;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Google OTP SMTP Exception: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Sends a HTML Email Notification to the Patient regarding their Claim Status (DOCUMENTS VERIFIED / REJECTED).
 */
function sendClaimStatusNotificationEmail(string $patientEmail, string $patientName, string $claimRef, string $status, string $officerNotes = ''): bool {
    $normalizedStatus = strtoupper(trim($status));
    $isVerified = in_array($normalizedStatus, ['OFFICER_VERIFIED', 'VERIFIED', 'DOCUMENTS_VERIFIED', 'APPROVED']);

    if ($isVerified) {
        $subject = "✓ Documents Verified: Claim #$claimRef - " . APP_NAME;
        $statusColor = '#059669';
        $statusBadge = 'DOCUMENTS ARE VERIFIED';
        $statusIcon  = '✓';
        $statusSubtext = 'Your cashless insurance claim documents and Aadhaar eKYC have been successfully <strong>verified by the Hospital Officer</strong> and forwarded to the Administrator for final eSign authorization.';
    } else {
        $subject = "✕ Claim Documents Rejected: Claim #$claimRef - " . APP_NAME;
        $statusColor = '#dc2626';
        $statusBadge = 'REJECTED';
        $statusIcon  = '✕';
        $statusSubtext = 'Your cashless insurance claim submission has been reviewed by the Hospital Officer and was <strong>rejected</strong>.';
    }

    $body = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 12px; background-color: #ffffff;'>
        <div style='text-align: center; margin-bottom: 20px;'>
            <h2 style='color: #0f172a; margin-bottom: 4px;'>" . htmlspecialchars(APP_NAME) . "</h2>
            <span style='color: #64748b; font-size: 14px;'>Official Claim Verification Status Notification</span>
        </div>
        <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
        <p style='font-size: 16px; color: #1e293b;'>Dear <strong>" . htmlspecialchars($patientName) . "</strong>,</p>
        <p style='color: #475569; line-height: 1.5; font-size: 15px;'>
            Your cashless insurance claim submission (Ref: <strong>" . htmlspecialchars($claimRef) . "</strong>) has been reviewed and processed by the Hospital Officer.
        </p>
        
        <div style='background-color: #f8fafc; border: 2px solid {$statusColor}; border-radius: 10px; padding: 22px; text-align: center; margin: 24px 0;'>
            <div style='font-size: 13px; font-weight: bold; color: #64748b; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;'>CLAIM VERIFICATION STATUS</div>
            <div style='font-size: 24px; font-weight: bold; color: {$statusColor}; letter-spacing: 0.5px;'>
                {$statusIcon} {$statusBadge}
            </div>
            <p style='margin: 10px 0 0; color: #475569; font-size: 13px; line-height: 1.4;'>{$statusSubtext}</p>
        </div>";

    if (!empty($officerNotes)) {
        $body .= "
        <div style='background-color: #f1f5f9; border-left: 4px solid " . ($isVerified ? '#059669' : '#dc2626') . "; padding: 14px 18px; border-radius: 6px; margin-bottom: 20px;'>
            <strong style='color: #1e293b; font-size: 14px;'>Hospital Officer Remarks:</strong>
            <p style='color: #334155; margin: 6px 0 0 0; font-size: 14px;'>" . nl2br(htmlspecialchars($officerNotes)) . "</p>
        </div>";
    }

    $body .= "
        <p style='color: #475569; font-size: 14px; line-height: 1.5;'>If you have any questions regarding your claim verification, please contact your hospital insurance claims department.</p>
        <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
        <p style='font-size: 12px; color: #94a3b8; text-align: center;'>This is an automated notification from " . htmlspecialchars(APP_NAME) . ". Please do not reply directly to this email.</p>
    </div>";

    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer not installed. Claim status email for $patientEmail ($claimRef) logged to system audit trail.");
        return true;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        
        // Primary Recipient: Patient's Registered Email Address
        $mail->addAddress($patientEmail, $patientName);

        // CC Recipient: Official Hospital / System Mail ID
        $officialEmail = getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in';
        if (!empty($officialEmail) && strtolower(trim($officialEmail)) !== strtolower(trim($patientEmail))) {
            $mail->addCC(trim($officialEmail), 'Official Hospital Claims Admin');
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = "Claim #$claimRef Status: $statusBadge. Officer Remarks: $officerNotes";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Claim Status Notification Exception for $patientEmail ($claimRef): " . $e->getMessage());
        return false;
    }
}

/**
 * Sends a HTML Email Alert to the Hospital Officer / Official Email when a new patient submits a claim form.
 */
function sendNewClaimNotificationToOfficer(string $officerEmail, string $patientName, string $claimRef, string $hospitalName, string $policyNumber, string $insuranceCompany, int $claimId): bool {
    $subject = "🚨 NEW PATIENT CLAIM SUBMITTED: #$claimRef ($patientName) - " . APP_NAME;
    $emailBaseUrl = (defined('APP_PUBLIC_URL') && !empty(APP_PUBLIC_URL) && strpos(APP_PUBLIC_URL, 'http') === 0) ? APP_PUBLIC_URL : APP_BASE_URL;
    $verifyUrl = rtrim($emailBaseUrl, '/') . "/officer/verify-patient-form.php?id=" . $claimId;

    $body = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #cbd5e1; border-radius: 12px; background-color: #ffffff;'>
        <div style='background-color: #0f172a; color: #ffffff; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;'>
            <h3 style='margin: 0; font-size: 20px;'>HOSPITAL OFFICER CLAIM ALERT</h3>
            <span style='font-size: 13px; color: #94a3b8;'>New Cashless Insurance Claim Submission Received</span>
        </div>

        <div style='padding: 20px;'>
            <p style='font-size: 16px; color: #0f172a;'>Hello Hospital Officer,</p>
            <p style='color: #334155; line-height: 1.5;'>A new patient insurance claim submission has just been received and requires your verification.</p>

            <table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;'>
                <tr>
                    <td style='padding: 12px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Claim Reference:</td>
                    <td style='padding: 12px; font-weight: bold; color: #2563eb; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($claimRef) . "</td>
                </tr>
                <tr>
                    <td style='padding: 12px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Patient Name:</td>
                    <td style='padding: 12px; font-weight: bold; color: #0f172a; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($patientName) . "</td>
                </tr>
                <tr>
                    <td style='padding: 12px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Hospital Name:</td>
                    <td style='padding: 12px; color: #334155; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($hospitalName) . "</td>
                </tr>
                <tr>
                    <td style='padding: 12px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Insurance & Policy:</td>
                    <td style='padding: 12px; color: #334155; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($insuranceCompany) . " (Pol: " . htmlspecialchars($policyNumber) . ")</td>
                </tr>
            </table>

            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . htmlspecialchars($verifyUrl) . "' style='background-color: #16a34a; color: #ffffff; padding: 14px 28px; text-decoration: none; font-weight: bold; font-size: 16px; border-radius: 8px; display: inline-block;'>
                    ✓ REVIEW & VERIFY CLAIM FORM
                </a>
            </div>

            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center;'>This is an automated system notification from " . htmlspecialchars(APP_NAME) . ".</p>
        </div>
    </div>";

    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer not installed. Official claim notification email for $officerEmail ($claimRef) logged.");
        return true;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($officerEmail, 'Hospital Officer');

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = "New Claim #$claimRef submitted by $patientName for $hospitalName. Review & verify at $verifyUrl";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Officer Notification Exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Sends a rich HTML Email Notification to the Patient when their claim is APPROVED with eSign.
 */
function sendAdminClaimApprovalEmail(string $patientEmail, string $patientName, string $claimRef, string $hospitalName, string $insuranceCompany, string $policyNumber, string $adminNotes = '', string $esignTransactionId = '', string $approvedAmount = '₹1,50,000'): bool {
    $subject = "✓ Approval of Health Insurance Claim — Policy No. $policyNumber (#$claimRef) - " . APP_NAME;

    // Dynamically retrieve the most accessible URL for mobile / external network access
    $emailBaseUrl = (defined('APP_PUBLIC_URL') && !empty(APP_PUBLIC_URL) && strpos(APP_PUBLIC_URL, 'http') === 0)
        ? APP_PUBLIC_URL
        : ((defined('APP_BASE_URL') && !empty(APP_BASE_URL)) ? APP_BASE_URL : 'http://localhost/insurancee');

    $viewLetterUrl     = rtrim($emailBaseUrl, '/') . "/public/view-approval-letter.php?ref=" . urlencode($claimRef);
    $downloadLetterUrl = rtrim($emailBaseUrl, '/') . "/public/download-approval-letter.php?ref=" . urlencode($claimRef);

    $body = "
    <div style='background-color: #f0fdf4; padding: 30px 10px; font-family: Arial, sans-serif;'>
        <div style='max-width: 620px; margin: 0 auto; background: #ffffff; border-radius: 12px; padding: 28px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-top: 6px solid #16a34a;'>
            <div style='text-align: center; margin-bottom: 20px;'>
                <h2 style='color: #16a34a; margin-bottom: 4px;'>✓ Claim Approved & Digitally eSigned</h2>
                <span style='color: #64748b; font-size: 14px;'>" . htmlspecialchars(APP_NAME) . "</span>
            </div>
            
            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>

            <p style='font-size: 16px; color: #1e293b;'>Dear <strong>" . htmlspecialchars($patientName) . "</strong>,</p>
            <p style='color: #475569; line-height: 1.6;'>
                We are pleased to inform you that your health insurance claim/application, referenced under Claim No. <strong>" . htmlspecialchars($claimRef) . "</strong> and Policy No. <strong>" . htmlspecialchars($policyNumber) . "</strong>, has been reviewed and approved by <strong>" . htmlspecialchars($insuranceCompany) . "</strong>.
            </p>

            <div style='background: #f0fdf4; border: 2px solid #22c55e; border-radius: 10px; padding: 18px; text-align: center; margin: 24px 0;'>
                <div style='font-size: 13px; font-weight: bold; color: #15803d; text-transform: uppercase; margin-bottom: 4px;'>APPROVED CLAIM AMOUNT</div>
                <div style='font-size: 28px; font-weight: bold; color: #16a34a;'>" . htmlspecialchars($approvedAmount) . "</div>
                " . (!empty($esignTransactionId) ? "<div style='font-size: 13px; color: #166534; margin-top: 6px;'><i style='font-style: normal;'>🔐</i> emSigner PKI Reference: <strong>" . htmlspecialchars($esignTransactionId) . "</strong></div>" : "") . "
            </div>

            <div style='background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 20px 0;'>
                <strong style='color: #0f172a; font-size: 14px;'>Details of the approval are as follows:</strong>
                <table style='width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px;'>
                    <tr>
                        <td style='padding: 8px 0; font-weight: bold; color: #64748b; border-bottom: 1px dashed #e2e8f0;'>Policyholder Name:</td>
                        <td style='padding: 8px 0; color: #1e293b; font-weight: bold; border-bottom: 1px dashed #e2e8f0;'>" . htmlspecialchars($patientName) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px 0; font-weight: bold; color: #64748b; border-bottom: 1px dashed #e2e8f0;'>Policy Number:</td>
                        <td style='padding: 8px 0; color: #1e293b; font-weight: bold; border-bottom: 1px dashed #e2e8f0;'>" . htmlspecialchars($policyNumber) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px 0; font-weight: bold; color: #64748b; border-bottom: 1px dashed #e2e8f0;'>Claim Number:</td>
                        <td style='padding: 8px 0; color: #1e293b; font-weight: bold; border-bottom: 1px dashed #e2e8f0;'>" . htmlspecialchars($claimRef) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px 0; font-weight: bold; color: #64748b; border-bottom: 1px dashed #e2e8f0;'>Hospital/Provider:</td>
                        <td style='padding: 8px 0; color: #1e293b; border-bottom: 1px dashed #e2e8f0;'>" . htmlspecialchars($hospitalName) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px 0; font-weight: bold; color: #64748b;'>Approved Amount:</td>
                        <td style='padding: 8px 0; color: #16a34a; font-weight: bold;'>" . htmlspecialchars($approvedAmount) . "</td>
                    </tr>
                </table>
            </div>

            <p style='color: #475569; font-size: 13px; line-height: 1.5; margin-top: 20px;'>
                This approval is subject to the terms and conditions outlined in your policy document. Please retain this notification for your records.
            </p>

            <div style='text-align: center; margin: 24px 0;'>
                <a href='" . htmlspecialchars($downloadLetterUrl) . "' style='background-color: #16a34a; color: #ffffff; padding: 13px 26px; text-decoration: none; font-weight: bold; font-size: 15px; border-radius: 8px; display: inline-block; margin: 6px;'>
                    📥 DOWNLOAD OFFICIAL PDF
                </a>
                <a href='" . htmlspecialchars($viewLetterUrl) . "' style='background-color: #0f172a; color: #ffffff; padding: 13px 22px; text-decoration: none; font-weight: bold; font-size: 15px; border-radius: 8px; display: inline-block; margin: 6px;'>
                    📄 VIEW & PRINT ONLINE
                </a>
            </div>

            <div style='margin-top: 16px; padding: 14px 18px; background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; text-align: left;'>
                <p style='margin: 0; color: #166534; font-size: 13px; line-height: 1.5;'>
                    📎 <strong>Direct PDF Attached:</strong><br>
                    Your official signed Claim Approval Letter (<strong>Claim_Approval_Letter_" . htmlspecialchars($claimRef) . ".pdf</strong>) is attached directly to this email. You can open and view it anytime directly on your mobile device.
                </p>
            </div>

            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 24px 0 16px;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center; margin: 0;'>This is an official system notification generated by " . htmlspecialchars(APP_NAME) . ".</p>
        </div>
    </div>";

    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer missing. Claim approval email for $patientEmail logged.");
        return true;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($patientEmail, $patientName);

        $officialEmail = getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in';
        if (!empty($officialEmail) && strtolower(trim($officialEmail)) !== strtolower(trim($patientEmail))) {
            $mail->addCC(trim($officialEmail), 'Hospital Claims Department');
        }

        // Attach the signed approval PDF certificate directly to the email
        try {
            require_once __DIR__ . '/../includes/approvalLetterPdfGenerator.php';
            require_once __DIR__ . '/database.php';

            $claimData = [
                'claim_reference'   => $claimRef,
                'insurance_company' => $insuranceCompany,
                'hospital_name'     => $hospitalName,
                'policy_number'     => $policyNumber,
                'patient_name'      => $patientName,
                'admission_date'    => date('Y-m-d')
            ];
            $patientData = [
                'full_name' => $patientName,
                'email'     => $patientEmail,
                'phone'     => ''
            ];
            $esignData = !empty($esignTransactionId) ? [
                'transaction_id' => $esignTransactionId,
                'created_at'     => date('Y-m-d H:i:s')
            ] : null;

            try {
                $dbConn = getDBConnection();
                $cStmt = $dbConn->prepare("SELECT * FROM claims WHERE claim_reference = :ref LIMIT 1");
                $cStmt->execute([':ref' => $claimRef]);
                $cRow = $cStmt->fetch(PDO::FETCH_ASSOC);
                if ($cRow) {
                    $claimData = array_merge($claimData, $cRow);
                    if (!empty($cRow['patient_id'])) {
                        $pStmt = $dbConn->prepare("SELECT * FROM patients WHERE id = :pid LIMIT 1");
                        $pStmt->execute([':pid' => $cRow['patient_id']]);
                        $pRow = $pStmt->fetch(PDO::FETCH_ASSOC);
                        if ($pRow) {
                            $patientData = array_merge($patientData, $pRow);
                        }
                    }
                    $esStmt = $dbConn->prepare("SELECT * FROM esign_transactions WHERE claim_id = :cid ORDER BY id DESC LIMIT 1");
                    $esStmt->execute([':cid' => $cRow['id']]);
                    $esRow = $esStmt->fetch(PDO::FETCH_ASSOC);
                    if ($esRow) {
                        $esignData = $esRow;
                    }
                }
            } catch (Exception $dbEx) {
                // Fallback to arguments
            }

            $pdfBytes = ApprovalLetterPdfGenerator::generatePdfBinary($claimData, $patientData, $esignData, $approvedAmount);
            if (!empty($pdfBytes)) {
                $safeFilename = 'Claim_Approval_Letter_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $claimRef) . '.pdf';
                $mail->addStringAttachment($pdfBytes, $safeFilename, PHPMailer::ENCODING_BASE64, 'application/pdf');
            }
        } catch (Exception $pdfEx) {
            error_log("Failed to attach PDF to approval email for $claimRef: " . $pdfEx->getMessage());
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = "Dear $patientName, your claim #$claimRef (Policy: $policyNumber) has been approved for $approvedAmount with Digital eSign (Ref: $esignTransactionId). Download your official approval letter PDF at $downloadLetterUrl or view online at $viewLetterUrl. The PDF letter is also attached directly to this email.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Claim Approval Email Exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Sends a rich HTML Email Notification to the Patient when their claim is REJECTED by Admin.
 */
function sendAdminClaimRejectionEmail(string $patientEmail, string $patientName, string $claimRef, string $hospitalName, string $insuranceCompany, string $policyNumber, string $rejectionReason = ''): bool {
    $subject = "⚠️ Claim Update: Claim #$claimRef Rejected by Administrator - " . APP_NAME;

    $body = "
    <div style='background-color: #fef2f2; padding: 30px 10px; font-family: Arial, sans-serif;'>
        <div style='max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; padding: 28px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-top: 6px solid #dc2626;'>
            <div style='text-align: center; margin-bottom: 20px;'>
                <h2 style='color: #dc2626; margin-bottom: 4px;'>Claim Rejection Notice</h2>
                <span style='color: #64748b; font-size: 14px;'>" . htmlspecialchars(APP_NAME) . "</span>
            </div>
            
            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>

            <p style='font-size: 16px; color: #1e293b;'>Dear <strong>" . htmlspecialchars($patientName) . "</strong>,</p>
            <p style='color: #475569; line-height: 1.6;'>
                Your insurance claim submission (Ref: <strong>" . htmlspecialchars($claimRef) . "</strong>) has been reviewed by the Hospital Administrator and was <strong>not approved</strong>.
            </p>

            <div style='background: #fef2f2; border: 2px solid #ef4444; border-radius: 10px; padding: 18px; text-align: center; margin: 24px 0;'>
                <div style='font-size: 13px; font-weight: bold; color: #991b1b; text-transform: uppercase; margin-bottom: 4px;'>STATUS</div>
                <div style='font-size: 24px; font-weight: bold; color: #dc2626;'>✕ CLAIM REJECTED</div>
            </div>

            <div style='background-color: #fff7ed; border-left: 4px solid #f97316; border-radius: 6px; padding: 16px; margin: 20px 0;'>
                <strong style='color: #9a3412; font-size: 14px;'>Administrator Rejection Reason / Remarks:</strong>
                <p style='color: #7c2d12; margin: 8px 0 0; line-height: 1.5;'>" . htmlspecialchars($rejectionReason ?: 'Policy coverage criteria not met or incomplete document proofs submitted.') . "</p>
            </div>

            <table style='width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px;'>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Claim Reference:</td>
                    <td style='padding: 10px; color: #1e293b; font-weight: bold; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($claimRef) . "</td>
                </tr>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Hospital:</td>
                    <td style='padding: 10px; color: #1e293b; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($hospitalName) . "</td>
                </tr>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Insurance Provider:</td>
                    <td style='padding: 10px; color: #1e293b; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($insuranceCompany) . " (Pol: " . htmlspecialchars($policyNumber) . ")</td>
                </tr>
            </table>

            <div style='background-color: #f8fafc; border-radius: 8px; padding: 14px; margin-top: 20px; font-size: 13px; color: #64748b;'>
                <strong>Assistance:</strong> If you believe this decision is in error or you have additional supporting medical documents, please contact the Hospital Insurance Desk directly.
            </div>

            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 24px 0 16px;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center; margin: 0;'>This is an official system notification generated by " . htmlspecialchars(APP_NAME) . ".</p>
        </div>
    </div>";

    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer missing. Claim rejection email for $patientEmail logged.");
        return true;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($patientEmail, $patientName);

        $officialEmail = getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in';
        if (!empty($officialEmail) && strtolower(trim($officialEmail)) !== strtolower(trim($patientEmail))) {
            $mail->addCC(trim($officialEmail), 'Hospital Claims Department');
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = "Dear $patientName, your claim #$claimRef has been rejected by the Hospital Administrator. Reason: $rejectionReason";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Claim Rejection Email Exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Sends a HTML Submission Acknowledgment Email Response to the Patient upon submitting the form.
 */
function sendPatientSubmissionAcknowledgmentEmail(string $patientEmail, string $patientName, string $claimRef, string $patientRef, string $hospitalName, string $insuranceCompany, string $policyNumber): bool {
    $subject = "✓ Claim Form Submitted Successfully: #$claimRef - " . APP_NAME;

    $body = "
    <div style='background-color: #f8fafc; padding: 30px 10px; font-family: Arial, sans-serif;'>
        <div style='max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; padding: 28px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-top: 6px solid #2563eb;'>
            <div style='text-align: center; margin-bottom: 20px;'>
                <h2 style='color: #2563eb; margin-bottom: 4px;'>✓ Claim Form Received</h2>
                <span style='color: #64748b; font-size: 14px;'>" . htmlspecialchars(APP_NAME) . "</span>
            </div>
            
            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>

            <p style='font-size: 16px; color: #1e293b;'>Dear <strong>" . htmlspecialchars($patientName) . "</strong>,</p>
            <p style='color: #475569; line-height: 1.6;'>
                Thank you for submitting your cashless hospitalization claim form. Your submission has been securely registered in the hospital claims portal.
            </p>

            <div style='background: #eff6ff; border: 2px solid #3b82f6; border-radius: 10px; padding: 18px; text-align: center; margin: 24px 0;'>
                <div style='font-size: 13px; font-weight: bold; color: #1d4ed8; text-transform: uppercase; margin-bottom: 4px;'>CLAIM REFERENCE NUMBER</div>
                <div style='font-size: 26px; font-weight: bold; color: #2563eb; letter-spacing: 1px; font-family: monospace;'>
                    " . htmlspecialchars($claimRef) . "
                </div>
                <div style='font-size: 13px; color: #64748b; margin-top: 4px;'>Patient ID: <strong>" . htmlspecialchars($patientRef) . "</strong></div>
            </div>

            <table style='width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px;'>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Selected Hospital:</td>
                    <td style='padding: 10px; color: #1e293b; font-weight: bold; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($hospitalName) . "</td>
                </tr>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Insurance Provider:</td>
                    <td style='padding: 10px; color: #1e293b; border-bottom: 1px solid #e2e8f0;'>" . htmlspecialchars($insuranceCompany) . " (Pol: " . htmlspecialchars($policyNumber) . ")</td>
                </tr>
                <tr>
                    <td style='padding: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0;'>Status:</td>
                    <td style='padding: 10px; color: #0284c7; font-weight: bold; border-bottom: 1px solid #e2e8f0;'>Under Hospital Officer Verification</td>
                </tr>
            </table>

            <div style='background-color: #f1f5f9; border-radius: 8px; padding: 14px; margin-top: 20px; font-size: 13px; color: #475569;'>
                <strong>What happens next?</strong><br>
                1. The Hospital Verification Officer will inspect your Aadhaar eKYC and policy documents.<br>
                2. Once verified, the Administrator will apply the digital emSigner certificate.<br>
                3. You will receive real-time email updates at every stage.
            </div>

            <hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 24px 0 16px;'>
            <p style='font-size: 12px; color: #94a3b8; text-align: center; margin: 0;'>This is an automated notification from " . htmlspecialchars(APP_NAME) . ".</p>
        </div>
    </div>";

    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log("PHPMailer missing. Acknowledgment email for $patientEmail logged.");
        return true;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($patientEmail, $patientName);

        $officialEmail = getenv('OFFICIAL_HOSPITAL_EMAIL') ?: '11239a107@kanchiuniv.ac.in';
        if (!empty($officialEmail) && strtolower(trim($officialEmail)) !== strtolower(trim($patientEmail))) {
            $mail->addCC(trim($officialEmail), 'Hospital Claims Admin');
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = "Dear $patientName, your claim form #$claimRef has been received for $hospitalName and is under officer verification.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Patient Acknowledgment Exception: " . $e->getMessage());
        return false;
    }
}


