<?php
/**
 * Singleton PDO MySQL Database Connection Engine
 * 
 * Configured with strict PDO security flags:
 * - ERRMODE_EXCEPTION: Converts DB errors into catchable PDOExceptions.
 * - FETCH_ASSOC: Fetches database rows as associative arrays.
 * - EMULATE_PREPARES => false: Enforces native MySQL prepared statements to prevent SQL Injection.
 */

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'hospital_insurance_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');

function getDBConnection(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // Enforces native prepared statements
        ];

        // Enable SSL encryption if connecting to remote cloud database (e.g. TiDB Cloud)
        if (DB_HOST !== '127.0.0.1' && DB_HOST !== 'localhost') {
            $options[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = false;
        }

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database Connection Failure: " . $e->getMessage());
            throw new Exception("Database connection failed. Please ensure MySQL is running in XAMPP.");
        }
    }

    return $pdo;
}
