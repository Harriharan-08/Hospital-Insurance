<?php
/**
 * CSRF Protection Token Generator & Validator
 * 
 * Protects forms against Cross-Site Request Forgery (CSRF).
 */

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/../config/security.php';

/**
 * Generates a cryptographically secure CSRF token.
 */
function generateCSRFToken(): string {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Validates submitted CSRF token against session token.
 */
function validateCSRFToken(?string $token): bool {
    if (empty($token) || empty($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }
    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Renders hidden input HTML field for forms.
 */
function getCSRFFormField(): string {
    $token = generateCSRFToken();
    return '<input type="hidden" name="' . htmlspecialchars(CSRF_TOKEN_NAME) . '" value="' . htmlspecialchars($token) . '">';
}
