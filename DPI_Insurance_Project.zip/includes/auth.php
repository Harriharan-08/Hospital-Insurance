<?php
/**
 * Role-Based Access Control (RBAC) & Session Auth Guards
 * 
 * Enforces session authentication states and backend role authorization guards.
 */

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/../config/security.php';

/**
 * Checks whether user is fully authenticated.
 */
function isLoggedIn(): bool {
    return isset($_SESSION['auth_state']) && $_SESSION['auth_state'] === AUTH_STATE_FULLY_AUTHENTICATED;
}

/**
 * Enforces authentication. Redirects unauthenticated or 2FA-pending users.
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        if (isset($_SESSION['auth_state']) && $_SESSION['auth_state'] === AUTH_STATE_2FA_PENDING) {
            header("Location: " . APP_BASE_URL . "/public/verify-2fa.php");
            exit();
        }
        $_SESSION['login_errors'] = ["Please log in to access this page."];
        header("Location: " . APP_BASE_URL . "/public/login.php");
        exit();
    }
}

/**
 * Enforces role-based authorization for given allowed roles.
 */
function requireRole($roles): void {
    requireLogin();
    $roles = (array)$roles;
    $userRole = strtolower($_SESSION['user_role'] ?? '');

    $normalizedAllowed = array_map('strtolower', $roles);

    if (!in_array($userRole, $normalizedAllowed, true)) {
        http_response_code(403);
        $redirectUrl = ($userRole === 'admin') ? APP_BASE_URL . '/admin/dashboard.php' : APP_BASE_URL . '/officer/dashboard.php';
        echo "<!DOCTYPE html><html><head><title>403 Forbidden</title><link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'></head><body class='bg-light text-center py-5'><div class='container'><div class='alert alert-danger shadow-sm p-4 display-6 fw-bold'>403 Access Denied</div><p class='text-muted'>You do not have the required role privileges (" . htmlspecialchars(implode(', ', $roles)) . ") to access this page.</p><a href='" . htmlspecialchars($redirectUrl) . "' class='btn btn-primary'>Go to Your Dashboard</a></div></body></html>";
        exit();
    }
}

/**
 * Enforces Admin role authorization.
 */
function requireAdmin(): void {
    requireRole(['admin']);
}

/**
 * Enforces Officer / Admin role authorization.
 */
function requireOfficer(): void {
    requireRole(['officer', 'admin']);
}

/**
 * Enforces general authenticated User / Officer / Admin authorization.
 */
function requireUser(): void {
    requireRole(['user', 'officer', 'admin']);
}

/**
 * Enforces 2FA Pending session state.
 */
function require2FAPending(): void {
    if (!isset($_SESSION['auth_state']) || $_SESSION['auth_state'] !== AUTH_STATE_2FA_PENDING) {
        if (isLoggedIn()) {
            $redirect = ($_SESSION['user_role'] === 'admin') ? '/admin/dashboard.php' : '/officer/dashboard.php';
            header("Location: " . APP_BASE_URL . $redirect);
            exit();
        }
        header("Location: " . APP_BASE_URL . "/public/login.php");
        exit();
    }
}

/**
 * Returns current authenticated user profile array.
 */
function getCurrentUser(): ?array {
    if (!isLoggedIn()) {
        return null;
    }
    return [
        'id'            => $_SESSION['user_id'] ?? null,
        'role'          => $_SESSION['user_role'] ?? 'user',
        'full_name'     => $_SESSION['user_name'] ?? 'User',
        'first_name'    => $_SESSION['user_first_name'] ?? '',
        'last_name'     => $_SESSION['user_last_name'] ?? '',
        'email'         => $_SESSION['user_email'] ?? '',
        'profile_image' => $_SESSION['user_profile_image'] ?? ($_SESSION['user_avatar'] ?? null),
        'avatar_url'    => $_SESSION['user_avatar'] ?? null,
        'provider'      => $_SESSION['provider'] ?? 'local',
        'hospital_name' => $_SESSION['user_hospital'] ?? 'City Central Hospital',
        'is_2fa'        => $_SESSION['user_2fa_enabled'] ?? false
    ];
}
