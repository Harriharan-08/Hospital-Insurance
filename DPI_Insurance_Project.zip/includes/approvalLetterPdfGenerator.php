<?php
/**
 * Official Health Insurance Claim Approval Letter PDF Generator Engine
 * 
 * Generates an official, standard-compliant Claim Approval Certificate PDF
 * matching insurance regulator and TPA layout requirements.
 * Uses pure PHP vector drawing and standard PDF 1.4 structure with zero external dependencies.
 */

require_once __DIR__ . '/eKycPdfGenerator.php'; // Re-use the robust eKycPdfDoc vector PDF engine

class ApprovalLetterPdfGenerator {

    /**
     * Generate pure PDF binary for the Claim Approval Letter.
     */
    public static function generatePdfBinary(array $claim, array $patient, ?array $esignRecord = null, string $approvedAmount = '₹1,50,000'): string {
        $doc = new eKycPdfDoc();

        // Colors
        $cPrimary = [22, 163, 74];      // #16a34a (Green)
        $cDark = [15, 23, 42];          // #0f172a (Navy/Black)
        $cGray = [100, 116, 139];       // #64748b (Slate)
        $cLightBg = [248, 250, 252];    // #f8fafc
        $cBorder = [226, 232, 240];     // #e2e8f0
        $cGreenBg = [240, 253, 244];    // #f0fdf4
        $cWhite = [255, 255, 255];

        // 1. Page Border Frame
        $doc->setDrawColor($cBorder[0], $cBorder[1], $cBorder[2]);
        $doc->setFillColor($cWhite[0], $cWhite[1], $cWhite[2]);
        $doc->rect(10, 10, 190, 277, 'DF');

        // Top green accent bar
        $doc->setFillColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->rect(10, 10, 190, 5, 'F');

        // 2. Company / Letterhead Header
        $companyName = !empty($claim['insurance_company']) ? $claim['insurance_company'] : 'Star Health & Allied Insurance Co. Ltd.';
        $hospitalName = !empty($claim['hospital_name']) ? $claim['hospital_name'] : 'City General Hospital';
        $policyNumber = !empty($claim['policy_number']) ? $claim['policy_number'] : 'POL-736384';
        $claimRef = !empty($claim['claim_reference']) ? $claim['claim_reference'] : 'CLM-2026-000000';
        $patientName = !empty($patient['full_name']) ? $patient['full_name'] : ($claim['patient_name'] ?? 'Policyholder');
        $patientPhone = !empty($patient['phone']) ? $patient['phone'] : ($claim['phone'] ?? 'N/A');
        $patientEmail = !empty($patient['email']) ? $patient['email'] : ($claim['email'] ?? 'N/A');
        $admissionDate = !empty($claim['admission_date']) ? date('d-M-Y', strtotime($claim['admission_date'])) : date('d-M-Y');
        $approvalDate = !empty($esignRecord['created_at']) ? date('F d, Y', strtotime($esignRecord['created_at'])) : date('F d, Y');
        $txId = !empty($esignRecord['transaction_id']) ? $esignRecord['transaction_id'] : ('EMSIGN-' . date('Ymd') . '-' . strtoupper(substr(md5($claimRef), 0, 8)));

        $doc->setFont('helvetica', 'B', 16);
        $doc->setTextColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->text(20, 26, strtoupper($companyName));

        $doc->setFont('helvetica', '', 9);
        $doc->setTextColor($cGray[0], $cGray[1], $cGray[2]);
        $doc->text(20, 32, 'Official Health Insurance Claim Approval & Cashless Settlement Authorization');
        $doc->text(20, 36, 'Customer Care: 1800-425-2255 | Support Email: claims-support@insurance-auth.gov.in');

        // Divider
        $doc->setDrawColor($cBorder[0], $cBorder[1], $cBorder[2]);
        $doc->line(20, 40, 190, 40);

        // 3. Date and Reference
        $doc->setFont('helvetica', 'B', 9);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(20, 47, "Date of Issuance: " . $approvalDate);
        $doc->text(130, 47, "Claim Reference: " . $claimRef);

        // 4. Recipient Box
        $doc->setFillColor($cLightBg[0], $cLightBg[1], $cLightBg[2]);
        $doc->setDrawColor($cBorder[0], $cBorder[1], $cBorder[2]);
        $doc->roundedRect(20, 52, 170, 22, 3, 'DF');

        $doc->setFont('helvetica', 'B', 9);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(25, 58, "TO: " . strtoupper($patientName));
        $doc->setFont('helvetica', '', 8.5);
        $doc->setTextColor($cGray[0], $cGray[1], $cGray[2]);
        $doc->text(25, 63, "Registered Email: " . $patientEmail . " | Phone: " . $patientPhone);
        $doc->text(25, 68, "Policy Number: " . $policyNumber . " | Hospital: " . $hospitalName);

        // 5. Subject Line
        $doc->setFont('helvetica', 'B', 10);
        $doc->setTextColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->text(20, 81, "SUBJECT: Formal Approval & Authorization of Insurance Claim #" . $claimRef);

        // 6. Body Paragraph
        $doc->setFont('helvetica', '', 9);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(20, 89, "Dear " . $patientName . ",");
        $doc->text(20, 95, "We are pleased to inform you that your health insurance claim submitted through " . $hospitalName);
        $doc->text(20, 100, "under Policy No. " . $policyNumber . " has been successfully verified, approved, and digitally authenticated.");

        // 7. Approved Amount Highlight Card
        $doc->setFillColor($cGreenBg[0], $cGreenBg[1], $cGreenBg[2]);
        $doc->setDrawColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->roundedRect(20, 107, 170, 25, 4, 'DF');

        $doc->setFont('helvetica', 'B', 8.5);
        $doc->setTextColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->text(25, 114, "TOTAL APPROVED CLAIM SETTLEMENT AMOUNT:");

        $doc->setFont('helvetica', 'B', 18);
        $doc->text(25, 125, $approvedAmount);

        $doc->setFont('helvetica', 'B', 8);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(115, 125, "[ eSign Digitally Stamped & Verified ]");

        // 8. Structured Table of Details
        $doc->setFillColor($cLightBg[0], $cLightBg[1], $cLightBg[2]);
        $doc->setDrawColor($cBorder[0], $cBorder[1], $cBorder[2]);
        $doc->roundedRect(20, 137, 170, 52, 3, 'DF');

        $doc->setFont('helvetica', 'B', 9);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(25, 143, "SUMMARY OF APPROVED CLAIM PARTICULARS");

        $doc->setDrawColor($cBorder[0], $cBorder[1], $cBorder[2]);
        $doc->line(25, 146, 185, 146);

        $rows = [
            ['Beneficiary / Patient:', $patientName, 'Admission Date:', $admissionDate],
            ['Insurance Company:', $companyName, 'Policy Number:', $policyNumber],
            ['Hospital / Provider:', $hospitalName, 'Claim Number:', $claimRef],
            ['Settlement Status:', 'APPROVED / AUTHORIZED', 'Payment Mode:', 'Direct Cashless TPA']
        ];

        $y = 153;
        foreach ($rows as $r) {
            $doc->setFont('helvetica', '', 8.5);
            $doc->setTextColor($cGray[0], $cGray[1], $cGray[2]);
            $doc->text(25, $y, $r[0]);
            $doc->text(110, $y, $r[2]);

            $doc->setFont('helvetica', 'B', 8.5);
            $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
            $doc->text(58, $y, substr($r[1], 0, 30));
            $doc->text(140, $y, substr($r[3], 0, 25));

            $y += 8;
        }

        // 9. Standard Conditions
        $doc->setFont('helvetica', '', 8);
        $doc->setTextColor($cGray[0], $cGray[1], $cGray[2]);
        $doc->text(20, 196, "Terms & Conditions: This authorization letter is issued subject to the policy terms, waiting periods, and exclusions.");
        $doc->text(20, 201, "The hospital has been authorized to process the cashless billing for the approved procedure.");

        // 10. Official Digital Signature Stamp (Only Sign)
        $doc->setFont('helvetica', '', 9.5);
        $doc->setTextColor($cDark[0], $cDark[1], $cDark[2]);
        $doc->text(20, 212, "Sincerely,");

        // Digital Signature Stamp Box
        $doc->setFillColor($cGreenBg[0], $cGreenBg[1], $cGreenBg[2]);
        $doc->setDrawColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->roundedRect(20, 217, 62, 36, 3, 'DF');

        // Dedicated Signature Card Plate
        $doc->setFillColor($cWhite[0], $cWhite[1], $cWhite[2]);
        $doc->setDrawColor(187, 247, 208); // #bbf7d0
        $doc->roundedRect(23, 220, 56, 24, 2, 'DF');

        // Add Signature Image (JPG)
        $sigJpg = __DIR__ . '/../public/assets/signatures/harriharan_signature.jpg';
        if (file_exists($sigJpg)) {
            $doc->addImage($sigJpg, 25, 221, 52, 21);
        } else {
            // Fallback cursive text if image missing
            $doc->setFont('helvetica', 'BI', 11);
            $doc->setTextColor(30, 58, 138); // Deep Blue
            $doc->text(26, 233, "Harriharan S.");
        }

        // Signature Caption
        $doc->setFont('helvetica', 'B', 7);
        $doc->setTextColor($cPrimary[0], $cPrimary[1], $cPrimary[2]);
        $doc->text(25, 248, "[ DIGITALLY SIGNED ]");

        // 11. Security Footer
        $doc->setFont('helvetica', '', 7.5);
        $doc->setTextColor($cGray[0], $cGray[1], $cGray[2]);
        $doc->text(20, 270, "Document Integrity Hash: SHA-256 [" . strtoupper(hash('sha256', $claimRef . $txId)) . "]");
        $doc->text(20, 274, "Hospital Insurance Portal System | Automated Electronic Transmission");

        return $doc->render();
    }
}
