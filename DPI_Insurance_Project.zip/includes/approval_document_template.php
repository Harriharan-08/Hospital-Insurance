<?php
/**
 * Official Health Insurance Claim Approval Document Template
 * 
 * Renders the formal claim approval letter populated with patient, hospital,
 * policy, and eSign digital signature authentication details according to the standard template.
 */

require_once __DIR__ . '/functions.php';

function renderApprovalDocument(
    array $claim,
    array $patient,
    ?array $esignRecord = null,
    string $approvedAmount = '₹1,50,000',
    bool $isInteractivePreview = false,
    string $signaturePath = 'public/assets/signatures/harriharan_signature.png',
    string $signatoryName = 'Harriharan S',
    string $signatoryTitle = 'Hospital Administrator & Authorized TPA Signatory'
): string {
    // 1. Insurance Company Information
    $companyInfo = getInsuranceCompanyInfo($claim['insurance_company'] ?? '');
    $companyName = $companyInfo['name'];
    $companyAddr1 = $companyInfo['address_1'];
    $companyCityStateZip = $companyInfo['city_state_zip'];
    $companyPhone = $companyInfo['phone'];
    $companyEmail = $companyInfo['email'];

    // 2. Date
    $approvalDate = !empty($esignRecord['created_at']) 
        ? date('F d, Y', strtotime($esignRecord['created_at'])) 
        : date('F d, Y');

    // 3. Policyholder / Patient Information
    $policyholderName = !empty($patient['full_name']) ? $patient['full_name'] : ($claim['patient_name'] ?? 'Policyholder');
    $patientAddrInfo = getPolicyholderAddressDetails($patient['address'] ?? ($claim['address'] ?? ''), $claim['ekyc_data'] ?? null);
    $policyholderAddr1 = $patientAddrInfo['address_1'];
    $policyholderCityStateZip = $patientAddrInfo['city_state_zip'];

    // 4. Policy & Claim Details
    $policyNumber = !empty($claim['policy_number']) ? $claim['policy_number'] : 'N/A';
    $claimNumber = !empty($claim['claim_reference']) ? $claim['claim_reference'] : 'CLM-' . date('Ymd');
    $treatmentDate = !empty($claim['admission_date']) ? date('F d, Y', strtotime($claim['admission_date'])) : date('F d, Y');
    $hospitalName = !empty($claim['hospital_name']) ? $claim['hospital_name'] : 'City General Hospital';

    // 5. Signature and Provider metadata
    $isSigned = (!empty($esignRecord) && ($esignRecord['status'] ?? '') === 'SIGNED');
    $txId = $esignRecord['transaction_id'] ?? '';
    $docHash = $esignRecord['document_hash'] ?? '';
    $signedTime = !empty($esignRecord['created_at']) ? date('d-M-Y H:i:s T', strtotime($esignRecord['created_at'])) : date('d-M-Y H:i:s T');

    // Parse response if amount was persisted
    if ($esignRecord && !empty($esignRecord['provider_response'])) {
        $pResp = json_decode($esignRecord['provider_response'], true);
        if (!empty($pResp['approved_amount'])) {
            $approvedAmount = $pResp['approved_amount'];
        }
        if (!empty($pResp['signed_by'])) {
            $signatoryName = $pResp['signed_by'];
        }
        if (!empty($pResp['signer_role'])) {
            $signatoryTitle = ucwords(strtolower(str_replace('_', ' ', $pResp['signer_role'])));
        }
        if (!empty($pResp['signature_file'])) {
            $signaturePath = $pResp['signature_file'];
        }
    }

    // Relative web path adjustment
    $webSigPath = (strpos($signaturePath, 'public/') === 0) ? '../' . $signaturePath : $signaturePath;
    if (file_exists(__DIR__ . '/../' . ltrim($signaturePath, '/'))) {
        $webSigPath = '../' . ltrim($signaturePath, '/');
    }

    ob_start();
    ?>
    <div class="approval-document-wrapper">
        <div class="approval-doc-card">
            
            <!-- Letterhead / Company Header -->
            <div class="doc-header">
                <div class="doc-company-name"><?= htmlspecialchars($companyName) ?></div>
                <div class="doc-company-address"><?= htmlspecialchars($companyAddr1) ?></div>
                <div class="doc-company-address"><?= htmlspecialchars($companyCityStateZip) ?></div>
                <div class="doc-company-contact">
                    <span>Phone: <?= htmlspecialchars($companyPhone) ?></span> | 
                    <span>Email: <?= htmlspecialchars($companyEmail) ?></span>
                </div>
            </div>

            <div class="doc-divider"></div>

            <!-- Date -->
            <div class="doc-date-block">
                <span class="doc-date"><?= htmlspecialchars($approvalDate) ?></span>
            </div>

            <!-- Recipient / Policyholder Block -->
            <div class="doc-recipient-block">
                <div class="doc-recipient-name"><?= htmlspecialchars($policyholderName) ?></div>
                <div class="doc-recipient-addr"><?= htmlspecialchars($policyholderAddr1) ?></div>
                <div class="doc-recipient-addr"><?= htmlspecialchars($policyholderCityStateZip) ?></div>
            </div>

            <!-- Subject Line -->
            <div class="doc-subject-line">
                <strong>Subject:</strong> Approval of Health Insurance Claim/Application — Policy No. <span class="doc-highlight"><?= htmlspecialchars($policyNumber) ?></span>
            </div>

            <!-- Salutation -->
            <div class="doc-salutation">
                Dear <?= htmlspecialchars($policyholderName) ?>,
            </div>

            <!-- Opening Paragraph -->
            <div class="doc-paragraph">
                We are pleased to inform you that your health insurance claim/application, referenced under Claim No. <strong><?= htmlspecialchars($claimNumber) ?></strong> and Policy No. <strong><?= htmlspecialchars($policyNumber) ?></strong>, has been reviewed and approved by <strong><?= htmlspecialchars($companyName) ?></strong>.
            </div>

            <!-- Approval Details Table / List -->
            <div class="doc-details-box">
                <div class="doc-details-title">Details of the approval are as follows:</div>
                <table class="doc-details-table">
                    <tbody>
                        <tr>
                            <td class="doc-dt-label">Policyholder Name:</td>
                            <td class="doc-dt-val"><strong><?= htmlspecialchars($policyholderName) ?></strong></td>
                        </tr>
                        <tr>
                            <td class="doc-dt-label">Policy Number:</td>
                            <td class="doc-dt-val font-monospace"><strong><?= htmlspecialchars($policyNumber) ?></strong></td>
                        </tr>
                        <tr>
                            <td class="doc-dt-label">Claim Number:</td>
                            <td class="doc-dt-val font-monospace"><strong><?= htmlspecialchars($claimNumber) ?></strong></td>
                        </tr>
                        <tr>
                            <td class="doc-dt-label">Date of Treatment/Service:</td>
                            <td class="doc-dt-val"><?= htmlspecialchars($treatmentDate) ?></td>
                        </tr>
                        <tr>
                            <td class="doc-dt-label">Hospital/Provider Name:</td>
                            <td class="doc-dt-val"><strong><?= htmlspecialchars($hospitalName) ?></strong></td>
                        </tr>
                        <tr>
                            <td class="doc-dt-label">Approved Amount:</td>
                            <td class="doc-dt-val"><span class="doc-approved-amount-badge" id="previewApprovedAmountBadge"><?= htmlspecialchars($approvedAmount) ?></span></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Closing Paragraphs -->
            <div class="doc-paragraph">
                This approval is subject to the terms and conditions outlined in your policy document. Please retain this letter for your records, and do not hesitate to contact our support team should you require any further assistance or clarification.
            </div>

            <div class="doc-paragraph">
                We appreciate your continued trust in <strong><?= htmlspecialchars($companyName) ?></strong>.
            </div>

            <!-- Sign-Off & eSign Block -->
            <div class="doc-signoff-block">
                <div class="doc-sincerely">Sincerely,</div>
                
                <div class="doc-signature-zone">
                    <div class="doc-sig-line-container">
                        <?php if ($isSigned): ?>
                            <!-- Authenticated Stamped eSign -->
                            <div class="doc-digital-sig-stamp">
                                <img src="<?= htmlspecialchars($webSigPath) ?>" alt="Digital Signature of <?= htmlspecialchars($signatoryName) ?>" class="doc-sig-img">
                            </div>
                        <?php elseif ($isInteractivePreview): ?>
                            <!-- Preview in Modal Before Approval -->
                            <div class="doc-sig-preview-placeholder">
                                <img src="../public/assets/signatures/harriharan_signature.png" id="modalSigImgLive" alt="Signature Preview" class="doc-sig-img">
                            </div>
                        <?php else: ?>
                            <!-- Signature Line with Pending Stamp -->
                            <div class="doc-sig-pending-box text-muted small p-2 bg-light rounded border text-center">
                                <i class="bi bi-pen me-1"></i>[ Digital eSign Signature will be stamped here ]
                            </div>
                        <?php endif; ?>
                        
                        <div class="doc-sig-underline">_____________________________</div>
                    </div>

                    <div class="doc-signatory-name"><?= htmlspecialchars($signatoryName) ?></div>
                    <div class="doc-signatory-title"><?= htmlspecialchars($signatoryTitle) ?></div>
                    <div class="doc-signatory-company"><?= htmlspecialchars($companyName) ?></div>
                </div>
            </div>



        </div>
    </div>

    <style>
    .approval-document-wrapper {
        font-family: 'Times New Roman', Times, Georgia, serif;
        color: #1a1a1a;
        line-height: 1.6;
        margin: 0 auto;
    }
    .approval-doc-card {
        background-color: #ffffff;
        border: 1px solid #d1d5db;
        border-radius: 12px;
        padding: 40px 48px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        position: relative;
        background-image: radial-gradient(#f1f5f9 1px, transparent 1px);
        background-size: 24px 24px;
    }
    .doc-header {
        text-align: center;
        margin-bottom: 24px;
    }
    .doc-company-name {
        font-size: 1.65rem;
        font-weight: 800;
        letter-spacing: 0.5px;
        color: #0f2b5c;
        text-transform: uppercase;
        margin-bottom: 4px;
        font-family: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, sans-serif;
    }
    .doc-company-address {
        font-size: 0.95rem;
        color: #4b5563;
        font-family: 'Plus Jakarta Sans', sans-serif;
        line-height: 1.4;
    }
    .doc-company-contact {
        font-size: 0.9rem;
        color: #2563eb;
        font-weight: 600;
        margin-top: 6px;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-divider {
        height: 2px;
        background: linear-gradient(90deg, transparent, #0f2b5c, transparent);
        margin: 20px 0 24px 0;
    }
    .doc-date-block {
        text-align: right;
        font-size: 1rem;
        font-weight: 600;
        color: #374151;
        margin-bottom: 20px;
    }
    .doc-recipient-block {
        margin-bottom: 24px;
        font-size: 1.05rem;
        line-height: 1.5;
    }
    .doc-recipient-name {
        font-size: 1.2rem;
        font-weight: 700;
        color: #111827;
    }
    .doc-recipient-addr {
        color: #4b5563;
    }
    .doc-subject-line {
        background-color: #f8fafc;
        border-left: 4px solid #0f2b5c;
        padding: 12px 18px;
        margin: 24px 0;
        font-size: 1.08rem;
        font-weight: 700;
        color: #0f172a;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-highlight {
        color: #1d4ed8;
    }
    .doc-salutation {
        font-size: 1.08rem;
        font-weight: 600;
        margin-bottom: 16px;
    }
    .doc-paragraph {
        font-size: 1.05rem;
        text-align: justify;
        margin-bottom: 18px;
        line-height: 1.7;
    }
    .doc-details-box {
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 18px 24px;
        margin: 22px 0;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-details-title {
        font-size: 1rem;
        font-weight: 700;
        color: #0f2b5c;
        margin-bottom: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .doc-details-table {
        width: 100%;
        border-collapse: collapse;
    }
    .doc-details-table td {
        padding: 8px 10px;
        font-size: 0.98rem;
        vertical-align: top;
        border-bottom: 1px dashed #e2e8f0;
    }
    .doc-details-table tr:last-child td {
        border-bottom: none;
    }
    .doc-dt-label {
        font-weight: 600;
        color: #4b5563;
        width: 38%;
    }
    .doc-dt-val {
        color: #111827;
    }
    .doc-approved-amount-badge {
        display: inline-block;
        background-color: #ecfdf5;
        color: #065f46;
        font-weight: 800;
        font-size: 1.15rem;
        padding: 4px 14px;
        border-radius: 6px;
        border: 1px solid #10b981;
    }
    .doc-signoff-block {
        margin-top: 32px;
        page-break-inside: avoid;
    }
    .doc-sincerely {
        font-size: 1.05rem;
        font-weight: 600;
        margin-bottom: 12px;
    }
    .doc-signature-zone {
        margin-top: 10px;
    }
    .doc-sig-line-container {
        position: relative;
        max-width: 340px;
        margin-bottom: 6px;
    }
    .doc-sig-underline {
        font-family: monospace;
        letter-spacing: -1px;
        color: #64748b;
        font-weight: 700;
        margin-top: -8px;
    }
    .doc-digital-sig-stamp {
        display: inline-block;
        margin-bottom: 4px;
    }
    .doc-sig-img {
        max-height: 52px;
        max-width: 170px;
        object-fit: contain;
    }
    .doc-sig-meta-stamp {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 10px;
        line-height: 1.3;
        color: #334155;
    }
    .doc-stamp-title {
        color: #16a34a;
        font-weight: 700;
        font-size: 11px;
    }
    .doc-signatory-name {
        font-size: 1.15rem;
        font-weight: 700;
        color: #111827;
        margin-top: 6px;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-signatory-title {
        font-size: 0.95rem;
        color: #4b5563;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-signatory-company {
        font-size: 0.95rem;
        font-weight: 600;
        color: #0f2b5c;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .doc-security-footer {
        margin-top: 36px;
        padding-top: 16px;
        border-top: 1px solid #e5e7eb;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 12px;
        color: #6b7280;
    }

    @media print {
        body {
            background: #ffffff !important;
            color: #000000 !important;
            padding: 0 !important;
            margin: 0 !important;
        }
        .header-banner, .navbar, .btn, .no-print, header, nav, footer {
            display: none !important;
        }
        .approval-doc-card {
            border: none !important;
            box-shadow: none !important;
            padding: 20px 0 !important;
            background-image: none !important;
        }
        .doc-subject-line, .doc-details-box {
            background-color: transparent !important;
            border: 1px solid #000000 !important;
        }
        .doc-approved-amount-badge {
            background: none !important;
            border: 1px solid #000 !important;
            color: #000 !important;
        }
    }
    </style>
    <?php
    return ob_get_clean();
}
