<?php
/**
 * Global Utility Functions, Security Helpers & RFC 6238 TOTP Engine
 */

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/../config/database.php';

/**
 * Sanitizes input string against XSS attacks.
 */
function sanitizeInput(string $data): string {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Retrieves client IP address safely.
 */
function getClientIP(): string {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP) ?: '127.0.0.1';
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return filter_var(trim($ips[0]), FILTER_VALIDATE_IP) ?: '127.0.0.1';
    }
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

/**
 * Writes system security event to audit_logs table.
 */
function logAuditEvent(?int $userId, string $eventType, ?string $details = null): void {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, event_type, ip_address, user_agent, details, created_at)
            VALUES (:user_id, :event_type, :ip_address, :user_agent, :details, NOW())
        ");
        $stmt->execute([
            ':user_id'    => $userId,
            ':event_type' => $eventType,
            ':ip_address' => getClientIP(),
            ':user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            ':details'    => $details
        ]);
    } catch (Exception $e) {
        error_log("Failed to write audit log: " . $e->getMessage());
    }
}

/**
 * Generates Server-Side Alphanumeric CAPTCHA (Alphabets + Mathematical Digits)
 */
function generateMathCaptcha(): array {
    return generateAlphanumericCaptcha();
}

function generateAlphanumericCaptcha(): array {
    $caps   = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $smalls = 'abcdefghijkmnpqrstuvwxyz';
    $digits = '23456789';

    // Guaranteed combination of Capital letters, Small letters, and Numbers (length 5)
    $chars = [
        $caps[random_int(0, strlen($caps) - 1)],
        $smalls[random_int(0, strlen($smalls) - 1)],
        $digits[random_int(0, strlen($digits) - 1)],
        (random_int(0, 1) === 1 ? $caps[random_int(0, strlen($caps) - 1)] : $smalls[random_int(0, strlen($smalls) - 1)]),
        $digits[random_int(0, strlen($digits) - 1)]
    ];
    shuffle($chars);
    $code = implode('', $chars);

    $_SESSION['captcha_answer'] = $code;
    $_SESSION['captcha_created'] = time();

    return [
        'question' => $code,
        'code'     => $code,
        'answer'   => $code
    ];
}

/**
 * Verifies Alphanumeric CAPTCHA Answer (Strict Case-Sensitive)
 */
function verifyMathCaptcha($userAnswer): bool {
    return verifyAlphanumericCaptcha($userAnswer);
}

function verifyAlphanumericCaptcha($userAnswer): bool {
    if (!isset($_SESSION['captcha_answer']) || empty($userAnswer)) {
        return false;
    }

    $correctAnswer = (string)$_SESSION['captcha_answer'];
    $givenAnswer   = trim((string)$userAnswer);

    // Invalidate CAPTCHA after single verification attempt
    unset($_SESSION['captcha_answer']);

    // Case-insensitive comparison for friendly UX
    return strcasecmp($givenAnswer, $correctAnswer) === 0;
}

/**
 * RFC 6238 Standard Base32 TOTP Engine
 */
class TOTPHelper {
    private static string $base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function generateSecret(int $length = 16): string {
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= self::$base32Chars[random_int(0, 31)];
        }
        return $secret;
    }

    public static function verifyCode(string $secret, string $code, int $discrepancy = 1): bool {
        $timestamp = time();
        $code = trim($code);

        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            $calculatedCode = self::calculateCode($secret, (int)floor($timestamp / 30) + $i);
            if (hash_equals($calculatedCode, $code)) {
                return true;
            }
        }
        return false;
    }

    public static function calculateCode(string $secret, int $timeSlice): string {
        $secretKey = self::base32Decode($secret);
        $time = pack('N*', 0) . pack('N*', $timeSlice);

        $hmac = hash_hmac('sha1', $time, $secretKey, true);
        $offset = ord(substr($hmac, -1)) & 0x0F;
        $hashPart = substr($hmac, $offset, 4);

        $value = unpack('N', $hashPart);
        $value = $value[1] & 0x7FFFFFFF;

        $modulo = pow(10, 6);
        return sprintf("%06d", $value % $modulo);
    }

    private static function base32Decode(string $secret): string {
        $secret = strtoupper($secret);
        $binary = '';
        for ($i = 0; $i < strlen($secret); $i++) {
            $char = $secret[$i];
            $pos = strpos(self::$base32Chars, $char);
            if ($pos !== false) {
                $binary .= sprintf('%05b', $pos);
            }
        }

        $binaryArray = str_split($binary, 8);
        $decoded = '';
        foreach ($binaryArray as $bin) {
            if (strlen($bin) === 8) {
                $decoded .= chr(bindec($bin));
            }
        }
        return $decoded;
    }
}

/**
 * Returns corporate contact details and address for an Insurance Company.
 */
function getInsuranceCompanyInfo(?string $companyName): array {
    $name = trim($companyName ?? '');
    if (empty($name)) {
        $name = 'Star Health and Allied Insurance Co. Ltd.';
    }

    $map = [
        'Star Health Insurance' => [
            'name'           => 'Star Health and Allied Insurance Co. Ltd.',
            'address_1'      => 'No. 15, Sri Balaji Complex, 1st Floor, Whites Road',
            'city_state_zip' => 'Chennai, Tamil Nadu 600014',
            'phone'          => '+91 44 2828 8800',
            'email'          => 'claims@starhealth.in'
        ],
        'HDFC ERGO Health Insurance' => [
            'name'           => 'HDFC ERGO General Insurance Company Ltd.',
            'address_1'      => '6th Floor, Leela Business Park, Andheri-Kurla Road',
            'city_state_zip' => 'Mumbai, Maharashtra 400059',
            'phone'          => '1800 2666 400',
            'email'          => 'care@hdfcergo.com'
        ],
        'ICICI Lombard Health' => [
            'name'           => 'ICICI Lombard General Insurance Co. Ltd.',
            'address_1'      => 'ICICI Lombard House, 414 Veer Savarkar Marg, Prabhadevi',
            'city_state_zip' => 'Mumbai, Maharashtra 400025',
            'phone'          => '1800 2666',
            'email'          => 'customersupport@icicilombard.com'
        ],
        'Care Health Insurance' => [
            'name'           => 'Care Health Insurance Limited',
            'address_1'      => '5th Floor, 19 Chawla House, Nehru Place',
            'city_state_zip' => 'New Delhi, Delhi 110019',
            'phone'          => '1800 102 4488',
            'email'          => 'customerfirst@careinsurance.com'
        ],
        'Niva Bupa Health Insurance' => [
            'name'           => 'Niva Bupa Health Insurance Co. Ltd.',
            'address_1'      => 'C-1, Minimum Wages Complex, Okhla Phase 1',
            'city_state_zip' => 'New Delhi, Delhi 110020',
            'phone'          => '1860 500 8888',
            'email'          => 'customercare@nivabupa.com'
        ]
    ];

    foreach ($map as $k => $info) {
        if (stripos($name, $k) !== false || stripos($k, $name) !== false) {
            return $info;
        }
    }

    return [
        'name'           => $name,
        'address_1'      => 'Corporate Claims & Underwriting Tower, Level 4, Financial District',
        'city_state_zip' => 'Chennai, Tamil Nadu 600001',
        'phone'          => '+91 1800 102 8900',
        'email'          => 'claims-desk@insurancee.gov.in'
    ];
}

/**
 * Extracts Line 1 and City/State/ZIP details from patient address / eKYC.
 */
function getPolicyholderAddressDetails(?string $rawAddress, ?string $ekycDataJson = null): array {
    $line1 = '';
    $cityStateZip = '';

    if (!empty($ekycDataJson)) {
        $ekyc = json_decode($ekycDataJson, true);
        if (is_array($ekyc)) {
            $district = trim($ekyc['district'] ?? '');
            $state    = trim($ekyc['state'] ?? '');
            $pincode  = trim($ekyc['pincode'] ?? '');
            $full     = trim($ekyc['full_address'] ?? '');

            if ($district || $state || $pincode) {
                $cityStateZip = trim(implode(', ', array_filter([$district, $state])) . ($pincode ? ", $pincode" : ''));
            }
            if ($full) {
                $lines = preg_split('/[\r\n]+/', $full);
                $line1 = trim($lines[0]);
                if (empty($cityStateZip) && count($lines) > 1) {
                    $cityStateZip = trim(implode(', ', array_slice($lines, 1)));
                }
            }
        }
    }

    if (empty($line1) && !empty($rawAddress)) {
        $lines = preg_split('/[\r\n]+/', trim($rawAddress));
        $line1 = trim($lines[0]);
        if (count($lines) > 1 && empty($cityStateZip)) {
            $cityStateZip = trim(implode(', ', array_slice($lines, 1)));
        } else if (empty($cityStateZip)) {
            $parts = explode(',', $rawAddress);
            if (count($parts) >= 2) {
                $line1 = trim($parts[0] . ', ' . $parts[1]);
                $cityStateZip = trim(implode(', ', array_slice($parts, 2)));
            }
        }
    }

    if (empty($line1)) {
        $line1 = 'No. 42, Anna Nagar West Extension';
    }
    if (empty($cityStateZip)) {
        $cityStateZip = 'Chennai, Tamil Nadu, 600101';
    }

    return [
        'address_1'      => $line1,
        'city_state_zip' => $cityStateZip
    ];
}
