<?php
/**
 * Secure PHP Session Management Engine
 * 
 * Enforces HttpOnly, SameSite=Lax, robust HTTPS detection, and Session Persistence.
 */

require_once __DIR__ . '/../config/security.php';

if (session_status() === PHP_SESSION_NONE) {
    if (!headers_sent()) {
        $isSecure = (
            (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] == 1)) ||
            (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
            (isset($_SERVER['HTTP_CF_VISITOR']) && strpos($_SERVER['HTTP_CF_VISITOR'], 'https') !== false) ||
            (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
        );

        $sessionLifetime = defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 2592000;

        // Check if session save path exists and is writable; fallback if needed
        $savePath = ini_get('session.save_path');
        if (!empty($savePath) && (!is_dir($savePath) || !is_writable($savePath))) {
            $tempDir = sys_get_temp_dir();
            if (is_dir($tempDir) && is_writable($tempDir)) {
                session_save_path($tempDir);
            }
        }

        session_set_cookie_params([
            'lifetime' => $sessionLifetime,
            'path'     => '/',
            'secure'   => $isSecure,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        ini_set('session.gc_maxlifetime', (string)$sessionLifetime);
        ini_set('session.cookie_lifetime', (string)$sessionLifetime);
        ini_set('session.use_only_cookies', '1');
    }

    @session_start();
}

/**
 * Regenerates session ID safely to prevent session fixation attacks.
 */
function secureRegenerateSession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

