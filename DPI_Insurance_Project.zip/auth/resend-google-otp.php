<?php
/**
 * Google OTP Resend Processor
 * 
 * Enforces 60-second cooldown, invalidates prior active OTPs,
 * generates a fresh 6-digit cryptographically secure OTP,
 * and sends it to the user's authenticated Google email address.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/verify-google-otp.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['google_otp_errors'] = ["Session token expired. Please try again."];
    header("Location: ../public/verify-google-otp.php");
    exit();
}

$userId      = (int)($_SESSION['google_auth_pending_user_id'] ?? 0);
$googleEmail = $_SESSION['google_auth_pending_email'] ?? '';
$googleName  = $_SESSION['google_auth_pending_name'] ?? 'User';

if ($userId <= 0 || empty($googleEmail)) {
    $_SESSION['login_errors'] = ["Authentication session expired. Please sign in again."];
    header("Location: ../public/login.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // Check resend cooldown
    $stmt = $pdo->prepare("
        SELECT resend_cooldown_until 
        FROM email_otps 
        WHERE user_id = :user_id 
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([':user_id' => $userId]);
    $lastOtp = $stmt->fetch();

    if ($lastOtp && $lastOtp['resend_cooldown_until'] && strtotime($lastOtp['resend_cooldown_until']) > time()) {
        $remaining = strtotime($lastOtp['resend_cooldown_until']) - time();
        $_SESSION['google_otp_errors'] = ["Please wait $remaining seconds before requesting another code."];
        header("Location: ../public/verify-google-otp.php");
        exit();
    }

    $pdo->beginTransaction();

    // Invalidate existing active OTPs
    $inv = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE user_id = :user_id AND is_used = 0");
    $inv->execute([':user_id' => $userId]);

    // Generate new OTP
    $rawOtp = sprintf("%06d", random_int(100000, 999999));
    $otpHash = hash('sha256', $rawOtp);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRATION_MINUTES . ' minutes'));
    $cooldownUntil = date('Y-m-d H:i:s', strtotime('+' . RESEND_COOLDOWN_SECONDS . ' seconds'));

    $insertOtp = $pdo->prepare("
        INSERT INTO email_otps (user_id, otp_hash, expires_at, attempts, max_attempts, resend_cooldown_until, is_used, created_at)
        VALUES (:user_id, :otp_hash, :expires_at, 0, :max_attempts, :cooldown, 0, NOW())
    ");
    $insertOtp->execute([
        ':user_id'      => $userId,
        ':otp_hash'     => $otpHash,
        ':expires_at'   => $expiresAt,
        ':max_attempts' => MAX_OTP_ATTEMPTS,
        ':cooldown'     => $cooldownUntil
    ]);

    $pdo->commit();

    // Send OTP to the Google email address
    $emailSent = sendGoogleOTPEmail($googleEmail, $googleName, $rawOtp);

    if (!$emailSent) {
        error_log("Failed to resend Google OTP email to: $googleEmail");
    }

    logAuditEvent($userId, 'GOOGLE_OTP_RESENT', "New Google OTP resent to Google email account");

    $_SESSION['google_otp_success'] = "A new verification code has been sent to your Google email.";

    header("Location: ../public/verify-google-otp.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Google Resend OTP Error: " . $e->getMessage());
    $_SESSION['google_otp_errors'] = ["Failed to resend code: " . $e->getMessage()];
    header("Location: ../public/verify-google-otp.php");
    exit();
}
