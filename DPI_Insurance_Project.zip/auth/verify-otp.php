<?php
/**
 * OTP Verification Processor (Phase 9)
 * 
 * Verifies submitted OTP SHA-256 hash against email_otps table.
 * On success: Sets email_verified = 1 and status = 'active' in users table.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/verify-email.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['otp_errors'] = ["Invalid CSRF token."];
    header("Location: ../public/verify-email.php");
    exit();
}

$userId  = (int)($_SESSION['verify_user_id'] ?? 0);
$userOtp = trim($_POST['otp_code'] ?? '');

if ($userId <= 0 || empty($userOtp) || strlen($userOtp) !== 6) {
    $_SESSION['otp_errors'] = ["Please enter a valid 6-digit OTP code."];
    header("Location: ../public/verify-email.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // Fetch active OTP record for user
    $stmt = $pdo->prepare("
        SELECT id, otp_hash, expires_at, attempts, max_attempts 
        FROM email_otps 
        WHERE user_id = :user_id AND is_used = 0 
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([':user_id' => $userId]);
    $otpRecord = $stmt->fetch();

    if (!$otpRecord) {
        $_SESSION['otp_errors'] = ["No active OTP request found. Please request a new OTP."];
        header("Location: ../public/verify-email.php");
        exit();
    }

    // Check maximum attempts (5 limit)
    if ($otpRecord['attempts'] >= $otpRecord['max_attempts']) {
        // Invalidate OTP
        $inv = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
        $inv->execute([':id' => $otpRecord['id']]);

        logAuditEvent($userId, 'OTP_MAX_ATTEMPTS_EXCEEDED', "Maximum verification attempts exceeded for OTP ID {$otpRecord['id']}");
        $_SESSION['otp_errors'] = ["Maximum verification attempts exceeded. Please request a new OTP."];
        header("Location: ../public/verify-email.php");
        exit();
    }

    // Check expiration timestamp
    if (strtotime($otpRecord['expires_at']) <= time()) {
        $inv = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
        $inv->execute([':id' => $otpRecord['id']]);

        logAuditEvent($userId, 'OTP_EXPIRED', "Expired OTP attempt for user ID $userId");
        $_SESSION['otp_errors'] = ["The verification code has expired. Please request a new OTP."];
        header("Location: ../public/verify-email.php");
        exit();
    }

    // Compute SHA-256 hash of submitted OTP
    $submittedHash = hash('sha256', $userOtp);

    // Verify hash match
    if (!hash_equals($otpRecord['otp_hash'], $submittedHash)) {
        // Increment attempt counter
        $inc = $pdo->prepare("UPDATE email_otps SET attempts = attempts + 1 WHERE id = :id");
        $inc->execute([':id' => $otpRecord['id']]);

        $remaining = $otpRecord['max_attempts'] - ($otpRecord['attempts'] + 1);
        logAuditEvent($userId, 'OTP_VERIFICATION_FAILED', "Invalid OTP code entered ($remaining attempts remaining)");

        $_SESSION['otp_errors'] = ["Invalid verification code. You have $remaining attempt(s) remaining."];
        header("Location: ../public/verify-email.php");
        exit();
    }

    // SUCCESS! Mark email verified and account active
    $pdo->beginTransaction();

    $userUpdate = $pdo->prepare("UPDATE users SET email_verified = 1, status = 'active', updated_at = NOW() WHERE id = :id");
    $userUpdate->execute([':id' => $userId]);

    $otpUpdate = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
    $otpUpdate->execute([':id' => $otpRecord['id']]);

    $pdo->commit();

    logAuditEvent($userId, 'EMAIL_VERIFIED_SUCCESS', "Officer account activated successfully after email OTP verification");

    unset($_SESSION['verify_user_id']);
    unset($_SESSION['verify_email']);
    unset($_SESSION['dev_otp_display']);

    $_SESSION['login_success'] = "Email verified successfully! You may now sign in with your credentials.";
    header("Location: ../public/login.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['otp_errors'] = ["Verification error: " . $e->getMessage()];
    header("Location: ../public/verify-email.php");
    exit();
}
