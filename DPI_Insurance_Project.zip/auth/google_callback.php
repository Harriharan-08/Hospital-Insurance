<?php
/**
 * Route alias for Google OAuth 2.0 callback (underscore alias)
 */
require_once __DIR__ . '/google-callback.php';
