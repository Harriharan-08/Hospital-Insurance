<?php
/**
 * Forgot Password Token Generator Processor (Phase 12)
 * 
 * Enforces anti-enumeration user feedback. Stores SHA-256 token hash in password_resets table.
 * Sends real email reset URL via PHPMailer SMTP.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/forgot-password.php");
    exit();
}

$csrfToken     = $_POST[CSRF_TOKEN_NAME] ?? '';
$captchaAnswer = $_POST['captcha_answer'] ?? '';

if (!validateCSRFToken($csrfToken)) {
    $_SESSION['forgot_errors'] = ["Invalid CSRF token."];
    header("Location: ../public/forgot-password.php");
    exit();
}

if (!verifyMathCaptcha($captchaAnswer)) {
    $_SESSION['forgot_errors'] = ["The entered captcha is wrong"];
    header("Location: ../public/forgot-password.php");
    exit();
}

$email = sanitizeInput($_POST['email'] ?? '');

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['forgot_errors'] = ["Please enter a valid email address."];
    header("Location: ../public/forgot-password.php");
    exit();
}

// Anti-Enumeration generic success message
$genericSuccess = "If an account exists for " . htmlspecialchars($email) . ", password reset instructions have been sent.";

try {
    $pdo = getDBConnection();

    // Check if account exists
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if ($user) {
        $userId = (int)$user['id'];

        // Generate 64-character random token
        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . PASSWORD_RESET_EXPIRATION_HOURS . ' hours'));

        $pdo->beginTransaction();

        // Invalidate previous unused reset tokens for user
        $inv = $pdo->prepare("UPDATE password_resets SET used = 1 WHERE user_id = :user_id AND used = 0");
        $inv->execute([':user_id' => $userId]);

        // Store SHA-256 token hash
        $insertToken = $pdo->prepare("
            INSERT INTO password_resets (user_id, token_hash, expires_at, used, created_at)
            VALUES (:user_id, :token_hash, :expires_at, 0, NOW())
        ");
        $insertToken->execute([
            ':user_id'    => $userId,
            ':token_hash' => $tokenHash,
            ':expires_at' => $expiresAt
        ]);

        $pdo->commit();

        $resetUrl = APP_BASE_URL . "/public/reset-password.php?token=" . urlencode($rawToken);

        // Send Email via PHPMailer
        sendPasswordResetEmail($email, $user['full_name'], $resetUrl);

        logAuditEvent($userId, 'PASSWORD_RESET_REQUESTED', "Password reset link generated for email: $email");
        $_SESSION['dev_reset_url'] = $resetUrl; // Fallback display for dev testing
    }

    $_SESSION['forgot_success'] = $genericSuccess;
    header("Location: ../public/forgot-password.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['forgot_errors'] = ["Password reset request error: " . $e->getMessage()];
    header("Location: ../public/forgot-password.php");
    exit();
}

/**
 * Helper function to send Password Reset Email
 */
function sendPasswordResetEmail(string $toEmail, string $toName, string $resetUrl): bool {
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        return false;
    }
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request - ' . APP_NAME;

        $mail->Body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;'>
            <h2 style='color: #2563eb; text-align: center;'>" . APP_NAME . "</h2>
            <p>Dear <strong>" . htmlspecialchars($toName) . "</strong>,</p>
            <p>We received a request to reset your account password. Click the link below to set a new password:</p>
            <p style='text-align: center; margin: 25px 0;'>
                <a href='" . htmlspecialchars($resetUrl) . "' style='background-color: #2563eb; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;'>Reset My Password</a>
            </p>
            <p style='color: #64748b; font-size: 13px;'>This link is valid for <strong>1 hour</strong>. If you did not request a password reset, please ignore this message.</p>
        </div>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Failed to send reset email: " . $e->getMessage());
        return false;
    }
}
