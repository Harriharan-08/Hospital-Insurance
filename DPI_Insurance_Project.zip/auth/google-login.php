<?php
/**
 * Google OAuth 2.0 Login Initiator
 * 
 * Generates cryptographically secure state token and directly redirects
 * to Google OAuth 2.0 authentication endpoint.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/csrf.php';

$clientId = GOOGLE_CLIENT_ID;
$redirectUri = GOOGLE_REDIRECT_URI;

if (empty($clientId) || empty(GOOGLE_CLIENT_SECRET)) {
    $_SESSION['login_errors'] = ["Google OAuth credentials are not configured in environment."];
    header("Location: ../public/login.php");
    exit();
}

// Generate state token for CSRF defense
$state = bin2hex(random_bytes(32));
$_SESSION['google_oauth_state'] = $state;

$params = [
    'response_type' => 'code',
    'client_id'     => $clientId,
    'redirect_uri'  => $redirectUri,
    'scope'         => 'openid email profile',
    'state'         => $state,
    'access_type'   => 'online',
    'prompt'        => 'select_account'
];

session_write_close();

$authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
header("Location: " . $authUrl);
exit();
