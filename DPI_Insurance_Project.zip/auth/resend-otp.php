<?php
/**
 * OTP Resend Processor (Phase 8)
 * 
 * Enforces 60-second resend cooldown, invalidates previous OTPs,
 * generates a new cryptographically secure 6-digit OTP, stores SHA-256 hash, and delivers via SMTP.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/verify-email.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['otp_errors'] = ["Invalid CSRF token."];
    header("Location: ../public/verify-email.php");
    exit();
}

$userId = (int)($_SESSION['verify_user_id'] ?? 0);
if ($userId <= 0) {
    header("Location: ../public/register.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // Check user & latest OTP cooldown
    $stmt = $pdo->prepare("
        SELECT o.resend_cooldown_until, u.full_name, u.email 
        FROM users u 
        LEFT JOIN email_otps o ON o.user_id = u.id AND o.is_used = 0
        WHERE u.id = :id 
        ORDER BY o.id DESC LIMIT 1
    ");
    $stmt->execute([':id' => $userId]);
    $row = $stmt->fetch();

    if (!$row) {
        throw new Exception("User account not found.");
    }

    if ($row['resend_cooldown_until'] && strtotime($row['resend_cooldown_until']) > time()) {
        $remaining = strtotime($row['resend_cooldown_until']) - time();
        $_SESSION['otp_errors'] = ["Please wait $remaining seconds before requesting a new OTP."];
        header("Location: ../public/verify-email.php");
        exit();
    }

    $pdo->beginTransaction();

    // Invalidate all previous unexpired OTPs for this user
    $invalidate = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE user_id = :user_id AND is_used = 0");
    $invalidate->execute([':user_id' => $userId]);

    // Generate new 6-digit cryptographic OTP
    $rawOtp = sprintf("%06d", random_int(100000, 999999));
    $otpHash = hash('sha256', $rawOtp);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRATION_MINUTES . ' minutes'));
    $cooldownUntil = date('Y-m-d H:i:s', strtotime('+' . RESEND_COOLDOWN_SECONDS . ' seconds'));

    // Insert new OTP record (SHA-256 hash only)
    $insertOtp = $pdo->prepare("
        INSERT INTO email_otps (user_id, otp_hash, expires_at, attempts, max_attempts, resend_cooldown_until, is_used, created_at)
        VALUES (:user_id, :otp_hash, :expires_at, 0, 5, :cooldown, 0, NOW())
    ");

    $insertOtp->execute([
        ':user_id'  => $userId,
        ':otp_hash' => $otpHash,
        ':expires_at' => $expiresAt,
        ':cooldown' => $cooldownUntil
    ]);

    $pdo->commit();

    // Deliver via SMTP
    sendOTPEmail($row['email'], $row['full_name'], $rawOtp);

    logAuditEvent($userId, 'OTP_RESENT', "New OTP generated and sent to {$row['email']}");

    $_SESSION['dev_otp_display'] = $rawOtp; // Fallback display for dev testing
    $_SESSION['otp_success'] = "A new 6-digit OTP code has been sent to your email!";

    header("Location: ../public/verify-email.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['otp_errors'] = ["Failed to resend OTP: " . $e->getMessage()];
    header("Location: ../public/verify-email.php");
    exit();
}
