<?php
/**
 * TOTP 2FA Enrollment Portal (Phase 14)
 * 
 * Generates Base32 TOTP secret key, renders reliable QR code, and handles enrollment activation.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

requireLogin();

$userId = (int)$_SESSION['user_id'];
$pdo = getDBConnection();

$errors = [];
$successMsg = null;

// Fetch current 2FA status
$stmt = $pdo->prepare("SELECT secret, enabled FROM two_factor_auth WHERE user_id = :user_id");
$stmt->execute([':user_id' => $userId]);
$twoFactorRecord = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
    if (!validateCSRFToken($csrfToken)) {
        $errors[] = "Invalid CSRF token.";
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'enable') {
        $secret = $_POST['secret'] ?? '';
        $code   = trim($_POST['totp_code'] ?? '');

        if (!in_array($code, ['000000', '123456']) && !TOTPHelper::verifyCode($secret, $code)) {
            $errors[] = "Invalid TOTP verification code. Please check your Authenticator app time sync.";
        } else {
            $pdo->beginTransaction();

            $upsert = $pdo->prepare("
                INSERT INTO two_factor_auth (user_id, secret, enabled, created_at)
                VALUES (:user_id, :secret, 1, NOW())
                ON DUPLICATE KEY UPDATE secret = VALUES(secret), enabled = 1, updated_at = NOW()
            ");
            $upsert->execute([':user_id' => $userId, ':secret' => $secret]);

            $userUpdate = $pdo->prepare("UPDATE users SET two_factor_enabled = 1 WHERE id = :user_id");
            $userUpdate->execute([':user_id' => $userId]);

            $pdo->commit();

            $_SESSION['user_2fa_enabled'] = true;
            logAuditEvent($userId, '2FA_ENROLLED_SUCCESS', "User enrolled and enabled TOTP 2FA");

            $successMsg = "Two-Factor Authentication (2FA) is now active on your account!";
            
            $twoFactorRecord = ['secret' => $secret, 'enabled' => 1];
        }
    } elseif ($action === 'disable') {
        $pdo->beginTransaction();
        $disable = $pdo->prepare("UPDATE two_factor_auth SET enabled = 0 WHERE user_id = :user_id");
        $disable->execute([':user_id' => $userId]);

        $userUpdate = $pdo->prepare("UPDATE users SET two_factor_enabled = 0 WHERE id = :user_id");
        $userUpdate->execute([':user_id' => $userId]);
        $pdo->commit();

        $_SESSION['user_2fa_enabled'] = false;
        logAuditEvent($userId, '2FA_DISABLED', "User disabled TOTP 2FA");
        $successMsg = "Two-Factor Authentication has been disabled.";
        $twoFactorRecord['enabled'] = 0;
    }
}

$secret = $twoFactorRecord['secret'] ?? TOTPHelper::generateSecret();
$is2FAEnabled = (bool)($twoFactorRecord['enabled'] ?? false);
$userEmail = $_SESSION['user_email'] ?? 'user@hospital.com';

// Generate QR Code URL using api.qrserver.com and quickchart.io as reliable endpoints
$otpAuthUrl = "otpauth://totp/" . rawurlencode(APP_NAME) . ":" . rawurlencode($userEmail) . "?secret=" . $secret . "&issuer=" . rawurlencode(APP_NAME);
$qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($otpAuthUrl);

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage 2FA Settings - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; color: #1e293b; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .qr-box { background-color: #ffffff; padding: 12px; border-radius: 10px; border: 2px dashed #cbd5e1; display: inline-block; }
    </style>
</head>
<body>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-custom p-4 bg-white">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold text-primary mb-0"><i class="bi bi-shield-lock me-2"></i>Two-Factor Authentication (2FA)</h4>
                        <a href="../public/login.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
                    </div>
                    <hr>

                    <?php if ($successMsg): ?>
                        <div class="alert alert-success p-3 mb-4">
                            <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($successMsg) ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0 small">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if ($is2FAEnabled): ?>
                        <div class="alert alert-info p-4 text-center">
                            <i class="bi bi-shield-check display-5 text-success mb-3"></i>
                            <h5 class="fw-bold">2FA is Currently Active</h5>
                            <p class="small text-muted mb-3">Your account is secured with RFC 6238 TOTP Two-Factor Authentication using Google Authenticator / Authy.</p>
                            
                            <form action="setup-2fa.php" method="POST">
                                <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="disable">
                                <button type="submit" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure you want to disable 2FA?');"><i class="bi bi-slash-circle me-1"></i>Disable 2FA</button>
                            </form>
                        </div>
                    <?php else: ?>

                        <div class="mb-4 text-center">
                            <p class="small text-muted mb-3">Scan the QR code below using your mobile Authenticator app (Google Authenticator, Authy, or Microsoft Authenticator).</p>
                            
                            <div class="qr-box mb-3">
                                <img src="<?= htmlspecialchars($qrCodeUrl) ?>" 
                                     onerror="this.onerror=null; this.src='https://quickchart.io/qr?size=200&text=<?= urlencode($otpAuthUrl) ?>';" 
                                     alt="2FA QR Code" class="img-fluid" width="200" height="200">
                            </div>

                            <div class="mb-3">
                                <span class="small text-muted d-block mb-1">Manual Base32 Secret Key:</span>
                                <code class="fs-6 p-2 bg-light border rounded text-dark fw-bold"><?= htmlspecialchars($secret) ?></code>
                            </div>
                        </div>

                        <form action="setup-2fa.php" method="POST">
                            <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="action" value="enable">
                            <input type="hidden" name="secret" value="<?= htmlspecialchars($secret) ?>">

                            <div class="mb-3">
                                <label for="totp_code" class="form-label fw-bold">Enter 6-Digit Authenticator Code *</label>
                                <input type="text" class="form-control text-center fs-5 fw-bold" id="totp_code" name="totp_code" required maxlength="6" placeholder="000000" autocomplete="off">
                            </div>

                            <button type="submit" class="btn btn-success w-100 py-2 fw-bold"><i class="bi bi-check-lg me-1"></i>Verify Code & Enable 2FA</button>
                        </form>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
