<?php
/**
 * Google OAuth 2.0 Callback Controller (Direct Google Sign-In, No OTP)
 * 
 * Validates Google OAuth authorization response (or Google Account Chooser selection),
 * retrieves verified Google profile, associates/creates local user record,
 * creates authenticated session immediately, and redirects to dashboard.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/mail.php';

// 1. Handle OAuth Errors or User Cancellation
if (!empty($_GET['error'])) {
    $errorDesc = sanitizeInput($_GET['error_description'] ?? $_GET['error']);
    if ($_GET['error'] === 'access_denied') {
        $_SESSION['login_errors'] = ["Google Sign-In was cancelled."];
    } else {
        $_SESSION['login_errors'] = ["Google Sign-In failed: " . $errorDesc];
    }
    header("Location: ../public/login.php");
    exit();
}

$isDirectAuth = (isset($_POST['direct_google_auth']) && $_POST['direct_google_auth'] === '1');
$state        = $_POST['state'] ?? ($_GET['state'] ?? '');
$code         = $_GET['code'] ?? '';

// 2. Validate CSRF State Token
$expectedState = $_SESSION['google_oauth_state'] ?? '';
unset($_SESSION['google_oauth_state']);

if (empty($state) || empty($expectedState) || !hash_equals($expectedState, $state)) {
    $_SESSION['login_errors'] = ["Invalid or expired Google authentication session. Please try again."];
    header("Location: ../public/login.php");
    exit();
}

try {
    $googleEmail   = '';
    $googleId      = '';
    $googleName    = '';
    $googleGiven   = '';
    $googleFamily  = '';
    $googlePicture = '';

    if ($isDirectAuth) {
        // Direct Selection from Google Account Chooser
        $googleEmail = sanitizeInput($_POST['google_email'] ?? '');
        $googleName  = sanitizeInput($_POST['google_name'] ?? '');
        if (empty($googleName)) {
            $googleName = ucwords(str_replace(['.', '_'], ' ', explode('@', $googleEmail)[0]));
        }
        $googleId = 'goog_acc_' . substr(md5($googleEmail), 0, 16);
    } else {
        // Live Google OAuth Code Exchange
        $clientId     = GOOGLE_CLIENT_ID;
        $clientSecret = GOOGLE_CLIENT_SECRET;
        $redirectUri  = GOOGLE_REDIRECT_URI;

        if (empty($clientId) || empty($clientSecret) || empty($code)) {
            $_SESSION['login_errors'] = ["Google OAuth credentials or authorization code missing."];
            header("Location: ../public/login.php");
            exit();
        }

        // 3. Exchange Authorization Code for Access Token
        $tokenEndpoint = 'https://oauth2.googleapis.com/token';
        $postFields = [
            'code'          => $code,
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
            'redirect_uri'  => $redirectUri,
            'grant_type'    => 'authorization_code'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $tokenEndpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

        $response = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($curlErr || $httpCode !== 200) {
            error_log("Google OAuth Token Exchange Error (HTTP $httpCode): " . ($curlErr ?: $response));
            $_SESSION['login_errors'] = ["Failed to communicate with Google authentication services."];
            header("Location: ../public/login.php");
            exit();
        }

        $tokenData = json_decode($response, true);
        $accessToken = $tokenData['access_token'] ?? '';

        if (empty($accessToken)) {
            $_SESSION['login_errors'] = ["Unable to obtain access token from Google."];
            header("Location: ../public/login.php");
            exit();
        }

        // 4. Retrieve Google User Profile
        $userInfoEndpoint = 'https://www.googleapis.com/oauth2/v3/userinfo';
        $chUser = curl_init();
        curl_setopt($chUser, CURLOPT_URL, $userInfoEndpoint);
        curl_setopt($chUser, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($chUser, CURLOPT_TIMEOUT, 15);
        curl_setopt($chUser, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($chUser, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Accept: application/json'
        ]);

        $userResponse = curl_exec($chUser);
        $userCurlErr  = curl_error($chUser);
        $userHttpCode = curl_getinfo($chUser, CURLINFO_HTTP_CODE);
        curl_close($chUser);

        if ($userCurlErr || $userHttpCode !== 200) {
            error_log("Google UserInfo Request Error (HTTP $userHttpCode): " . ($userCurlErr ?: $userResponse));
            $_SESSION['login_errors'] = ["Failed to retrieve Google user profile."];
            header("Location: ../public/login.php");
            exit();
        }

        $googleProfile = json_decode($userResponse, true);

        $googleEmail   = trim($googleProfile['email'] ?? '');
        $googleId      = trim($googleProfile['sub'] ?? '');
        $googleName    = trim($googleProfile['name'] ?? 'Google User');
        $googleGiven   = trim($googleProfile['given_name'] ?? '');
        $googleFamily  = trim($googleProfile['family_name'] ?? '');
        $googlePicture = trim($googleProfile['picture'] ?? '');
    }

    // 5. Validate Email
    if (empty($googleEmail) || !filter_var($googleEmail, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['login_errors'] = ["Google account did not provide a valid email address."];
        header("Location: ../public/login.php");
        exit();
    }

    $pdo = getDBConnection();

    // 6. Lookup Existing User by Email
    $cleanEmail = strtolower(trim($googleEmail));
    $isDesignatedAdmin = ($cleanEmail === '11239a107@kanchiuniv.ac.in');
    $isDesignatedOfficer = ($cleanEmail === '11239a089@kanchiuniv.ac.in');

    $stmt = $pdo->prepare("SELECT id, role, full_name, username, email, status, email_verified, hospital_name, department FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $googleEmail]);
    $user = $stmt->fetch();

    if ($user) {
        // Enforce designated role and name for comfort and seamless access
        $targetRole = $user['role'];
        $targetDept = $user['department'];
        $targetName = $user['full_name'];

        if ($isDesignatedAdmin) {
            $targetRole = 'admin';
            $targetDept = 'Administration';
            $targetName = 'System Administrator';
            $pdo->prepare("UPDATE users SET role = 'admin', department = 'Administration', full_name = 'System Administrator', username = 'admin' WHERE id = :id")->execute([':id' => $user['id']]);
        } elseif ($isDesignatedOfficer) {
            $targetRole = 'officer';
            $targetDept = 'Claims & Billing';
            $targetName = 'Officer Sarah Connor';
            $pdo->prepare("UPDATE users SET role = 'officer', department = 'Claims & Billing', full_name = 'Officer Sarah Connor', first_name = 'Sarah', last_name = 'Connor', username = 'sarah_officer' WHERE id = :id")->execute([':id' => $user['id']]);
        }

        // Account Status Check
        if ($user['status'] === 'blocked') {
            logAuditEvent((int)$user['id'], 'GOOGLE_LOGIN_BLOCKED', "Blocked user attempted Google OAuth: $googleEmail");
            $_SESSION['login_errors'] = ["Your account has been suspended. Please contact administrator."];
            header("Location: ../public/login.php");
            exit();
        }

        // Update provider information, email_verified, and status
        $updateStmt = $pdo->prepare("
            UPDATE users 
            SET provider = 'google', provider_user_id = :p_uid, profile_image = COALESCE(:pic, profile_image), email_verified = 1, status = 'active', last_login = NOW(), updated_at = NOW() 
            WHERE id = :id
        ");
        $updateStmt->execute([
            ':p_uid' => $googleId,
            ':pic'   => $googlePicture ?: null,
            ':id'    => $user['id']
        ]);

        $userId   = (int)$user['id'];
        $userRole = $targetRole;
        $userName = $targetName;
    } else {
        // Auto-provision new account for first-time Google sign-in
        $pdo->beginTransaction();

        $baseUsername = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', explode('@', $googleEmail)[0]));
        if (strlen($baseUsername) < 4) {
            $baseUsername = 'user_' . substr(md5($googleEmail), 0, 6);
        }
        $candidateUsername = $baseUsername;
        $suffix = 1;
        while (true) {
            $check = $pdo->prepare("SELECT id FROM users WHERE username = :u LIMIT 1");
            $check->execute([':u' => $candidateUsername]);
            if (!$check->fetch()) break;
            $candidateUsername = $baseUsername . '_' . $suffix++;
        }

        if ($isDesignatedAdmin) {
            $assignedRole      = 'admin';
            $assignedDept      = 'Administration';
            $assignedName      = 'System Administrator';
            $assignedGiven     = 'System';
            $assignedFamily    = 'Administrator';
            $candidateUsername = 'admin';
        } elseif ($isDesignatedOfficer) {
            $assignedRole      = 'officer';
            $assignedDept      = 'Claims & Billing';
            $assignedName      = 'Officer Sarah Connor';
            $assignedGiven     = 'Sarah';
            $assignedFamily    = 'Connor';
            $candidateUsername = 'sarah_officer';
        } else {
            $assignedRole   = 'officer';
            $assignedDept   = 'Claims & Billing';
            $assignedName   = !empty($googleName) ? $googleName : 'Google User';
            $assignedGiven  = $googleGiven ?: null;
            $assignedFamily = $googleFamily ?: null;
        }

        $insertUser = $pdo->prepare("
            INSERT INTO users (role, full_name, first_name, last_name, username, hospital_name, department, email, provider, provider_user_id, profile_image, email_verified, status, last_login, created_at)
            VALUES (:role, :full_name, :first_name, :last_name, :username, 'City Central Hospital', :dept, :email, 'google', :provider_uid, :profile_image, 1, 'active', NOW(), NOW())
        ");
        $insertUser->execute([
            ':role'         => $assignedRole,
            ':full_name'    => $assignedName,
            ':first_name'   => $assignedGiven,
            ':last_name'    => $assignedFamily,
            ':username'     => $candidateUsername,
            ':dept'         => $assignedDept,
            ':email'        => $googleEmail,
            ':provider_uid' => $googleId,
            ':profile_image'=> $googlePicture ?: null
        ]);

        $userId   = (int)$pdo->lastInsertId();
        $userRole = $assignedRole;
        $userName = $assignedName;

        $pdo->commit();
    }

    $userName = !empty($userName) ? $userName : (!empty($googleName) ? $googleName : 'Google User');
    $userRole = !empty($userRole) ? $userRole : 'officer';

    // 7. Fetch full user profile for session creation
    $userStmt = $pdo->prepare("SELECT id, role, full_name, first_name, last_name, username, email, hospital_name, profile_image, provider FROM users WHERE id = :id LIMIT 1");
    $userStmt->execute([':id' => $userId]);
    $fullUser = $userStmt->fetch();

    if (!$fullUser) {
        throw new Exception("User profile not found.");
    }

    if ($isDesignatedOfficer) {
        $fullUser['full_name'] = 'Officer Sarah Connor';
        $fullUser['first_name'] = 'Sarah';
        $fullUser['last_name'] = 'Connor';
    } elseif ($isDesignatedAdmin) {
        $fullUser['full_name'] = 'System Administrator';
    }

    // 8. Establish Full Authenticated Session directly (Direct Google Sign-In, No OTP)
    secureRegenerateSession();

    $_SESSION['user_id']            = (int)$fullUser['id'];
    $_SESSION['user_role']          = $fullUser['role'];
    $_SESSION['user_name']          = $fullUser['full_name'];
    $_SESSION['user_first_name']    = $fullUser['first_name'] ?? '';
    $_SESSION['user_last_name']     = $fullUser['last_name'] ?? '';
    $_SESSION['user_email']         = $fullUser['email'];
    $_SESSION['user_avatar']        = $fullUser['profile_image'] ?? null;
    $_SESSION['user_profile_image'] = $fullUser['profile_image'] ?? null;
    $_SESSION['provider']           = 'google';
    $_SESSION['user_hospital']      = $fullUser['hospital_name'] ?? 'City Central Hospital';
    $_SESSION['user_2fa_enabled']   = false;
    $_SESSION['auth_state']         = AUTH_STATE_FULLY_AUTHENTICATED;

    // Clean up any pending OTP session variables
    unset($_SESSION['google_auth_pending_user_id']);
    unset($_SESSION['google_auth_pending_email']);
    unset($_SESSION['google_auth_pending_name']);
    unset($_SESSION['google_auth_pending_role']);
    unset($_SESSION['google_auth_pending_pic']);
    unset($_SESSION['google_otp_success']);
    unset($_SESSION['google_otp_errors']);

    logAuditEvent($userId, 'GOOGLE_LOGIN_SUCCESS', "User authenticated directly via Google OAuth 2.0 (Role: {$fullUser['role']})");

    session_write_close();

    // 9. Redirect directly to dashboard based on role
    $targetUrl = ($fullUser['role'] === 'admin') ? "../admin/dashboard.php" : "../officer/dashboard.php";
    header("Location: " . $targetUrl);
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Google Callback Processing Exception: " . $e->getMessage());
    $_SESSION['login_errors'] = ["An error occurred while processing Google login: " . $e->getMessage()];
    header("Location: ../public/login.php");
    exit();
}
