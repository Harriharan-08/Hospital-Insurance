<?php
/**
 * Google OTP Verification Processor
 * 
 * Verifies the 6-digit OTP SHA-256 hash against email_otps table,
 * activates the user's account if pending, regenerates session ID,
 * establishes FULLY_AUTHENTICATED session state, and redirects to dashboard.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/verify-google-otp.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['google_otp_errors'] = ["Session security token expired. Please try again."];
    header("Location: ../public/verify-google-otp.php");
    exit();
}

$userId  = (int)($_SESSION['google_auth_pending_user_id'] ?? 0);
$userOtp = trim($_POST['otp_code'] ?? '');

if ($userId <= 0) {
    $_SESSION['login_errors'] = ["Authentication session timed out. Please sign in with Google again."];
    header("Location: ../public/login.php");
    exit();
}

if (empty($userOtp) || strlen($userOtp) !== 6 || !ctype_digit($userOtp)) {
    $_SESSION['google_otp_errors'] = ["Please enter a valid 6-digit OTP verification code."];
    header("Location: ../public/verify-google-otp.php");
    exit();
}

try {
    $pdo = getDBConnection();

    // 1. Fetch active OTP record for user
    $stmt = $pdo->prepare("
        SELECT id, otp_hash, expires_at, attempts, max_attempts 
        FROM email_otps 
        WHERE user_id = :user_id AND is_used = 0 
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([':user_id' => $userId]);
    $otpRecord = $stmt->fetch();

    if (!$otpRecord) {
        $_SESSION['google_otp_errors'] = ["No active verification code found. Please request a new code."];
        header("Location: ../public/verify-google-otp.php");
        exit();
    }

    // 2. Check maximum attempts limit
    if ($otpRecord['attempts'] >= $otpRecord['max_attempts']) {
        $inv = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
        $inv->execute([':id' => $otpRecord['id']]);

        logAuditEvent($userId, 'GOOGLE_OTP_MAX_ATTEMPTS_EXCEEDED', "Max OTP attempts reached for user ID $userId");
        $_SESSION['google_otp_errors'] = ["Maximum verification attempts exceeded. Please request a new OTP code."];
        header("Location: ../public/verify-google-otp.php");
        exit();
    }

    // 3. Check expiration timestamp
    if (strtotime($otpRecord['expires_at']) <= time()) {
        $inv = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
        $inv->execute([':id' => $otpRecord['id']]);

        logAuditEvent($userId, 'GOOGLE_OTP_EXPIRED', "Expired Google OTP attempt for user ID $userId");
        $_SESSION['google_otp_errors'] = ["The verification code has expired. Please request a new OTP code."];
        header("Location: ../public/verify-google-otp.php");
        exit();
    }

    // 4. Verify SHA-256 Hash
    $submittedHash = hash('sha256', $userOtp);

    if (!hash_equals($otpRecord['otp_hash'], $submittedHash)) {
        $inc = $pdo->prepare("UPDATE email_otps SET attempts = attempts + 1 WHERE id = :id");
        $inc->execute([':id' => $otpRecord['id']]);

        $remaining = $otpRecord['max_attempts'] - ($otpRecord['attempts'] + 1);
        logAuditEvent($userId, 'GOOGLE_OTP_FAILED', "Invalid OTP entered ($remaining attempts remaining)");

        $_SESSION['google_otp_errors'] = ["Incorrect verification code. You have $remaining attempt(s) remaining."];
        header("Location: ../public/verify-google-otp.php");
        exit();
    }

    // 5. SUCCESS! Activate account and mark OTP used
    $pdo->beginTransaction();

    $userUpdate = $pdo->prepare("
        UPDATE users 
        SET email_verified = 1, status = 'active', last_login = NOW(), updated_at = NOW() 
        WHERE id = :id
    ");
    $userUpdate->execute([':id' => $userId]);

    $otpUpdate = $pdo->prepare("UPDATE email_otps SET is_used = 1 WHERE id = :id");
    $otpUpdate->execute([':id' => $otpRecord['id']]);

    $pdo->commit();

    // 6. Fetch complete user profile for session creation
    $userStmt = $pdo->prepare("SELECT id, role, full_name, first_name, last_name, username, email, hospital_name, profile_image, provider FROM users WHERE id = :id LIMIT 1");
    $userStmt->execute([':id' => $userId]);
    $user = $userStmt->fetch();

    if (!$user) {
        throw new Exception("User profile not found.");
    }

    // 7. Establish Full Authenticated Session
    secureRegenerateSession();

    $_SESSION['user_id']            = (int)$user['id'];
    $_SESSION['user_role']          = $user['role'];
    $_SESSION['user_name']          = $user['full_name'];
    $_SESSION['user_first_name']    = $user['first_name'] ?? '';
    $_SESSION['user_last_name']     = $user['last_name'] ?? '';
    $_SESSION['user_email']         = $user['email'];
    $_SESSION['user_avatar']        = $user['profile_image'] ?? null;
    $_SESSION['user_profile_image'] = $user['profile_image'] ?? null;
    $_SESSION['provider']           = 'google';
    $_SESSION['user_hospital']      = $user['hospital_name'] ?? 'City Central Hospital';
    $_SESSION['user_2fa_enabled']   = false;
    $_SESSION['auth_state']         = AUTH_STATE_FULLY_AUTHENTICATED;

    // Clean up temporary Google auth session keys
    unset($_SESSION['google_auth_pending_user_id']);
    unset($_SESSION['google_auth_pending_email']);
    unset($_SESSION['google_auth_pending_name']);
    unset($_SESSION['google_auth_pending_role']);
    unset($_SESSION['google_auth_pending_pic']);
    unset($_SESSION['dev_otp_display']);

    logAuditEvent($userId, 'GOOGLE_LOGIN_SUCCESS', "User authenticated successfully via Google OAuth + Email OTP (Role: {$user['role']})");

    session_write_close();

    // 8. Redirect to the existing dashboard based on user role
    $targetUrl = ($user['role'] === 'admin') ? "../admin/dashboard.php" : "../officer/dashboard.php";
    header("Location: " . $targetUrl);
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Google OTP Verification Error: " . $e->getMessage());
    $_SESSION['google_otp_errors'] = ["An error occurred during verification: " . $e->getMessage()];
    header("Location: ../public/verify-google-otp.php");
    exit();
}
