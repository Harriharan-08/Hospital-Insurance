<?php
/**
 * Officer Registration Processor (Phase 5 & 8)
 * 
 * Enforces role = 'officer', validates Math CAPTCHA, validates uniqueness,
 * hashes password, generates 6-digit SHA-256 email OTP, and sends real SMTP email.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/register.php");
    exit();
}

$csrfToken     = $_POST[CSRF_TOKEN_NAME] ?? '';
$captchaAnswer = $_POST['captcha_answer'] ?? '';

$_SESSION['register_form_data'] = $_POST;
$errors = [];

// 1. Validate CSRF Token
if (!validateCSRFToken($csrfToken)) {
    $errors[] = "Security check failed. Invalid CSRF token.";
}

// 2. Validate CAPTCHA
if (!verifyMathCaptcha($captchaAnswer)) {
    $errors[] = "The entered captcha is wrong";
}

$fullName        = sanitizeInput($_POST['full_name'] ?? '');
$username        = sanitizeInput($_POST['username'] ?? '');
$email           = sanitizeInput($_POST['email'] ?? '');
$hospitalName    = sanitizeInput($_POST['hospital_name'] ?? '');
$department      = sanitizeInput($_POST['department'] ?? '');
$phone           = sanitizeInput($_POST['phone'] ?? '');
$password        = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

// 3. Input Validation Rules
if (empty($fullName) || empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
    $errors[] = "Please fill in all required fields.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Please enter a valid email address.";
}

if (strlen($username) < 4 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    $errors[] = "Username must be at least 4 characters and contain only letters, numbers, and underscores.";
}

if (strlen($password) < 8) {
    $errors[] = "Password must be at least 8 characters long.";
}

if ($password !== $confirmPassword) {
    $errors[] = "Password confirmation does not match.";
}

// 4. Uniqueness Checks against MySQL `users` Table
if (empty($errors)) {
    try {
        $pdo = getDBConnection();

        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
        $stmt->execute([':username' => $username, ':email' => $email]);
        if ($stmt->fetch()) {
            $errors[] = "The username or email address is already registered.";
        }
    } catch (Exception $e) {
        $errors[] = "Database check error: " . $e->getMessage();
    }
}

if (!empty($errors)) {
    $_SESSION['register_errors'] = $errors;
    header("Location: ../public/register.php");
    exit();
}

try {
    $pdo = getDBConnection();
    $pdo->beginTransaction();

    // 5. Password Hashing & Account Creation (Role automatically = 'officer')
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $insertUser = $pdo->prepare("
        INSERT INTO users (role, full_name, username, hospital_name, department, phone, email, password_hash, email_verified, status, created_at)
        VALUES ('officer', :full_name, :username, :hospital_name, :department, :phone, :email, :password_hash, 0, 'pending', NOW())
    ");

    $insertUser->execute([
        ':full_name'     => $fullName,
        ':username'      => $username,
        ':hospital_name' => $hospitalName,
        ':department'    => $department,
        ':phone'         => $phone,
        ':email'         => $email,
        ':password_hash' => $passwordHash
    ]);

    $userId = (int)$pdo->lastInsertId();

    // 6. Generate 6-Digit Cryptographic Email OTP (Phase 8)
    $rawOtp = sprintf("%06d", random_int(100000, 999999));
    $otpHash = hash('sha256', $rawOtp);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+' . OTP_EXPIRATION_MINUTES . ' minutes'));
    $cooldownUntil = date('Y-m-d H:i:s', strtotime('+' . RESEND_COOLDOWN_SECONDS . ' seconds'));

    $insertOtp = $pdo->prepare("
        INSERT INTO email_otps (user_id, otp_hash, expires_at, attempts, max_attempts, resend_cooldown_until, is_used, created_at)
        VALUES (:user_id, :otp_hash, :expires_at, 0, 5, :cooldown, 0, NOW())
    ");

    $insertOtp->execute([
        ':user_id'     => $userId,
        ':otp_hash'    => $otpHash,
        ':expires_at'  => $expiresAt,
        ':cooldown'    => $cooldownUntil
    ]);

    $pdo->commit();

    // 7. Real SMTP Email Delivery via PHPMailer (Phase 7)
    $emailSent = sendOTPEmail($email, $fullName, $rawOtp);

    logAuditEvent($userId, 'REGISTRATION_SUBMITTED', "Officer account created for $username ($email). OTP generated.");

    unset($_SESSION['register_form_data']);
    $_SESSION['verify_user_id'] = $userId;
    $_SESSION['verify_email']   = $email;
    $_SESSION['dev_otp_display'] = $rawOtp; // Development fallback display

    header("Location: ../public/verify-email.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['register_errors'] = ["Registration failed: " . $e->getMessage()];
    header("Location: ../public/register.php");
    exit();
}
