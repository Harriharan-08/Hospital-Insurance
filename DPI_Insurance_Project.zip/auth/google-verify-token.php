<?php
/**
 * Google Identity Services (GIS) ID Token Verification Endpoint
 * 
 * Verifies Google JWT ID tokens server-side directly against Google's tokeninfo API,
 * validates email verification, client audience, and expiration claims,
 * links/auto-provisions user records in MySQL, establishes full authenticated session,
 * and returns redirect response to the existing dashboard (NO OTP).
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/mail.php';

function jsonError(string $message, int $statusCode = 400) {
    http_response_code($statusCode);
    echo json_encode([
        'success' => false,
        'error'   => $message
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError("Invalid request method. POST required.", 405);
}

// 1. Parse JSON or POST payload
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!is_array($data)) {
    $data = $_POST;
}

$idToken   = trim($data['id_token'] ?? '');
$csrfToken = trim($data['csrf_token'] ?? ($_POST[CSRF_TOKEN_NAME] ?? ''));

if (empty($idToken)) {
    jsonError("Missing Google ID token.");
}

// 2. CSRF Token Validation (if provided)
if (!empty($csrfToken) && !validateCSRFToken($csrfToken)) {
    jsonError("Session security token expired. Please refresh the page.", 403);
}

try {
    // 3. Verify Google ID Token server-side via Google's tokeninfo API
    $tokenInfoEndpoint = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenInfoEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr || $httpCode !== 200 || empty($response)) {
        error_log("Google ID Token Verification Error (HTTP $httpCode): " . ($curlErr ?: $response));
        jsonError("Google token verification failed. Please try signing in again.");
    }

    $tokenPayload = json_decode($response, true);

    if (!is_array($tokenPayload) || empty($tokenPayload['sub']) || empty($tokenPayload['email'])) {
        jsonError("Invalid token payload returned by Google.");
    }

    // 4. Validate Token Claims
    $googleId      = trim($tokenPayload['sub']);
    $googleEmail   = strtolower(trim($tokenPayload['email']));
    $googleName    = trim($tokenPayload['name'] ?? 'Google User');
    $googleGiven   = trim($tokenPayload['given_name'] ?? '');
    $googleFamily  = trim($tokenPayload['family_name'] ?? '');
    $googlePicture = trim($tokenPayload['picture'] ?? '');
    $emailVerified = $tokenPayload['email_verified'] ?? false;
    $aud           = trim($tokenPayload['aud'] ?? '');
    $iss           = trim($tokenPayload['iss'] ?? '');
    $exp           = (int)($tokenPayload['exp'] ?? 0);

    // Verify token expiration
    if ($exp > 0 && $exp < time()) {
        jsonError("Google authentication token has expired. Please sign in again.");
    }

    // Verify Issuer
    $validIssuers = ['accounts.google.com', 'https://accounts.google.com'];
    if (!empty($iss) && !in_array($iss, $validIssuers, true)) {
        jsonError("Invalid token issuer.");
    }

    // Verify Audience / Client ID (if configured in environment)
    $expectedClientId = GOOGLE_CLIENT_ID;
    if (!empty($expectedClientId) && $aud !== $expectedClientId) {
        error_log("Google Token Audience Mismatch: Expected '$expectedClientId', got '$aud'");
        jsonError("Google Client ID mismatch. Token not authorized for this application.");
    }

    // Verify Email Format and Verification
    if (!filter_var($googleEmail, FILTER_VALIDATE_EMAIL)) {
        jsonError("Google account did not provide a valid email address.");
    }

    $isVerified = ($emailVerified === true || $emailVerified === 'true' || $emailVerified === 1 || $emailVerified === '1');
    if (!$isVerified) {
        jsonError("Your Google email is not verified with Google. Please verify your email with Google first.");
    }

    // 5. Database User Resolution (MySQL via PDO)
    $pdo = getDBConnection();

    $cleanEmail = strtolower(trim($googleEmail));
    $isDesignatedAdmin = ($cleanEmail === '11239a107@kanchiuniv.ac.in');
    $isDesignatedOfficer = ($cleanEmail === '11239a089@kanchiuniv.ac.in');

    $stmt = $pdo->prepare("SELECT id, role, full_name, first_name, last_name, username, email, status, hospital_name, department FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $googleEmail]);
    $user = $stmt->fetch();

    if ($user) {
        // Enforce designated roles and display names for Google sign-in
        $targetRole = $user['role'];
        $targetDept = $user['department'];
        $targetName = $user['full_name'];

        if ($isDesignatedAdmin) {
            $targetRole = 'admin';
            $targetDept = 'Administration';
            $targetName = 'System Administrator';
            $pdo->prepare("UPDATE users SET role = 'admin', department = 'Administration', full_name = 'System Administrator', username = 'admin' WHERE id = :id")->execute([':id' => $user['id']]);
        } elseif ($isDesignatedOfficer) {
            $targetRole = 'officer';
            $targetDept = 'Claims & Billing';
            $targetName = 'Officer Sarah Connor';
            $pdo->prepare("UPDATE users SET role = 'officer', department = 'Claims & Billing', full_name = 'Officer Sarah Connor', first_name = 'Sarah', last_name = 'Connor', username = 'sarah_officer' WHERE id = :id")->execute([':id' => $user['id']]);
        }

        // Account Status Check
        if ($user['status'] === 'blocked') {
            logAuditEvent((int)$user['id'], 'GOOGLE_LOGIN_BLOCKED', "Blocked user attempted Google Sign-In: $googleEmail");
            jsonError("Your account has been suspended. Please contact administrator.", 403);
        }

        // Update provider information, email_verified = 1, status = active, last_login = NOW()
        $updateStmt = $pdo->prepare("
            UPDATE users 
            SET provider = 'google', provider_user_id = :p_uid, profile_image = COALESCE(:pic, profile_image), email_verified = 1, status = 'active', last_login = NOW(), updated_at = NOW() 
            WHERE id = :id
        ");
        $updateStmt->execute([
            ':p_uid' => $googleId,
            ':pic'   => $googlePicture ?: null,
            ':id'    => $user['id']
        ]);

        $userId   = (int)$user['id'];
        $userRole = $targetRole;
    } else {
        // Auto-provision new account for first-time Google sign-in
        $pdo->beginTransaction();

        $baseUsername = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', explode('@', $googleEmail)[0]));
        if (strlen($baseUsername) < 4) {
            $baseUsername = 'user_' . substr(md5($googleEmail), 0, 6);
        }
        $candidateUsername = $baseUsername;
        $suffix = 1;
        while (true) {
            $check = $pdo->prepare("SELECT id FROM users WHERE username = :u LIMIT 1");
            $check->execute([':u' => $candidateUsername]);
            if (!$check->fetch()) break;
            $candidateUsername = $baseUsername . '_' . $suffix++;
        }

        if ($isDesignatedAdmin) {
            $assignedRole      = 'admin';
            $assignedDept      = 'Administration';
            $assignedName      = 'System Administrator';
            $assignedGiven     = 'System';
            $assignedFamily    = 'Administrator';
            $candidateUsername = 'admin';
        } elseif ($isDesignatedOfficer) {
            $assignedRole      = 'officer';
            $assignedDept      = 'Claims & Billing';
            $assignedName      = 'Officer Sarah Connor';
            $assignedGiven     = 'Sarah';
            $assignedFamily    = 'Connor';
            $candidateUsername = 'sarah_officer';
        } else {
            $assignedRole   = 'officer';
            $assignedDept   = 'Claims & Billing';
            $assignedName   = !empty($googleName) ? $googleName : 'Google User';
            $assignedGiven  = $googleGiven ?: null;
            $assignedFamily = $googleFamily ?: null;
        }

        $insertUser = $pdo->prepare("
            INSERT INTO users (role, full_name, first_name, last_name, username, hospital_name, department, email, provider, provider_user_id, profile_image, email_verified, status, last_login, created_at)
            VALUES (:role, :full_name, :first_name, :last_name, :username, 'City Central Hospital', :dept, :email, 'google', :provider_uid, :profile_image, 1, 'active', NOW(), NOW())
        ");
        $insertUser->execute([
            ':role'         => $assignedRole,
            ':full_name'    => $assignedName,
            ':first_name'   => $assignedGiven,
            ':last_name'    => $assignedFamily,
            ':username'     => $candidateUsername,
            ':dept'         => $assignedDept,
            ':email'        => $googleEmail,
            ':provider_uid' => $googleId,
            ':profile_image'=> $googlePicture ?: null
        ]);

        $userId   = (int)$pdo->lastInsertId();
        $userRole = $assignedRole;

        $pdo->commit();
    }

    // 6. Fetch full user profile for session creation
    $userStmt = $pdo->prepare("SELECT id, role, full_name, first_name, last_name, username, email, hospital_name, profile_image, provider FROM users WHERE id = :id LIMIT 1");
    $userStmt->execute([':id' => $userId]);
    $fullUser = $userStmt->fetch();

    if (!$fullUser) {
        throw new Exception("User profile not found.");
    }

    if ($isDesignatedOfficer) {
        $fullUser['full_name'] = 'Officer Sarah Connor';
        $fullUser['first_name'] = 'Sarah';
        $fullUser['last_name'] = 'Connor';
    } elseif ($isDesignatedAdmin) {
        $fullUser['full_name'] = 'System Administrator';
    }

    // 7. Establish Full Authenticated Session directly (no secondary OTP needed for Google Sign-In)
    secureRegenerateSession();

    $_SESSION['user_id']            = (int)$fullUser['id'];
    $_SESSION['user_role']          = $fullUser['role'];
    $_SESSION['user_name']          = $fullUser['full_name'];
    $_SESSION['user_first_name']    = $fullUser['first_name'] ?? '';
    $_SESSION['user_last_name']     = $fullUser['last_name'] ?? '';
    $_SESSION['user_email']         = $fullUser['email'];
    $_SESSION['user_avatar']        = $fullUser['profile_image'] ?? null;
    $_SESSION['user_profile_image'] = $fullUser['profile_image'] ?? null;
    $_SESSION['provider']           = 'google';
    $_SESSION['user_hospital']      = $fullUser['hospital_name'] ?? 'City Central Hospital';
    $_SESSION['user_2fa_enabled']   = false;
    $_SESSION['auth_state']         = AUTH_STATE_FULLY_AUTHENTICATED;

    logAuditEvent($userId, 'GOOGLE_LOGIN_SUCCESS', "User authenticated directly via Google GIS (Role: {$fullUser['role']})");

    session_write_close();

    $targetUrl = ($fullUser['role'] === 'admin') ? "../admin/dashboard.php" : "../officer/dashboard.php";

    echo json_encode([
        'success'  => true,
        'redirect' => $targetUrl,
        'message'  => 'Google authentication successful.'
    ]);
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Google Token Verification Exception: " . $e->getMessage());
    jsonError("An unexpected server error occurred: " . $e->getMessage(), 500);
}
