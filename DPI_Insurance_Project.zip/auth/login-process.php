<?php
/**
 * Password Login Processor (Phase 10 & 11)
 * 
 * Validates CSRF token, Math CAPTCHA, checks rate limiting lockout,
 * verifies password using password_verify(), regenerates session ID,
 * checks 2FA status, and enforces state machine transitions.
 * Supports both standard Form Submissions and Modern AJAX JSON requests.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

$isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') 
       || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
       || (isset($_POST['is_ajax']) && $_POST['is_ajax'] === '1');

function respondLoginError(string $message, bool $isAjax) {
    // Explicitly destroy any existing authenticated session state
    unset(
        $_SESSION['auth_state'], 
        $_SESSION['user_id'], 
        $_SESSION['user_role'], 
        $_SESSION['user_name'], 
        $_SESSION['user_email'],
        $_SESSION['user_hospital']
    );
    if (isset($_COOKIE['remember_user_profile'])) {
        setcookie('remember_user_profile', '', time() - 42000, '/');
        unset($_COOKIE['remember_user_profile']);
    }

    $newCaptcha = generateMathCaptcha();
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode([
            'success'     => false,
            'error'       => $message,
            'new_captcha' => $newCaptcha['code']
        ]);
        exit();
    }
    $_SESSION['login_errors'] = [$message];
    session_write_close();
    header("Location: ../public/login.php");
    exit();
}

function respondLoginSuccess(string $redirectUrl, array $user, bool $isAjax) {
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode([
            'success'  => true,
            'redirect' => $redirectUrl,
            'message'  => 'Authentication successful',
            'user'     => [
                'name' => $user['full_name'] ?? 'User',
                'role' => $user['role'] ?? 'officer'
            ]
        ]);
        exit();
    }
    header("Location: " . $redirectUrl);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) {
        respondLoginError("Invalid request method.", true);
    }
    header("Location: ../public/login.php");
    exit();
}

$csrfToken     = $_POST[CSRF_TOKEN_NAME] ?? '';
$captchaAnswer = $_POST['captcha_answer'] ?? '';

// 1. Validate CSRF Token
if (!validateCSRFToken($csrfToken)) {
    respondLoginError("Invalid or expired session security token. Please refresh.", $isAjax);
}

// 2. Validate CAPTCHA
if (!verifyMathCaptcha($captchaAnswer)) {
    respondLoginError("Incorrect CAPTCHA verification code. Please check and try again.", $isAjax);
}

$identifier = sanitizeInput($_POST['identifier'] ?? '');
$password   = $_POST['password'] ?? '';
$clientIP   = getClientIP();

if (empty($identifier) || empty($password)) {
    respondLoginError("Please enter your username/email and password.", $isAjax);
}

try {
    $pdo = getDBConnection();

    // 3. Check Rate Limiting Lockout (5 failed attempts in 15 minutes)
    $rateCheck = $pdo->prepare("
        SELECT COUNT(*) FROM login_attempts 
        WHERE identifier = :identifier AND attempt_time > NOW() - INTERVAL " . LOGIN_LOCKOUT_MINUTES . " MINUTE AND success = 0
    ");
    $rateCheck->execute([':identifier' => $identifier]);
    $failedAttempts = (int)$rateCheck->fetchColumn();

    if ($failedAttempts >= MAX_LOGIN_ATTEMPTS) {
        logAuditEvent(null, 'LOGIN_LOCKOUT', "Account locked due to $failedAttempts failed attempts for identifier: $identifier");
        respondLoginError("Too many failed login attempts. Account temporarily locked for " . LOGIN_LOCKOUT_MINUTES . " minutes.", $isAjax);
    }

    // 4. Find User by Username or Email
    $stmt = $pdo->prepare("
        SELECT id, role, full_name, username, email, password_hash, email_verified, two_factor_enabled, status 
        FROM users 
        WHERE username = :username_id OR email = :email_id
    ");
    $stmt->execute([':username_id' => $identifier, ':email_id' => $identifier]);
    $user = $stmt->fetch();

    // 5. Verify User Existence & Password
    if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
        // Record failed attempt
        $logAttempt = $pdo->prepare("INSERT INTO login_attempts (identifier, ip_address, attempt_time, success) VALUES (:id, :ip, NOW(), 0)");
        $logAttempt->execute([':id' => $identifier, ':ip' => $clientIP]);

        logAuditEvent($user['id'] ?? null, 'LOGIN_FAILED', "Failed password login attempt for: $identifier");
        respondLoginError("Invalid username/email or password.", $isAjax);
    }

    // 6. Verify Account Status
    if ($user['status'] === 'blocked') {
        logAuditEvent($user['id'], 'LOGIN_BLOCKED', "Blocked user account attempted login: {$user['username']}");
        respondLoginError("Your account has been suspended. Please contact administrator.", $isAjax);
    }

    if ($user['email_verified'] == 0 || $user['status'] === 'pending') {
        $_SESSION['verify_user_id'] = $user['id'];
        $_SESSION['verify_email']   = $user['email'];
        $_SESSION['otp_errors']     = ["Please complete email verification before logging in."];
        session_write_close();
        if ($isAjax) {
            respondLoginSuccess("../public/verify-email.php", $user, true);
        } else {
            header("Location: ../public/verify-email.php");
            exit();
        }
    }

    // 7. Log Successful Attempt & Regenerate Session ID
    $logAttempt = $pdo->prepare("INSERT INTO login_attempts (identifier, ip_address, attempt_time, success) VALUES (:id, :ip, NOW(), 1)");
    $logAttempt->execute([':id' => $identifier, ':ip' => $clientIP]);

    secureRegenerateSession();

    $_SESSION['user_id']         = $user['id'];
    $_SESSION['user_role']       = $user['role'];
    $_SESSION['user_name']       = $user['full_name'];
    $_SESSION['user_email']      = $user['email'];
    $_SESSION['user_2fa_enabled']= (bool)$user['two_factor_enabled'];

    // 8. Check 2FA Requirement
    if ($user['two_factor_enabled'] == 1) {
        $_SESSION['auth_state'] = AUTH_STATE_2FA_PENDING;
        logAuditEvent($user['id'], 'LOGIN_2FA_CHALLENGE_ISSUED', "Password correct. Prompting for 2FA TOTP challenge.");
        session_write_close();
        respondLoginSuccess("../public/verify-2fa.php", $user, $isAjax);
    }

    // Fully Authenticated State
    $_SESSION['auth_state'] = AUTH_STATE_FULLY_AUTHENTICATED;
    logAuditEvent($user['id'], 'LOGIN_SUCCESS', "User authenticated successfully (Role: {$user['role']})");

    session_write_close(); // Ensure session is written before response

    // Redirect based on role
    $targetUrl = ($user['role'] === 'admin') ? "../admin/dashboard.php" : "../officer/dashboard.php";
    respondLoginSuccess($targetUrl, $user, $isAjax);

} catch (Exception $e) {
    error_log("Login processing exception: " . $e->getMessage());
    respondLoginError("An unexpected server error occurred. Please try again.", $isAjax);
}
