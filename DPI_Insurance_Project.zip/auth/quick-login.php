<?php
/**
 * Permanent Quick-Login Controller for Hospital Officers & Administrators
 * 
 * Provides instantaneous 1-click permanent authentication without password/captcha/2FA hurdles.
 * Enforces 10-year persistent sessions and permanent authentication cookies.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$profile = trim($_GET['profile'] ?? $_POST['profile'] ?? 'officer');
if (!in_array($profile, ['officer', 'general_officer', 'test_officer', 'admin'])) {
    $profile = 'officer';
}

try {
    $pdo = getDBConnection();

    // Clear any temporary rate limit lockouts
    $pdo->exec("TRUNCATE TABLE login_attempts");

    // Fetch target user by role or designated email
    if ($profile === 'admin') {
        $stmt = $pdo->prepare("SELECT id, role, full_name, username, email, hospital_name, department FROM users WHERE email = '11239a107@kanchiuniv.ac.in' OR username = 'admin' LIMIT 1");
    } elseif ($profile === 'general_officer' || $profile === 'test_officer') {
        $stmt = $pdo->prepare("SELECT id, role, full_name, username, email, hospital_name, department FROM users WHERE username = 'test_officer' OR email = 'test_officer@hospital.com' LIMIT 1");
    } else {
        $stmt = $pdo->prepare("SELECT id, role, full_name, username, email, hospital_name, department FROM users WHERE email = '11239a089@kanchiuniv.ac.in' OR username = 'sarah_officer' LIMIT 1");
    }
    $stmt->execute();
    $user = $stmt->fetch();

    // Fallback: If specific user not found, fetch by role
    if (!$user) {
        $stmtRole = $pdo->prepare("SELECT id, role, full_name, username, email, hospital_name, department FROM users WHERE role = :r AND status = 'active' LIMIT 1");
        $stmtRole->execute([':r' => $profile]);
        $user = $stmtRole->fetch();
    }

    // If still no user exists, auto-seed default account
    if (!$user) {
        if ($profile === 'admin') {
            $pass = password_hash('AdminPass123!', PASSWORD_DEFAULT);
            $pdo->prepare("
                INSERT INTO users (role, full_name, username, hospital_name, department, email, password_hash, email_verified, two_factor_enabled, status, created_at)
                VALUES ('admin', 'System Administrator', 'admin', 'City Central Hospital', 'Administration', '11239a107@kanchiuniv.ac.in', :p, 1, 0, 'active', NOW())
            ")->execute([':p' => $pass]);
            $userId = (int)$pdo->lastInsertId();
            $user = [
                'id' => $userId,
                'role' => 'admin',
                'full_name' => 'System Administrator',
                'username' => 'admin',
                'email' => '11239a107@kanchiuniv.ac.in',
                'hospital_name' => 'City Central Hospital',
                'department' => 'Administration'
            ];
        } else {
            $pass = password_hash('OfficerPass123!', PASSWORD_DEFAULT);
            $pdo->prepare("
                INSERT INTO users (role, full_name, username, hospital_name, department, phone, email, password_hash, email_verified, two_factor_enabled, status, created_at)
                VALUES ('officer', 'Officer Sarah Connor', 'sarah_officer', 'City Central Hospital', 'Claims & Billing', '+91 9876543210', '11239a089@kanchiuniv.ac.in', :p, 1, 0, 'active', NOW())
            ")->execute([':p' => $pass]);
            $userId = (int)$pdo->lastInsertId();
            $user = [
                'id' => $userId,
                'role' => 'officer',
                'full_name' => 'Officer Sarah Connor',
                'username' => 'sarah_officer',
                'email' => '11239a089@kanchiuniv.ac.in',
                'hospital_name' => 'City Central Hospital',
                'department' => 'Claims & Billing'
            ];
        }
    }

    // Regenerate session and set permanent session superglobals
    secureRegenerateSession();

    $_SESSION['user_id']          = (int)$user['id'];
    $_SESSION['user_role']        = $user['role'];
    $_SESSION['user_name']        = $user['full_name'];
    $_SESSION['user_email']       = $user['email'];
    $_SESSION['user_hospital']    = $user['hospital_name'] ?? 'City Central Hospital';
    $_SESSION['user_2fa_enabled'] = false;
    $_SESSION['auth_state']       = AUTH_STATE_FULLY_AUTHENTICATED;

    // Set 10-year permanent authentication cookie
    $isSecure = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ||
                (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
    $expireTime = time() + (3650 * 24 * 3600); // 10 years
    setcookie('remember_user_profile', $user['role'], [
        'expires'  => $expireTime,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    logAuditEvent($user['id'], 'PERMANENT_PROFILE_LOGIN', "Permanent 1-click login as {$user['role']} ({$user['username']})");

    session_write_close();

    // Redirect to respective dashboard
    if ($user['role'] === 'admin') {
        header("Location: ../admin/dashboard.php");
    } else {
        header("Location: ../officer/dashboard.php");
    }
    exit();

} catch (Exception $e) {
    error_log("Permanent profile login error: " . $e->getMessage());
    $_SESSION['login_errors'] = ["An error occurred while processing your request. Please try again."];
    session_write_close();
    header("Location: ../public/login.php");
    exit();
}
