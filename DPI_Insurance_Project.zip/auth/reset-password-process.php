<?php
/**
 * Password Reset Execution Processor (Phase 12)
 * 
 * Validates new password strength, computes password_hash(), updates users table,
 * invalidates reset tokens, and writes audit event.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/forgot-password.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['reset_errors'] = ["Invalid CSRF token."];
    header("Location: ../public/forgot-password.php");
    exit();
}

$rawToken        = sanitizeInput($_POST['token'] ?? '');
$password        = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

if (empty($rawToken) || empty($password) || empty($confirmPassword)) {
    $_SESSION['reset_errors'] = ["All password fields are required."];
    header("Location: ../public/reset-password.php?token=" . urlencode($rawToken));
    exit();
}

if (strlen($password) < 8) {
    $_SESSION['reset_errors'] = ["New password must be at least 8 characters long."];
    header("Location: ../public/reset-password.php?token=" . urlencode($rawToken));
    exit();
}

if ($password !== $confirmPassword) {
    $_SESSION['reset_errors'] = ["Password confirmation does not match."];
    header("Location: ../public/reset-password.php?token=" . urlencode($rawToken));
    exit();
}

try {
    $pdo = getDBConnection();
    $tokenHash = hash('sha256', $rawToken);

    // Validate active token
    $stmt = $pdo->prepare("
        SELECT id, user_id, expires_at, used 
        FROM password_resets 
        WHERE token_hash = :hash AND used = 0
    ");
    $stmt->execute([':hash' => $tokenHash]);
    $tokenRecord = $stmt->fetch();

    if (!$tokenRecord || strtotime($tokenRecord['expires_at']) <= time()) {
        $_SESSION['reset_errors'] = ["Invalid or expired reset token. Please request a new password reset link."];
        header("Location: ../public/forgot-password.php");
        exit();
    }

    $userId = (int)$tokenRecord['user_id'];
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $pdo->beginTransaction();

    // 1. Update user password
    $userUpdate = $pdo->prepare("UPDATE users SET password_hash = :pass, updated_at = NOW() WHERE id = :id");
    $userUpdate->execute([':pass' => $passwordHash, ':id' => $userId]);

    // 2. Mark token as used
    $tokenUpdate = $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = :id");
    $tokenUpdate->execute([':id' => $tokenRecord['id']]);

    // 3. Invalidate all previous reset tokens for user
    $invAll = $pdo->prepare("UPDATE password_resets SET used = 1 WHERE user_id = :user_id");
    $invAll->execute([':user_id' => $userId]);

    $pdo->commit();

    logAuditEvent($userId, 'PASSWORD_RESET_SUCCESS', "User updated account password successfully via email reset token");

    $_SESSION['login_success'] = "Password reset successfully! You may now sign in with your new password.";
    header("Location: ../public/login.php");
    exit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['reset_errors'] = ["Password reset error: " . $e->getMessage()];
    header("Location: ../public/reset-password.php?token=" . urlencode($rawToken));
    exit();
}
