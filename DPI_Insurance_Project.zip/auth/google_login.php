<?php
/**
 * Route alias for Google OAuth 2.0 login (underscore alias)
 */
require_once __DIR__ . '/google-login.php';
