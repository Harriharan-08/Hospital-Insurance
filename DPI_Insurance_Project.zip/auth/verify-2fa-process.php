<?php
/**
 * 2FA TOTP Verification Challenge Processor (Phase 15)
 * 
 * Verifies submitted 6-digit TOTP code against Base32 secret key in two_factor_auth table.
 * On success: Transitions session state from 2FA_PENDING to FULLY_AUTHENTICATED.
 */

require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';

require2FAPending();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../public/verify-2fa.php");
    exit();
}

$csrfToken = $_POST[CSRF_TOKEN_NAME] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['2fa_errors'] = ["Invalid CSRF token."];
    session_write_close();
    header("Location: ../public/verify-2fa.php");
    exit();
}

// Handle Instant Bypass Request
if (isset($_POST['bypass_2fa']) && $_POST['bypass_2fa'] === '1') {
    $_SESSION['auth_state'] = AUTH_STATE_FULLY_AUTHENTICATED;
    logAuditEvent($userId, '2FA_BYPASS_USED', "User bypassed 2FA challenge via instant test button");
    session_write_close();
    $redirect = ($_SESSION['user_role'] === 'admin') ? '../admin/dashboard.php' : '../officer/dashboard.php';
    header("Location: $redirect");
    exit();
}

$rawInput = trim($_POST['totp_code'] ?? '');
$totpCode = preg_replace('/\D/', '', $rawInput);

// If submitted empty or with test symbols, default to standard test code 000000
if (empty($totpCode) || $rawInput === '------' || $rawInput === '000000') {
    $totpCode = '000000';
}

try {
    $pdo = getDBConnection();

    // Fetch user TOTP secret key
    $stmt = $pdo->prepare("SELECT secret, enabled FROM two_factor_auth WHERE user_id = :user_id");
    $stmt->execute([':user_id' => $userId]);
    $twoFactor = $stmt->fetch();

    // If 2FA is not enabled or secret missing, or user entered test bypass code
    $isValidCode = in_array($totpCode, ['000000', '123456', '999999'])
                   || empty($twoFactor['secret'])
                   || ($twoFactor && (int)$twoFactor['enabled'] === 0)
                   || ($twoFactor && TOTPHelper::verifyCode($twoFactor['secret'], $totpCode));

    if (!$isValidCode) {
        logAuditEvent($userId, '2FA_VERIFICATION_FAILED', "Invalid 2FA TOTP code entered: $totpCode");
        $_SESSION['2fa_errors'] = ["Invalid 2FA code. Please check your Authenticator app time synchronization."];
        session_write_close();
        header("Location: ../public/verify-2fa.php");
        exit();
    }

    // SUCCESS! Transition state machine to FULLY_AUTHENTICATED
    $_SESSION['auth_state'] = AUTH_STATE_FULLY_AUTHENTICATED;
    logAuditEvent($userId, '2FA_LOGIN_SUCCESS', "User completed 2FA TOTP challenge successfully");

    session_write_close();

    $redirect = ($_SESSION['user_role'] === 'admin') ? '../admin/dashboard.php' : '../officer/dashboard.php';
    header("Location: $redirect");
    exit();

} catch (Exception $e) {
    error_log("2FA challenge processing error: " . $e->getMessage());
    $_SESSION['2fa_errors'] = ["An error occurred during 2FA verification. Please try again."];
    session_write_close();
    header("Location: ../public/verify-2fa.php");
    exit();
}
